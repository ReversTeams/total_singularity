local M = {}

-- 尝试开火射击时调用
function M.shoot(api)
    local heat = api:getHeatAmount() + 1
    api:setHeatAmount(heat)
    if (api:getHeatAmount() > 20) then
        local count = 1
        if (api:getAttachment("EXTENDED_MAG") == "eos:arrow_mod_da") then
            count = 5
        end
        if (api:getAttachment("EXTENDED_MAG") == "eos:arrow_mod_dea") then
            count = 10
        end
        for i = 1, count do
            api:shootOnce(api:isShootingNeedConsumeAmmo())
        end
    end
end

local function tick_normal(api, heatTimestamp)
    local delay = api:getCoolingDelay()
    local now = api:getCurrentTimestamp()

    if now - heatTimestamp >= delay then
        local heat = api:getHeatAmount() - api:calcHeatReduction(heatTimestamp)
        api:setHeatAmount(heat)
        if (heat > 10) then
            local count = 2
            if (api:getAttachment("EXTENDED_MAG") == "eos:arrow_mod_da") then
                count = 5
            end
            if (api:getAttachment("EXTENDED_MAG") == "eos:arrow_mod_dea") then
                count = 10
            end
            for i = 1, (heat/api:getHeatMax() * count) do
                api:shootOnce(api:isShootingNeedConsumeAmmo())
            end
            api:setOverheatLocked(true)
        end
    end
end

local function tick_locked(api, heatTimestamp)
    local overheatTime = api:getOverheatTime()
    local now = api:getCurrentTimestamp()

    if now - heatTimestamp >= overheatTime then
        local heat = api:getHeatAmount() - api:calcHeatReduction(heatTimestamp)
        api:setHeatAmount(heat)
        if heat <= 0 then
            api:setOverheatLocked(false);
        end
    end
end

function M.tick_heat(api, heatTimestamp)
    if api:hasHeatData() then
        if api:isOverheatLocked() then
            tick_locked(api, heatTimestamp)
        else
            tick_normal(api, heatTimestamp)
        end
    end
end

-- 警告，此方法是shootOnce的一部分，不要在此处尝试射击，不然会死循环
function M.handle_shoot_heat(api)
    if api:hasHeatData() then
        local heatMax = api:getHeatMax()
        local heat = math.min(api:getHeatAmount() + api:getHeatPerShot(), heatMax)
        api:setHeatAmount(heat)
        if heat >= heatMax then
            api:setOverheatLocked(true);
        end
    end
end

return M