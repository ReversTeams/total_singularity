#version 120
// =====================================================================
//  gbuffers_skybasic.fsh - niebo: zloty dzien / granatowo-fioletowa noc
//  + proceduralne, migoczace gwiazdy (obracaja sie razem z niebem)
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/noise.glsl"
#include "/lib/skyfx.glsl"
#if defined(DIM_END)
  #include "/lib/endsky.glsl"
#endif

uniform mat4  gbufferProjectionInverse;
uniform float rainStrength;
uniform mat4  gbufferModelViewInverse;
uniform vec3  sunPosition;
uniform vec3  moonPosition;
uniform vec3  upPosition;

varying vec4 starData;

/* DRAWBUFFERS:0 */
void main()
{
#if !defined(DIM_END)
    if (starData.a > 0.5) discard;   // wylacz gwiazdy vanilla - zastepuja je proceduralne
#endif                           // End: nie odrzucamy - skybox Endu (szary kolor wierzcholkow) bywa rysowany tym programem

    vec4 ndc = vec4(gl_FragCoord.xy / vec2(viewWidth, viewHeight) * 2.0 - 1.0, 1.0, 1.0);
    vec4 vp  = gbufferProjectionInverse * ndc;
    vec3 viewDir = normalize(vp.xyz / vp.w);

#if defined(DIM_NETHER)
    // Nether: brak nieba - kolor mgly biomu
    gl_FragData[0] = vec4(toLinear(fogColor) * 1.2, 1.0);
    return;
#elif defined(DIM_END)
    // End: proceduralna ciemna fantazja (lib/endsky.glsl)
    vec3 dirW = normalize(mat3(gbufferModelViewInverse) * viewDir);
    gl_FragData[0] = vec4(endSky(dirW), 1.0);
    return;
#endif

    vec3 sunVec  = normalize(sunPosition);
    vec3 moonVec = normalize(moonPosition);
    vec3 upVec   = normalize(upPosition);
    float sunHeight = dot(sunVec, upVec);
    float h = max(dot(viewDir, upVec), 0.0);

    vec3 sky = getSkyColor(vec3(viewDir.xyz), sunVec, moonVec, upVec);
    sky = applyRainToSky(sky, rainStrength);

    // gwiazdy tylko w nocy, nad horyzontem, nie podczas deszczu
    float night = 1.0 - dayFactor(sunHeight);
    if (night > 0.01 && rainStrength < 0.99)
    {
        vec3 dirW = mat3(gbufferModelViewInverse) * viewDir;
        float nightVis = night * (1.0 - rainStrength);
        sky += nightSkyEffects(dirW, nightVis, h);
    }

    gl_FragData[0] = vec4(sky, 1.0);
}
