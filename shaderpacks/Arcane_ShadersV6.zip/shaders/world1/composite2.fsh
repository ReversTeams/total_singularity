#version 120
#define DIM_END
// =====================================================================
//  composite2.fsh - MOTION BLUR (rozmycie ruchu kamery)
//  Predkosc piksela = jego pozycja na ekranie w poprzedniej klatce (reprojekcja z glebi
//  i poprzednich macierzy). Piksele stojace w miejscu i reka nie sa rozmywane.
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/noise.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D depthtex0;

uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferPreviousModelView;
uniform mat4 gbufferPreviousProjection;
uniform vec3 cameraPosition;
uniform vec3 previousCameraPosition;

varying vec2 texcoord;

/* DRAWBUFFERS:0 */
void main()
{
    vec3 col = texture2D(colortex0, texcoord).rgb;
#ifdef MOTION_BLUR
    if (texture2D(colortex1, texcoord).b < 0.3)                 // bez reki
    {
        float d  = texture2D(depthtex0, texcoord).r;
        vec4  vp = gbufferProjectionInverse * vec4(vec3(texcoord, d) * 2.0 - 1.0, 1.0);
        vec3  eye = (gbufferModelViewInverse * vec4(vp.xyz / vp.w, 1.0)).xyz;
        vec3  prevEye = eye + cameraPosition - previousCameraPosition;
        vec4  pc = gbufferPreviousProjection * (gbufferPreviousModelView * vec4(prevEye, 1.0));
        if (pc.w > 0.0)
        {
            vec2  v   = (texcoord - (pc.xy / pc.w * 0.5 + 0.5)) * MOTION_BLUR_STRENGTH;
            float len = length(v);
            if (len > 0.0006)
            {
                v *= min(1.0, 0.04 / len);                       // maks. 4% szerokosci ekranu
                float n = interleavedNoise(gl_FragCoord.xy);
                vec3 acc = col;
                for (int i = 1; i < MOTION_BLUR_SAMPLES; i++)
                {
                    float t = (float(i) + n) / float(MOTION_BLUR_SAMPLES) - 0.5;
                    acc += texture2D(colortex0, clamp(texcoord + v * t, 0.001, 0.999)).rgb;
                }
                col = acc / float(MOTION_BLUR_SAMPLES);
            }
        }
    }
#endif
    gl_FragData[0] = vec4(col, 1.0);
}
