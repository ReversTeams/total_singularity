#version 120
#define DIM_END
// =====================================================================
//  gbuffers_clouds.fsh (v17.6) - chmury: srebrna obwodka + znacznik dla promieni swiatla
//
//  * Srebrna obwodka (silver lining): cienkie brzegi chmur swieca, gdy patrzymy w strone slonca.
//    "Cienkosc" liczona z tekstury chmur (256x256, 1 teksel = 1 komorka): wygladzone pokrycie
//    z 5x5 probek co pol teksela; brzeg = niskie pokrycie, srodek = wysokie.
//  * Znacznik chmury w colortex2 (r = 1, b = 0 - normalna, ktora nie istnieje w geometrii):
//    composite.fsh uzywa go, zeby promienie swiatla przechodzily PRZEZ luki w chmurach.
//
//  v20: CIENIOWANIE CHMUR (self-shadowing). Chmura jest plaska (clouds=fast), wiec glebie udajemy
//  w przestrzeni tekstury: od piksela idziemy w strone slonca/ksiezyca (kierunek swiatla rzutowany
//  na plaszczyzne chmur, 1 teksel = 12 blokow) i sumujemy pokrycie. Duzo chmury po drodze do slonca
//  = ciemny, zacieniony brzeg/spod; brzeg zwrocony do slonca zostaje jasny. Do tego prawo Beera
//  (grube srodki ciemniejsze), jasniejsze "wielokrotne rozproszenie" i chlodniejszy, ciemniejszy
//  spod grubych chmur. Opcje: CLOUD_SHADING, CLOUD_SHADING_STRENGTH, CLOUD_SHADING_STEPS.
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/noise.glsl"

uniform sampler2D texture;
uniform vec3  sunPosition;
uniform vec3  upPosition;
uniform float rainStrength;
uniform mat4  gbufferModelViewInverse;

varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 viewPos;

// Gladkie pokrycie chmur (0 = pusto, 1 = gleboko w chmurze).
// Tekstura jest binarna (1 teksel = 1 komorka chmur), wiec samo probkowanie dawaloby schodki
// o szerokosci calego teksela. Dlatego: rozmyte pokrycie (3x3) liczone w SRODKACH 4 sasiednich
// tekseli (16 odczytow), a potem interpolacja dwuliniowa wg polozenia piksela wewnatrz teksela.
float cloudWeight1D(float d)
{
    float a = abs(d);
    return a < 0.5 ? 1.0 : (a < 1.5 ? 0.6 : 0.0);
}

float cloudCover(vec2 uv)
{
    const float SIZE = 256.0;                       // rozmiar tekstury chmur w vanilla
    vec2 p  = uv * SIZE - 0.5;
    vec2 i0 = floor(p);
    vec2 f  = p - i0;

    float c00 = 0.0, c10 = 0.0, c01 = 0.0, c11 = 0.0;
    for (int k = 0; k < 4; k++)
    {
        for (int l = 0; l < 4; l++)
        {
            float a = step(0.01, texture2D(texture, (i0 + vec2(float(k) - 1.0, float(l) - 1.0) + 0.5) / SIZE).a);
            float kx = float(k), ly = float(l);
            // srodki rogow: indeksy (1,1) (2,1) (1,2) (2,2) w tablicy 4x4
            c00 += a * cloudWeight1D(kx - 1.0) * cloudWeight1D(ly - 1.0);
            c10 += a * cloudWeight1D(kx - 2.0) * cloudWeight1D(ly - 1.0);
            c01 += a * cloudWeight1D(kx - 1.0) * cloudWeight1D(ly - 2.0);
            c11 += a * cloudWeight1D(kx - 2.0) * cloudWeight1D(ly - 2.0);
        }
    }
    float norm = 2.2 * 2.2;                         // suma wag jadra 3x3
    return mix(mix(c00, c10, f.x), mix(c01, c11, f.x), f.y) / norm;
}


// ---------------------------------------------------------------------
//  Cieniowanie chmur: miekkie pokrycie (dwuliniowo, 4 odczyty) i marsz w strone swiatla
// ---------------------------------------------------------------------
float cloudTexel(vec2 uv)
{
    return step(0.01, texture2D(texture, uv).a);
}

float cloudSoft(vec2 uv)
{
    const float SIZE = 256.0;
    vec2 p = uv * SIZE - 0.5;
    vec2 i = floor(p);
    vec2 f = p - i;
    f = f * f * (3.0 - 2.0 * f);
    float a = cloudTexel((i + vec2(0.5, 0.5)) / SIZE);
    float b = cloudTexel((i + vec2(1.5, 0.5)) / SIZE);
    float c = cloudTexel((i + vec2(0.5, 1.5)) / SIZE);
    float d = cloudTexel((i + vec2(1.5, 1.5)) / SIZE);
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// Srednie pokrycie na drodze od piksela do swiatla (0 = czysta droga, 1 = chmura az do konca)
// oraz wzgledna dlugosc tej drogi (0.3 .. 1) - przy wysokim sloncu droga jest krotka.
void cloudLightPath(vec2 uv, vec3 lightDirW, out float meanCover, out float pathF)
{
    const float THICKNESS = 18.0;    // "grubosc" chmury w blokach (stylizowana - chmura jest plaska)
    const float MAX_BLOCKS = 64.0;   // najdluzsza droga w blokach (niskie slonce)
    vec2  hDir = lightDirW.xz;
    float hLen = length(hDir);
    vec2  dirUV = hLen > 0.0001 ? hDir / hLen : vec2(0.0);
#ifdef CLOUD_LIGHT_FLIP
    dirUV = -dirUV;
#endif
    float travel = min(THICKNESS * hLen / max(lightDirW.y, 0.12), MAX_BLOCKS);   // bloki
    float travelTex = travel / 12.0;                                            // teksele
    pathF = clamp(travelTex * 0.5, 0.3, 1.0);

    // Liczba probek dopasowana do dlugosci drogi: gdy slonce jest wysoko, droga ma ulamek teksela i
    // 4 probki trafialyby prawie w to samo miejsce - wystarcza 2. Przy niskim sloncu (dluga droga) pelne kroki.
    float nF  = min(max(ceil(travelTex / 0.6), 2.0), float(CLOUD_SHADING_STEPS));
    float sum = 0.0;
    for (int i = 0; i < CLOUD_SHADING_STEPS; i++)
    {
        if (float(i) >= nF) break;
        float t = (float(i) + 0.5) / nF;
        sum += cloudSoft(uv + dirUV * (t * travelTex / 256.0));
    }
    meanCover = sum / nF;
}

#if CLOUD_STYLE == 1
// =====================================================================
//  v25: OBJETOSCIOWE CHMURY
//  Geometria chmur to nadal jedna plaska plaszczyzna (clouds=fast) - sluzy tylko jako "powierzchnia startowa".
//  Dla kazdego jej piksela idziemy wzdluz promienia z kamery przez PLASTER chmur o grubosci CLOUD_THICKNESS
//  nad ta plaszczyzna i w kazdym kroku pytamy tekstury chmur (pokrycie), jak wysoka jest tam kolumna chmury:
//  srodki duzych chmur sa wysokie i puchate (szum), brzegi niskie i unosza sie nad plaszczyzna, spod jest
//  plaski i ciemniejszy. Daje to prawdziwy parallax, widoczna grubosc przy niskim kacie i boki oswietlone
//  od slonca (marsz w strone swiatla + rozpraszanie do przodu = srebrna obwodka).
//  Odwzorowanie swiat XZ -> UV liczymy z pochodnych ekranowych (dFdx/dFdy), zamiast zakladac "12 blokow na teksel"
//  i orientacje osi - dzieki temu dziala tak samo w vanilla, Sodium i innych wersjach MC (fallback: 12 blokow/teksel).
// =====================================================================
uniform vec3 cameraPosition;

vec3  gP;       // pozycja piksela plaszczyzny wzgledem kamery (osie swiata)
mat2  gJ;       // d(uv) / d(swiat xz)
float gTime;

#ifdef CLOUD_SHADING
const float CV_SHADE = CLOUD_SHADING_STRENGTH;
#else
const float CV_SHADE = 0.6;
#endif
#ifdef CLOUD_SILVER_ON
const float CV_SILVER = CLOUD_SILVER;
#else
const float CV_SILVER = 0.0;
#endif

// gestosc chmury w punkcie q (wzgledem kamery): 0..1
// detail = waga drobnego szumu (0 = brak; maleje, gdy krok marszu jest dlugi - inaczej szum tworzy ziarno)
float cloudDensity(vec3 q, float detail)
{
    float cov = cloudSoft(texcoord + gJ * (q.xz - gP.xz));
    if (cov < 0.001) return 0.0;
    float h   = clamp((q.y - gP.y) / CLOUD_THICKNESS, 0.0, 1.0);
    vec2  w   = q.xz + cameraPosition.xz;
    float n   = vnoise(w * 0.11 + vec2(gTime * 0.012, gTime * 0.008));         // duze "klebki" (~9 blokow)
    n = mix(0.5, n, 0.35 + 0.65 * detail);                                      // przy dlugich krokach tlumimy rozrzut (inaczej ziarno)
    float top = cov * (0.50 + 0.50 * n) * (1.0 + 0.4 * rainStrength);          // wysokosc kolumny (0..1)
    float bot = (1.0 - cov) * 0.22;                                            // brzegi uniesione, srodek nisko
    if (detail > 0.001)
    {
        float n2 = vnoise(w * 0.37 - vec2(gTime * 0.02, 0.0));                 // drobne wybrzuszenia
        bot += 0.10 * n2 * detail;
        top *= 1.0 + (0.30 * n2 - 0.15) * detail;
    }
    top = min(top, 1.0);
    return smoothstep(bot, bot + 0.16, h) * (1.0 - smoothstep(top - 0.30, top, h));
}

/* DRAWBUFFERS:02 */
void main()
{
    // ---- odwzorowanie swiat -> uv z pochodnych (PRZED jakimkolwiek discard) ----
    vec3 P   = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
    vec2 dwx = dFdx(P.xz), dwy = dFdy(P.xz);
    vec2 dux = dFdx(texcoord), duy = dFdy(texcoord);
    float det = dwx.x * dwy.y - dwx.y * dwy.x;
    mat2 J = mat2(1.0 / 3072.0, 0.0, 0.0, 1.0 / 3072.0);                       // fallback: 12 blokow na teksel, 256 tekseli
    if (abs(det) > 1.0e-10)
    {
        float id = 1.0 / det;
        vec2 iw0 = vec2( dwy.y, -dwx.y) * id;                                  // kolumny odwrotnosci macierzy [dwx dwy]
        vec2 iw1 = vec2(-dwy.x,  dwx.x) * id;
        vec2 j0  = dux * iw0.x + duy * iw0.y;
        vec2 j1  = dux * iw1.x + duy * iw1.y;
        float dj  = j0.x * j1.y - j0.y * j1.x;
        float ref = 1.0 / (3072.0 * 3072.0);
        if (abs(dj) > ref * 0.25 && abs(dj) < ref * 4.0) J = mat2(j0, j1);     // odrzuc wartosci spoza rozsadnego zakresu / NaN
    }
    gP = P; gJ = J; gTime = frameTimeCounter;

    vec3  sunV      = normalize(sunPosition);
    float sunHeight = dot(sunV, normalize(upPosition));
    vec3  lightCol  = getLightColor(sunHeight);
    vec3  ambCol    = getAmbientColor(sunHeight);
    vec3  lightV    = normalize(mix(-sunV, sunV, smoothstep(-0.06, 0.06, sunHeight)));   // slonce w dzien, ksiezyc w nocy
    vec3  Lw        = normalize(mat3(gbufferModelViewInverse) * lightV);

    // ---- przedzial promienia w plastrze [P.y, P.y + grubosc] ----
    vec3  D  = normalize(P);
    float tA = length(P);                                                      // sam piksel plaszczyzny
    float tB = abs(D.y) > 0.0005 ? (P.y + CLOUD_THICKNESS) / D.y : 1.0e5;     // gora plastra
    float t0 = max(min(tA, tB), 0.0);
    float t1 = max(tA, tB);
    float len = min(t1 - t0, 110.0);
    if (len <= 0.01) discard;

    // tani test: jesli tekstura jest pusta na poczatku, w polowie i na koncu odcinka - nie marszujemy
    float pre = cloudSoft(texcoord + J * ((D * t0).xz - P.xz));
    pre = max(pre, cloudSoft(texcoord + J * ((D * (t0 + 0.5 * len)).xz - P.xz)));
    pre = max(pre, cloudSoft(texcoord + J * ((D * (t0 + len)).xz - P.xz)));
    if (pre < 0.02) discard;

    float rain  = clamp(rainStrength, 0.0, 1.0);
    float dt    = len / float(CLOUD_VOLUME_STEPS);
    float jit   = interleavedNoise(gl_FragCoord.xy);
    float dWeight = 1.0 - smoothstep(6.0, 14.0, dt);                           // niski kat = dlugie kroki = bez drobnego szumu
    float sigma = 0.16 * CLOUD_DENSITY * (1.0 + 0.6 * rain);
    float cosT  = dot(D, Lw);
    // rozpraszanie do przodu: patrzac w strone swiatla cienkie fragmenty chmury swieca (srebrna obwodka)
    float phase = 0.62 + 1.5 * CV_SILVER * pow(max(cosT, 0.0), 5.0) * (1.0 - rain * 0.8);
    vec3  albedo = toLinear(glcolor.rgb);

    float T = 1.0;
    vec3  acc = vec3(0.0);
    for (int i = 0; i < 12; i++)
    {
        if (i >= CLOUD_VOLUME_STEPS || T < 0.03) break;
        vec3  q = D * (t0 + (float(i) + jit) * dt);
        float d = cloudDensity(q, dWeight);
        if (d > 0.005)
        {
            // glebokosc optyczna w strone swiatla (3 probki)
            float tau = cloudDensity(q + Lw * (CLOUD_THICKNESS * 0.20), 0.0) * 0.20
                      + cloudDensity(q + Lw * (CLOUD_THICKNESS * 0.55), 0.0) * 0.35
                      + cloudDensity(q + Lw * (CLOUD_THICKNESS * 1.05), 0.0) * 0.50;
            float Tl = exp(-tau * CLOUD_THICKNESS * sigma * CV_SHADE);
            float h  = clamp((q.y - P.y) / CLOUD_THICKNESS, 0.0, 1.0);
            vec3  amb = ambCol * 0.95 * (0.55 + 0.45 * h);
            amb *= mix(vec3(0.66, 0.72, 0.86), vec3(1.0), h);                  // spod chlodniejszy i ciemniejszy
            vec3  sc = albedo * (lightCol * (1.0 - rain * 0.75) * 0.72 * phase * (0.12 + 0.88 * Tl)
                               + amb * (1.0 - rain * 0.35));
            sc = mix(sc, vec3(luma(sc)) * vec3(0.92, 0.97, 1.06), rain * 0.7); // deszczowa chmura: szara
            float a = 1.0 - exp(-d * sigma * dt);
            acc += T * a * sc;
            T   *= 1.0 - a;
        }
    }

    float alpha = 1.0 - T;
    if (alpha < 0.04) discard;
    gl_FragData[0] = vec4(acc / max(alpha, 0.001), min(alpha, 0.97));
    gl_FragData[1] = vec4(1.0, 0.0, 0.0, 1.0);                                 // znacznik chmury (patrz composite.fsh)
}

#elif CLOUD_STYLE >= 2
// Styl 2 i 3 (v26/v27): chmury rysuje composite1 (lib/clouds.glsl), wiec plaszczyzne chmur z gry odrzucamy w calosci.
/* DRAWBUFFERS:02 */
void main()
{
    discard;
}

#else
/* DRAWBUFFERS:02 */
void main()
{
    vec4 tex = texture2D(texture, texcoord) * glcolor;
    if (tex.a < 0.01) discard;

    vec3  sunV      = normalize(sunPosition);
    float sunHeight = dot(sunV, normalize(upPosition));
    vec3  lightCol  = getLightColor(sunHeight);
    vec3  ambCol    = getAmbientColor(sunHeight);
    vec3  albedo    = toLinear(tex.rgb);

#if defined(CLOUD_SHADING) || defined(CLOUD_SILVER_ON)
    float cover = cloudCover(texcoord);                              // 0 = brzeg, 1 = gleboko w chmurze
    float thick = smoothstep(0.40, 1.00, cover);
#else
    float thick = 0.0;
#endif

    float direct = 1.0;      // ile bezposredniego swiatla dociera do piksela chmury
    float under  = 0.0;      // ile ma "spod" (zaslonieta gorna polkula)

#ifdef CLOUD_SHADING
    if (CLOUD_SHADING_STRENGTH > 0.001)
    {
        // kierunek swiatla: slonce w dzien, ksiezyc (przeciwna strona) w nocy
        vec3  lightV  = normalize(mix(-sunV, sunV, smoothstep(-0.06, 0.06, sunHeight)));
        vec3  lightW  = normalize(mat3(gbufferModelViewInverse) * lightV);
        float meanCover, pathF;
        cloudLightPath(texcoord, lightW, meanCover, pathF);

        float od = thick * 0.75 + meanCover * 1.6 * pathF;
        od *= 1.0 + rainStrength * 0.6;                              // deszczowe chmury ciemniejsze
        float beer = exp(-od * 1.2 * CLOUD_SHADING_STRENGTH);
        direct = 0.12 + 0.88 * beer;                                 // 0.12 = wielokrotne rozproszenie
        under  = thick * min(CLOUD_SHADING_STRENGTH, 1.0);
    }
#endif

    vec3 ambient = ambCol * 0.85;
    ambient *= mix(vec3(1.0), vec3(0.62, 0.68, 0.82), under * 0.75);  // spod grubych chmur: ciemniej i chlodniej
    vec3 light = lightCol * 0.55 * direct + ambient;
    light = mix(light, vec3(luma(light)) * 0.8, rainStrength * 0.6);

    vec3 color = albedo * light;

#ifdef CLOUD_SILVER_ON
    if (CLOUD_SILVER > 0.001)
    {
        float thin  = 1.0 - smoothstep(0.50, 0.95, cover);               // 1 = cienki brzeg, 0 = gruby srodek
#ifndef CLOUD_SHADING
        color *= mix(0.84, 1.0, thin);                                   // grube chmury odrobine ciemniejsze w srodku
#endif

        float toSun = max(dot(normalize(viewPos), sunV), 0.0);
        // srebrna obwodka tylko w poblizu slonca (daleko od niego jej wklad < 1%) - poza tym nie liczymy pow()
        float nearSun = smoothstep(0.15, 0.30, toSun);
        if (nearSun > 0.0)
        {
            float lining = thin * (pow(toSun, 6.0) * 1.8 + pow(toSun, 1.6) * 0.18) * nearSun;
            lining *= smoothstep(-0.10, 0.20, sunHeight) * (1.0 - rainStrength * 0.85);   // tylko gdy slonce nad horyzontem
            color += lightCol * albedo * lining * CLOUD_SILVER * 1.4;
        }
    }
#endif

    gl_FragData[0] = vec4(color, tex.a);
    gl_FragData[1] = vec4(1.0, 0.0, 0.0, 1.0);        // znacznik chmury (patrz composite.fsh)
}
#endif
