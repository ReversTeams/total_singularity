#version 120
#define DIM_END
// =====================================================================
//  composite8.fsh - BLOOM: poziom 3: zmniejszenie 2x + rozmycie poziome (colortex6 -> colortex3)
//  Piramida o zredukowanej rozdzielczosci (lib/bloom.glsl) - ok. 30x mniej pracy niz
//  dawna kaskada w pelnej rozdzielczosci.
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/bloom.glsl"

uniform sampler2D colortex6;

/* DRAWBUFFERS:3 */
void main()
{
    vec3 sum = vec3(0.0);
#ifdef BLOOM
    if (BLOOM_WIDE > 0.001 && bloomInside(BLOOM_LV3))
        sum = bloomDownBlurH(colortex6, gl_FragCoord.xy, BLOOM_LV3, BLOOM_LV2, BLOOM_RADIUS * 0.6);
#endif
    gl_FragData[0] = vec4(sum, 1.0);
}
