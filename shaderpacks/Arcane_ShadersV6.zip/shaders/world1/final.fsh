#version 120
#define DIM_END
// =====================================================================
//  final.fsh - koncowy post-processing:
//   bloom -> ekspozycja -> tonemapping (ACES) -> gamma -> split toning
//   -> vibrance/saturacja -> winieta -> dithering
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/bloom.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex4;   // bloom: poziom 3 (1/8) - szerokie halo
uniform sampler2D colortex5;   // bloom: poziom 1 (1/2) - waskie halo
uniform sampler2D colortex6;   // bloom: poziom 2 (1/4) - srednie halo
varying vec2 texcoord;

vec3 aces(vec3 x)
{
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

#ifdef FXAA
// ---------------------------------------------------------------------
//  FXAA (v33) - wygladzanie krawedzi calego obrazu, liczone na kolorze sceny PRZED bloomem i tonemappingiem.
//  Jasnosc do wykrywania krawedzi jest "percepcyjna" (sqrt(c / (1 + c))), zeby bardzo jasna tarcza slonca (HDR) nie dominowala.
//  Krawedz (kontrast sasiadow) -> kierunek z gradientu jasnosci -> usrednienie probek wzdluz krawedzi; wynik odrzucany, jesli wyszedl poza zakres jasnosci sasiadow.
// ---------------------------------------------------------------------
float fxL(vec3 c) { return dot(sqrt(c / (1.0 + c)), vec3(0.299, 0.587, 0.114)); }

vec3 fxaaScene(vec2 uv)
{
    vec2  px = 1.0 / vec2(viewWidth, viewHeight);
    vec3  cM = texture2D(colortex0, uv).rgb;
    float lM = fxL(cM);
    float lN = fxL(texture2D(colortex0, uv + vec2( 0.0,  px.y)).rgb);
    float lS = fxL(texture2D(colortex0, uv + vec2( 0.0, -px.y)).rgb);
    float lE = fxL(texture2D(colortex0, uv + vec2( px.x,  0.0)).rgb);
    float lW = fxL(texture2D(colortex0, uv + vec2(-px.x,  0.0)).rgb);
    float lMin = min(lM, min(min(lN, lS), min(lE, lW)));
    float lMax = max(lM, max(max(lN, lS), max(lE, lW)));
    if (lMax - lMin < max(0.0312, lMax * 0.125)) return cM;                           // brak krawedzi: bez zmian (tanio)

    float lNW = fxL(texture2D(colortex0, uv + vec2(-px.x,  px.y)).rgb);
    float lNE = fxL(texture2D(colortex0, uv + vec2( px.x,  px.y)).rgb);
    float lSW = fxL(texture2D(colortex0, uv + vec2(-px.x, -px.y)).rgb);
    float lSE = fxL(texture2D(colortex0, uv + vec2( px.x, -px.y)).rgb);
    vec2  dir = vec2(-((lNW + lNE) - (lSW + lSE)), (lNW + lSW) - (lNE + lSE));          // kierunek krawedzi
    float red = max((lNW + lNE + lSW + lSE) * 0.03125, 1.0 / 128.0);
    dir = clamp(dir / (min(abs(dir.x), abs(dir.y)) + red), -8.0, 8.0) * px;
    vec3 a  = 0.5 * (texture2D(colortex0, uv + dir * (1.0 / 3.0 - 0.5)).rgb + texture2D(colortex0, uv + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 b  = a * 0.5 + 0.25 * (texture2D(colortex0, uv - dir * 0.5).rgb + texture2D(colortex0, uv + dir * 0.5).rgb);
    float lB = fxL(b);
    return (lB < lMin || lB > lMax) ? a : b;
}
#endif

void main()
{
    vec2 uv = texcoord;
#ifdef FXAA
    vec3 color = fxaaScene(uv);
#else
    vec3 color = texture2D(colortex0, uv).rgb;
#endif

#ifdef BLOOM
    // piramida: waskie (1/2) + srednie (1/4) + szerokie (1/8) halo, kazdy poziom to gladki Gauss
    vec3 bl = bloomSample(colortex5, uv, BLOOM_LV1) * 0.30 + bloomSample(colortex6, uv, BLOOM_LV2) * 0.65;
    if (BLOOM_WIDE > 0.001) bl += bloomSample(colortex4, uv, BLOOM_LV3) * BLOOM_WIDE * 0.8;
    color += bl * BLOOM_STRENGTH * BLOOM_TINT;   // magiczna poswiata
#endif

    color *= EXPOSURE;
    color  = aces(color);
    color  = pow(color, vec3(1.0 / 2.2));                                  // powrot do gamma

#ifdef SPLIT_TONING
    float l = luma(color);
    color *= mix(SHADOW_TINT, HIGHLIGHT_TINT, smoothstep(0.05, 0.75, l));   // fioletowe cienie, zlote swiatla
#endif

    // Vibrance: wzmacnia przede wszystkim malo nasycone kolory
    float mx  = max(color.r, max(color.g, color.b));
    float mn  = min(color.r, min(color.g, color.b));
    float sat = mx - mn;
    float lum = luma(color);
    color = mix(vec3(lum), color, 1.0 + VIBRANCE * (1.0 - sat));
    color = mix(vec3(luma(color)), color, SATURATION);                      // globalne nasycenie

#ifdef VIGNETTE
    vec2  q = uv * (1.0 - uv);
    float v = pow(clamp(16.0 * q.x * q.y, 0.0, 1.0), VIGNETTE_POWER);
#if defined(DIM_END)
    float vs = min(VIGNETTE_STRENGTH * (1.0 + 0.6 * END_DEPTH), 0.85);       // End: glebsza winieta
#else
    float vs = VIGNETTE_STRENGTH;
#endif
    color *= mix(vec3(1.0 - vs, 1.0 - vs, 1.0 - vs * 0.75), vec3(1.0), v);
#endif

    // lekki dithering przeciw bandingowi gradientow nieba
    color += (fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(0.06711056, 0.00583715)))) - 0.5) / 255.0;

    gl_FragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
