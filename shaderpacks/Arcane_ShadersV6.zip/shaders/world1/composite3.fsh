#version 120
#define DIM_END
// =====================================================================
//  composite3.fsh - BLOOM: wyciecie jasnosci + zmniejszenie 2x (poziom 1, colortex3)
//  Piramida o zredukowanej rozdzielczosci (lib/bloom.glsl) - ok. 30x mniej pracy niz
//  dawna kaskada w pelnej rozdzielczosci.
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/bloom.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;

vec3 brightPass(vec2 px)
{
    vec2  uv = px / bloomRes();
    vec3  c  = texture2D(colortex0, uv).rgb;
    float m  = texture2D(colortex1, uv).r;
    vec3  b  = c * m + max(c - BLOOM_THRESHOLD, 0.0) * 0.35;
    return min(b, vec3(32.0));
}

/* DRAWBUFFERS:3 */
void main()
{
    vec3 sum = vec3(0.0);
#ifdef BLOOM
    if (bloomInside(BLOOM_LV1))
    {
        vec2 sp = gl_FragCoord.xy / bloomReg(BLOOM_LV1) * bloomRes();     // srodek bloku 2x2 w pelnej rozdzielczosci
        sum  = brightPass(sp + vec2(-1.0, -1.0));
        sum += brightPass(sp + vec2( 1.0, -1.0));
        sum += brightPass(sp + vec2(-1.0,  1.0));
        sum += brightPass(sp + vec2( 1.0,  1.0));
        sum *= 0.25;
    }
#endif
    gl_FragData[0] = vec4(sum, 1.0);
}
