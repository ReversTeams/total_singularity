#version 120
#define DIM_END
// gbuffers_skytextured.fsh - tarcza slonca (zlota) i ksiezyca (chlodny blekit), HDR -> bloom
// W Endzie ta sama paczka rysuje skybox (end_sky.png) - zastepujemy go proceduralnym niebem (lib/endsky.glsl).
#include "/lib/common.glsl"
#if defined(DIM_END)
  #include "/lib/endsky.glsl"
#endif

uniform sampler2D texture;
uniform mat4  gbufferModelViewInverse;
uniform vec3  sunPosition;
uniform float rainStrength;

varying vec2 texcoord;
varying vec4 glcolor;
varying vec3 viewPos;

/* DRAWBUFFERS:0 */
void main()
{
#if defined(DIM_END)
    vec3 dirW = normalize(mat3(gbufferModelViewInverse) * normalize(viewPos));
    gl_FragData[0] = vec4(endSky(dirW), 1.0);
#else
    vec4 tex = texture2D(texture, texcoord) * glcolor;
    bool isSun = dot(normalize(viewPos), normalize(sunPosition)) > 0.0;
    vec3 col = toLinear(tex.rgb);
    col *= isSun ? SUN_COLOR * SUN_BRIGHTNESS : MOON_COLOR * MOON_BRIGHTNESS;
    col *= 1.0 - rainStrength * 0.8;
    gl_FragData[0] = vec4(col, tex.a);
#endif
}
