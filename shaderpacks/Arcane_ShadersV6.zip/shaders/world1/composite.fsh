#version 120
#define DIM_END
// =====================================================================
//  composite.fsh - PASS A: efekty w POLOWIE rozdzielczosci
//  Piksele poza lewa-dolna cwiartka bufora koncza prace od razu, wiec koszt
//  to ok. 1/4 pelnej rozdzielczosci. Wynik -> colortex5 / colortex3,
//  skladany i upsamplowany (z uwzglednieniem glebi) w composite1.fsh.
//    colortex5 = (god rays, SSAO, odleglosc, -)      
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/noise.glsl"
#if CLOUD_STYLE >= 2 && !defined(DIM_END) && !defined(DIM_NETHER)
  #include "/lib/clouds.glsl"
#endif

/*
const int colortex0Format = RGBA16F;
const int colortex1Format = RGBA8;
const int colortex2Format = RGBA8;
const int colortex3Format = RGBA16F;
const int colortex4Format = R11F_G11F_B10F;
const int colortex5Format = RGBA16F;
const int colortex6Format = RGBA16F;
const int colortex7Format = RGBA16F;      // v24: warstwa deszczu / sniegu (gbuffers_weather -> composite1)
const int colortex8Format = RGBA16F;      // v33: chmury (polowa rozdzielczosci) + historia poprzedniej klatki; alfa = przezroczystosc + 1 (0 = brak historii)
const bool colortex8Clear = false;        // historia musi przetrwac miedzy klatkami
const vec4 colortex1ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex2ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex7ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
*/

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;
uniform sampler2D colortex8;          // v33: historia chmur

uniform mat4  gbufferProjection;
uniform mat4  gbufferProjectionInverse;
uniform mat4  gbufferModelViewInverse;
uniform mat4  gbufferPreviousModelView;
uniform mat4  gbufferPreviousProjection;
uniform int   frameCounter;
uniform vec3  cameraPosition;
uniform vec3  previousCameraPosition;
uniform vec3  sunPosition;
uniform vec3  moonPosition;
uniform vec3  upPosition;
uniform float rainStrength;
uniform int   isEyeInWater;

varying vec2 texcoord;

// uporzadkowany wzorzec 4x4 (Bayer): 16 roznych przesuniec probek. composite1 usrednia okno 4x4,
// wiec wzorzec sie znosi i zostaje gladkie AO zamiast ziarna (losowy szum nie dawal tego efektu).
float bayer2(vec2 a) { a = floor(a); return fract(a.x * 0.5 + a.y * a.y * 0.75); }
float bayer4(vec2 a) { a = mod(floor(a), 4.0); return bayer2(a * 0.5) * 0.25 + bayer2(a); }

vec3 toView(vec2 uv, float depth)
{
    vec4 p = gbufferProjectionInverse * vec4(vec3(uv, depth) * 2.0 - 1.0, 1.0);
    return p.xyz / p.w;
}

// Halton(i, b) - nisko-rozbiezna sekwencja do jittera podpikselowego (GLSL 1.20 nie ma operatora %, stad i - (i / b) * b)
float halton(int i, int b)
{
    float f = 1.0, r = 0.0;
    for (int k = 0; k < 8; k++)
    {
        if (i <= 0) break;
        f /= float(b);
        r += f * float(i - (i / b) * b);
        i /= b;
    }
    return r;
}

// waga Catmull-Rom dla jednego z 4 tekseli (k = 0..3) przy ulamku t: ostrzejsze probkowanie historii niz bilinear (bilinear rozmywal przy wolnym obrocie kamery)
float crw(float t, int k)
{
    if (k == 0) return -0.5 * t * t * t + t * t - 0.5 * t;
    if (k == 1) return  1.5 * t * t * t - 2.5 * t * t + 1.0;
    if (k == 2) return -1.5 * t * t * t + 2.0 * t * t + 0.5 * t;
    return 0.5 * t * t * t - 0.5 * t * t;
}

/* DRAWBUFFERS:58 */
void main()
{
    vec2 res     = vec2(viewWidth, viewHeight);
    vec2 halfRes = floor(res * 0.5);
    if (gl_FragCoord.x >= halfRes.x || gl_FragCoord.y >= halfRes.y)
    {
        gl_FragData[0] = vec4(0.0);
        gl_FragData[1] = vec4(0.0);
        return;
    }
    vec2 uv = gl_FragCoord.xy / halfRes;            // ekran -> cwiartka bufora

    float d0    = texture2D(depthtex0, uv).r;
    float d1    = texture2D(depthtex1, uv).r;
    bool  isSky = d0 > 0.99999;
    vec3  P0    = toView(uv, d0);
    float dist0 = length(P0);
    vec3  viewDir = P0 / max(dist0, 0.0001);
    vec4  flags = texture2D(colortex1, uv);         // r emisja, g woda, b reka
    float noise = (bayer4(gl_FragCoord.xy) + 0.03125);   // 0..1, 16 poziomow

    vec4 nd = texture2D(colortex2, uv);              // rgb normalna, a = 1 dla geometrii
    bool solid = !isSky && nd.a > 0.9 && flags.b < 0.3 && abs(d0 - d1) < 0.00002 && !(nd.r > 0.99 && nd.b < 0.01);   // ostatni warunek: znacznik chmury; nd.a < 0.9 = roslina / lisc (bez SSAO)

    // ---------------------------- SSAO ----------------------------
    float ao = 1.0;
#ifdef SSAO
#if defined(DIM_END)
    // End: szerszy promien i dalszy zasieg -> miekkie, glebokie zaciemnienie zakamarkow
    float aoRadius = SSAO_RADIUS * (1.0 + 0.6 * clamp(END_AO, 0.0, 1.0));
    float aoRange  = 128.0;
#else
    float aoRadius = SSAO_RADIUS;
    float aoRange  = 96.0;
#endif
    if (solid && dist0 < aoRange)
    {
        vec3 N = normalize(nd.rgb * 2.0 - 1.0);
        vec3 T = normalize(abs(N.y) < 0.99 ? cross(N, vec3(0.0, 1.0, 0.0)) : cross(N, vec3(1.0, 0.0, 0.0)));
        vec3 B = cross(N, T);
        float bias = 0.04 + dist0 * 0.002;
        float occ = 0.0;
        for (int i = 0; i < SSAO_SAMPLES; i++)
        {
            float t  = (float(i) + noise) / float(SSAO_SAMPLES);       // przesuniecie wzdluz spirali zalezne od wzorca 4x4
            float a  = float(i) * 2.39996323 + noise * 6.2831853;
            float r  = sqrt(t);
            vec3  h  = vec3(cos(a) * r, sin(a) * r, sqrt(max(1.0 - t, 0.0)));
            float sc = mix(0.15, 1.0, t);
            vec3  sp = P0 + (T * h.x + B * h.y + N * h.z) * aoRadius * sc;

            vec4 clip = gbufferProjection * vec4(sp, 1.0);
            if (clip.w <= 0.0) continue;
            vec2 suv = clip.xy / clip.w * 0.5 + 0.5;
            if (suv.x < 0.0 || suv.x > 1.0 || suv.y < 0.0 || suv.y > 1.0) continue;

            float sz = toView(suv, texture2D(depthtex1, suv).r).z;
            float rc = smoothstep(0.0, 1.0, aoRadius / max(abs(P0.z - sz), 0.0001));
            // rosliny i liscie nie zaslaniaja (cienkie, dziurawe geometrie dawaly brudne plamy na ziemi wokol nich)
            float occluder = step(0.9, texture2D(colortex2, suv).a);
            occ += step(sp.z + bias, sz) * rc * occluder;
        }
        ao = 1.0 - occ / float(SSAO_SAMPLES);
    }
#endif

    // --------------------------- God Rays --------------------------
    float ray = 0.0;
#if defined(GODRAYS) && !defined(DIM_NETHER) && !defined(DIM_END)
    {
        vec3  sunVec  = normalize(sunPosition);
        vec3  upVec   = normalize(upPosition);
        float sunHeight = dot(sunVec, upVec);
        bool  sunIsSource = sunHeight > -0.08;
        vec3  lightPosV   = sunIsSource ? sunPosition : moonPosition;
        vec3  lightVec    = normalize(lightPosV);
        float fade        = smoothstep(-0.04, 0.12, dot(lightVec, upVec)) * (1.0 - rainStrength * 0.85);
        vec4  clip        = gbufferProjection * vec4(lightPosV, 1.0);

        if (fade > 0.001 && clip.w > 0.0)
        {
            vec2  lightUV = clip.xy / clip.w * 0.5 + 0.5;
            float vis     = pow(max(dot(viewDir, lightVec), 0.0), GODRAYS_FOCUS);
            if (vis > 0.03)
            {
                vec2  delta = (lightUV - uv) * (GODRAYS_LENGTH / float(GODRAYS_SAMPLES));
                vec2  coord = uv + delta * noise;
                float illum = 0.0, decay = 1.0, total = 0.0;
                for (int i = 0; i < GODRAYS_SAMPLES; i++)
                {
                    coord += delta;
                    vec2 cc = clamp(coord, 0.001, 0.999);
#if defined(CLOUD_SHAFTS) && CLOUD_STYLE >= 2
                    // v36: chmury proceduralne nie zapisuja znacznika w colortex2, wiec "dziury" liczymy z pola chmur: dla probki nieba
                    // bierzemy jej kierunek w swiecie i pytamy ta sama gestosc, co ray-marching (cloudSkyOpacity). Gestsza chmura = mniej swiatla.
                    float skyOpen = step(0.99999, texture2D(depthtex1, cc).r);
                    float cOpen = 1.0;
                    if (skyOpen > 0.5)
                        cOpen = 1.0 - 0.88 * cloudSkyOpacity(normalize(mat3(gbufferModelViewInverse) * toView(cc, 0.5)), cameraPosition, clamp(rainStrength, 0.0, 1.0));
                    illum += skyOpen * cOpen * decay;
#elif defined(CLOUD_SHAFTS)
                    // swiatlo przechodzi przez niebo i (czesciowo) przez chmury; teren, woda i szklo go blokuja.
                    // chmura = znacznik w colortex2.r (1.0; w niebie 0.0), nieprzezroczysta geometria = depthtex1 < 1
                    float open = step(0.99999, texture2D(depthtex1, cc).r) * (1.0 - 0.88 * step(0.99, texture2D(colortex2, cc).r));
                    illum += open * decay;
#else
                    illum += step(0.99999, texture2D(depthtex0, cc).r) * decay;   // 1 = niebo
#endif
                    total += decay;
                    decay *= GODRAYS_DECAY;
                }
                ray = illum / total * vis * fade;
            }
        }
    }
#endif

    gl_FragData[0] = vec4(ray, ao, dist0, solid ? 1.0 : 0.0);   // a = piksel przyjmuje SSAO (waga w rozmyciu)

    // ---------------- chmury proceduralne (v28: tu, w polowie rozdzielczosci; v33: + akumulacja czasowa) ----------------
    // colortex8 = (rgb przedmnozone przez pokrycie, przezroczystosc + 1). Piksel terenu marszuje tylko do swojej glebi,
    // niebo - bez limitu; composite1 skleja wynik z waga glebi.
    // CLOUD_TAA: w kazdej klatce promien jest przesuniety o ulamek piksela (Halton 2,3 / 16 klatek) i ma inny szum marszu; wynik jest
    // usredniany z poprzednia klatka (reprojekcja obrotem kamery - chmury sa "w nieskonczonosci", wiec nie trzeba glebi), a gdy historia
    // mocno sie roznie (nagla zmiana, teleport, deszcz), waga historii spada do zera. To usuwa ziarno i "ucinane", schodkowe krawedzie.
    vec4 cloudOut = vec4(0.0, 0.0, 0.0, 1.0);
#if CLOUD_STYLE >= 2 && !defined(DIM_END) && !defined(DIM_NETHER)
    if (isEyeInWater == 0)
    {
        vec3  csun = normalize(sunPosition);
        vec3  cmoon = normalize(moonPosition);
        vec3  cup  = normalize(upPosition);
        float csh  = dot(csun, cup);
        mat3  mvi  = mat3(gbufferModelViewInverse);
#ifdef CLOUD_TAA
        int   fi   = frameCounter - (frameCounter / 16) * 16 + 1;
        vec2  jit  = vec2(halton(fi, 2), halton(fi, 3)) - 0.5;                          // przesuniecie w pikselach polowy rozdzielczosci
        float jOff = fract(float(frameCounter) * 0.61803399);
#else
        vec2  jit  = vec2(0.0);
        float jOff = 0.0;
#endif
        vec2  uvJ  = clamp((gl_FragCoord.xy + jit) / halfRes, vec2(0.0), vec2(1.0));
        vec3  vJ   = toView(uvJ, 0.5);
        vec3  dirJ = normalize(mvi * normalize(vJ));                                    // promien przez przesuniety punkt piksela
        // Glebie odczytujemy w tym samym, jitterowanym miejscu co promien. Dodatkowo
        // ograniczamy ja glebia srodkowego piksela, aby probka polrozdzielczosci nie
        // przeniosla chmury przez krawedz bloku.
        float dJ = texture2D(depthtex0, uvJ).r;
        float distJ = dJ > 0.99999 ? 1.0e5 : length(toView(uvJ, dJ));
        float cloudMaxDist = min(isSky ? 1.0e5 : dist0, distJ);
        vec3  lightV = normalize(mix(-csun, csun, smoothstep(-0.06, 0.06, csh)));      // slonce w dzien, ksiezyc w nocy
        vec3  Lw   = normalize(mvi * lightV);
        vec3  skyHere = applyRainToSky(getSkyColor(viewDir, csun, cmoon, cup), rainStrength);
        float cloudHitDistance = 0.0;
        cloudOut = proceduralClouds(dirJ, cloudMaxDist, cameraPosition, Lw,
                                    getLightColor(csh), getAmbientColor(csh), skyHere,
                                    clamp(rainStrength, 0.0, 1.0), gl_FragCoord.xy, jOff, cloudHitDistance);
#ifdef CLOUD_TAA
        // --- historia: reprojekcja rzeczywistego punktu w chmurze (uwzglednia ruch kamery w 3D) ---
        // Nie reprojektuj pustego wyniku: stara chmura nie moze zostac na pikselu,
        // ktory w tej klatce jest zasloniety blokiem.
        vec3  cloudWorldPos = cameraPosition + dirJ * cloudHitDistance;
        vec3  prevEye = cloudWorldPos - previousCameraPosition;
        vec4  pc = gbufferPreviousProjection * (gbufferPreviousModelView * vec4(prevEye, 1.0));
        if (cloudHitDistance > 0.0 && pc.w > 0.0)
        {
            vec2 puv = pc.xy / pc.w * 0.5 + 0.5;
            if (puv.x > 0.0 && puv.y > 0.0 && puv.x < 1.0 && puv.y < 1.0)
            {
                vec2 hp = puv * halfRes - 0.5;                                           // wspolrzedne tekseli polowy rozdzielczosci
                vec2 hb = floor(hp);
                vec2 hf = hp - hb;
                vec2 lo = vec2(0.0), hi = halfRes - 1.0;
                vec4  hAcc = vec4(0.0);
                float hW   = 0.0;
                for (int j = 0; j < 4; j++)
                {
                    for (int i = 0; i < 4; i++)
                    {
                        vec2  tp = clamp(hb + vec2(float(i - 1), float(j - 1)), lo, hi);
                        vec4  hv = texture2D(colortex8, (tp + 0.5) / res);              // reczne probkowanie 4x4 (niezalezne od filtrowania bufora)
                        float wg = crw(hf.x, i) * crw(hf.y, j) * step(0.5, hv.a);       // teksele bez historii pomijamy
                        hAcc += hv * wg;
                        hW   += wg;
                    }
                }
                if (hW > 0.5)
                {
                    vec4  hist  = hAcc / hW;
                    vec3  hRgb  = max(hist.rgb, vec3(0.0));                              // Catmull-Rom ma ujemne listki: przycinamy
                    float histT = clamp(hist.a - 1.0, 0.0, 1.0);
                    float diff  = abs(histT - cloudOut.a) + 0.5 * luma(abs(hRgb - cloudOut.rgb));
                    float mot   = length((puv - uvJ) * halfRes);                         // ruch punktu chmury w pikselach polowy rozdzielczosci
                    float base  = mix(0.12, 0.45, smoothstep(0.15, 1.5, mot));          // ruch = krotsza historia (mniej rozmycia), bez ruchu = ok. 8 klatek
                    float w     = mix(base, 1.0, smoothstep(0.60, 1.10, diff));         // duza roznica (nowa chmura, teleport, deszcz) = tylko obecna klatka
                    cloudOut = vec4(mix(hRgb, cloudOut.rgb, w), mix(histT, cloudOut.a, w));
                }
            }
        }
#endif
    }
#endif
    gl_FragData[1] = vec4(cloudOut.rgb, cloudOut.a + 1.0);                              // alfa + 1: wartosc < 0.5 oznacza "brak historii"

}
