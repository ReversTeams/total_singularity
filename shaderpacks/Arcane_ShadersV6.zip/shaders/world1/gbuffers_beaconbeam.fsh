#version 120
#define DIM_END
// gbuffers_beaconbeam.fsh - wiazka latarni: bardzo jasna (HDR -> bloom)
#include "/lib/common.glsl"

uniform sampler2D texture;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPosV;

/* DRAWBUFFERS:01 */
void main()
{
    vec4 tex = texture2D(texture, texcoord) * glcolor;
    if (tex.a < 0.01) discard;
    gl_FragData[0] = vec4(toLinear(tex.rgb) * 3.0, tex.a);
    gl_FragData[1] = vec4(0.0, 0.0, 0.0, 1.0);          // kasuje znacznik odroczonego oswietlenia (wiazka nie jest terenem)
}
