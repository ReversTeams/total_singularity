#version 120
#define DIM_END
// =====================================================================
//  gbuffers_terrain.fsh - bloki: zlociste swiatlo, miekkie cienie, swiecace bloki,
//  labPBR (normal mapy / specular / emisja), normalne dla SSAO
//  colortex1.r = emisja (bloom), colortex2 = normalna geometryczna (SSAO)
//  DEFERRED_LIGHTING: ten shader tylko zapisuje dane materialu (G-buffer), a swiatlo / cienie / PBR
//  liczy deferred.fsh RAZ NA PIKSEL EKRANU (zamiast dla kazdej warstwy lisci i trawy - brak overdrawu).
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/endpalette.glsl"
#include "/lib/shadow.glsl"
#include "/lib/pbr.glsl"
#include "/lib/handlight.glsl"
#include "/lib/lava.glsl"
#include "/lib/gbuf.glsl"

uniform sampler2D texture;
uniform vec3  sunPosition;
uniform vec3  moonPosition;
uniform vec3  upPosition;

varying vec2  texcoord;
varying vec2  lmcoord;
varying vec4  glcolor;
varying vec3  normal;
varying float emissive;
varying vec3  viewPosV;
varying vec3  tangentV;
varying vec3  bitangentV;
varying float plantFlag;
varying float foliageKind;
varying float plantShade;
varying vec3  wposV;

/* DRAWBUFFERS:01245 */
void main()
{
    vec4 tex = texture2D(texture, texcoord);
    if (tex.a < 0.1) discard;

    vec3 albedo = toLinear(tex.rgb * glcolor.rgb);      // glcolor = biom + vanilla AO

    // ---- roslinnosc: zmiennosc koloru i przyciemnienie podstawy ----
    float isFol  = step(0.5, foliageKind);
    float isLeafF = step(0.5, foliageKind) * (1.0 - step(1.5, foliageKind));
    float isPlantF = step(1.5, foliageKind) * (1.0 - step(2.5, foliageKind));
    if (isFol > 0.5)
    {
        float vn = vnoise(wposV.xz * 0.045 + vec2(7.3, 2.1)) * 0.65 + vnoise(wposV.xz * 0.15) * 0.35;
        vec3 tint = mix(vec3(0.86, 1.06, 0.94), vec3(1.10, 1.04, 0.78), smoothstep(0.30, 0.70, vn));   // szmaragd <-> zloto
        albedo *= mix(vec3(1.0), tint, FOLIAGE_VARIATION);
    }
    albedo *= mix(1.0, plantShade, FOLIAGE_SHADE);

    vec3 sunVec  = normalize(sunPosition);
    vec3 moonVec = normalize(moonPosition);
    vec3 upVec   = normalize(upPosition);
    vec3 N       = normalize(normal);

    float warmFlag = step(0.5, emissive) * (1.0 - step(1.5, emissive));
    float soulFlag = step(1.5, emissive) * (1.0 - step(2.5, emissive));
    float endStrong = step(2.5, emissive) * (1.0 - step(3.5, emissive));     // 10012
    float endSoft   = step(3.5, emissive) * (1.0 - step(4.5, emissive));      // 10013
    float lavaFlag  = step(4.5, emissive) * (1.0 - step(5.5, emissive));      // 10020 (lib/lava.glsl)
#ifdef DEFERRED_LIGHTING
    // ================= TRYB ODROCZONY: tylko zapis G-buffera =================
  #ifdef FANTASY_LAVA
    if (lavaFlag > 0.5)
    {
        // lawa jest samoswiecaca i nie potrzebuje oswietlenia - liczymy ja tu, bez znacznika deferred
        vec3  Nw = normalize(mat3(gbufferModelViewInverse) * N);
        vec3  lavaCol; float lavaEmis;
        shadeLava(wposV, Nw, N, viewPosV, luma(albedo), lavaCol, lavaEmis);
        gl_FragData[0] = vec4(lavaCol, 1.0);
        gl_FragData[1] = vec4(lavaEmis, 0.0, 0.0, 1.0);
        gl_FragData[2] = vec4(N * 0.5 + 0.5, 1.0);
        gl_FragData[3] = vec4(0.0);
        gl_FragData[4] = vec4(0.0);
        return;
    }
  #endif
    PBRData pbrG = noPBR(N);
    if (plantFlag < 0.5) pbrG = readPBR(texcoord, N, normalize(tangentV), normalize(bitangentV), albedo, length(viewPosV));
    float matCode = 1.0 + floor(emissive + 0.5) + 6.0 * floor(foliageKind + 0.5);
    float softG   = (plantFlag > 0.5 || isLeafF > 0.5) ? 0.6 : 1.0;      // rosliny / liscie: bez SSAO (alfa 0.6)
    gl_FragData[0] = vec4(albedo, 1.0);
    gl_FragData[1] = vec4(lmcoord, 0.0, DEFER_MARK);
    gl_FragData[2] = vec4(N * 0.5 + 0.5, softG);
    gl_FragData[3] = vec4(pbrG.ao, pbrG.emission, matCode, 0.0);
    gl_FragData[4] = vec4(octEnc(pbrG.N), pbrG.smoothness, pbrG.metal > 0.0 ? 1.0 + pbrG.metal : pbrG.F0.r);   // F0 < 1 = dielektryk, 1 + x = metal (x = ile metalu)
#else
    // ================= TRYB KLASYCZNY (forward): swiatlo liczone w tym shaderze =================
    float emisWarm = emissiveStrength(albedo, warmFlag);
    float emisSoul = emissiveStrength(albedo, soulFlag);
    float emisEnd  = endGlowStrength(albedo) * (endStrong + 0.35 * endSoft) * END_GLOW * END_GLOW_DIM;
    // rosliny i liscie: duzo nakladajacych sie warstw (overdraw) -> tani filtr cienia (4 probki)
    float shadow   = (plantFlag > 0.5 || isLeafF > 0.5) ? getShadowLite(viewPosV, N, lmcoord.y, gl_FragCoord.xy)
                                                        : getShadow(viewPosV, N, lmcoord.y, gl_FragCoord.xy);   // cien z normalnej geometrycznej
#ifdef PLANT_SHADOWS
    // rosliny: skrzyzowane plaszczyzny rzucalyby ostre cienie same na siebie -> lagodzimy odbior
    if (plantFlag > 0.5) shadow = mix(1.0, shadow, PLANT_SHADOW_STRENGTH * 0.6);
#endif

    // labPBR (pomijane dla roslin)
    PBRData pbr = noPBR(N);
    if (plantFlag < 0.5) pbr = readPBR(texcoord, N, normalize(tangentV), normalize(bitangentV), albedo, length(viewPosV));

    vec3 diffuseAlbedo = albedo * (1.0 - pbr.metal);    // metale nie maja dyfuzji
    vec3 color = calcLightingAO(diffuseAlbedo, lmcoord, pbr.N, sunVec, moonVec, upVec, emisWarm, rainStrength, shadow, pbr.ao);
    color += diffuseAlbedo * handLight(viewPosV, pbr.N);                              // swiatlo z reki
    color += albedo * emisSoul * SOUL_EMISSIVE_COLOR * EMISSIVE_BRIGHTNESS;          // cyanowa poswiata dusz
    // poswiata blokow Endu: kolor tekstury podbity w strone akcentu palety, delikatnie pulsuje
    color += albedo * mix(vec3(1.0), END_COL_C * 1.5, 0.35) * emisEnd * EMISSIVE_BRIGHTNESS * 1.6
           * (0.88 + 0.12 * sin(frameTimeCounter * 1.3));
    float emisPBR = pbr.emission * PBR_EMISSION;
    color += albedo * emisPBR * EMISSIVE_BRIGHTNESS;                                  // emisja z tekstury _s
    color += pbrSpecular(pbr, viewPosV, sunVec, moonVec, upVec, lmcoord, shadow, rainStrength);

#if defined(FOLIAGE_SSS) && !defined(DIM_NETHER) && !defined(DIM_END)
    // swiatlo przechodzace przez liscie / trawe, gdy patrzymy w strone slonca (lub ksiezyca)
    if (isLeafF + isPlantF > 0.5)
    {
        float sunH  = dot(sunVec, upVec);
        vec3  Ls    = (dayFactor(sunH) > 0.5) ? sunVec : moonVec;
        float back  = pow(clamp(dot(normalize(viewPosV), Ls), 0.0, 1.0), 3.0);
        float open  = smoothstep(0.30, 0.90, lmcoord.y) * (1.0 - rainStrength);
        color += albedo * vec3(1.15, 1.05, 0.65) * getLightColor(sunH) * back * open * FOLIAGE_SSS_STRENGTH;
    }
#endif

    float emis = max(max(emisWarm, emisSoul), max(emisPBR, emisEnd));
#ifdef FANTASY_LAVA
    if (lavaFlag > 0.5)
    {
        // lawa jest samoswiecaca: nadpisuje oswietlenie wlasnym wygladem (skorupa + zyly)
        vec3  Nw = normalize(mat3(gbufferModelViewInverse) * N);      // normalna w swiecie (wybor plaszczyzny wzoru)
        vec3  lavaCol; float lavaEmis;
        shadeLava(wposV, Nw, N, viewPosV, luma(albedo), lavaCol, lavaEmis);
        color = lavaCol;
        emis  = max(emis, lavaEmis);
    }
#endif
    // SSAO ma przyciemniac glownie swiatlo OTOCZENIA: w pelnym sloncu AO slabnie (colortex1.a = mnoznik 0.3..1).
    // Bez tego w nasloneczionych miejscach tworzyly sie brudne plamy tam, gdzie slonce i tak swieci.
    float aoMul = 1.0;
#if !defined(DIM_NETHER) && !defined(DIM_END)
    {
        float directLit = shadow * smoothstep(0.0, 0.45, dot(N, sunVec)) * smoothstep(-0.05, 0.20, dot(sunVec, upVec))
                        * smoothstep(0.15, 0.60, lmcoord.y) * (1.0 - rainStrength * 0.75);
        aoMul = 1.0 - 0.7 * directLit;
    }
#endif
    // rosliny i liscie sa cienkie / dziurawe: glebia daje na nich "brudne" AO, wiec ich nie dotyczy (alfa 0.6)
    float softMat = (plantFlag > 0.5 || isLeafF > 0.5) ? 0.6 : 1.0;
    gl_FragData[0] = vec4(color, 1.0);
    gl_FragData[1] = vec4(emis, 0.0, 0.0, aoMul);        // r = maska emisji (bloom), a = mnoznik sily SSAO
    gl_FragData[2] = vec4(N * 0.5 + 0.5, softMat);       // normalna dla SSAO, a = 1 zwykly blok / 0.6 roslina
    gl_FragData[3] = vec4(0.0);                          // bufory G-buffera nieuzywane w trybie klasycznym
    gl_FragData[4] = vec4(0.0);
#endif
}
