#version 120
#define DIM_END
// gbuffers_textured.vsh - czasteczki, reka, fallback dla wielu programow
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPosV;

void main()
{
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lmcoord  = clamp((lmcoord - 0.03125) * 1.06667, 0.0, 1.0);
    glcolor  = gl_Color;
    normal   = gl_NormalMatrix * gl_Normal;
    viewPosV = (gl_ModelViewMatrix * gl_Vertex).xyz;
}
