#version 120
// =====================================================================
//  gbuffers_weather.vsh - deszcz / snieg (v24)
//  Wiatr pochyla smugi: przesuniecie poziome rosnie liniowo z wysokoscia nad poziomem oczu
//  (scinanie calej objetosci deszczu), wiec sasiednie smugi zostaja spojne i nie ma szczelin.
//  Kierunek jest ten sam co wiatr roslin (lib/wind.glsl).
// =====================================================================
#include "/lib/settings.glsl"

uniform mat4  gbufferModelView;
uniform mat4  gbufferModelViewInverse;
uniform float frameTimeCounter;
uniform float rainStrength;
uniform vec3  cameraPosition;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPosV;
varying vec2 rainCol;      // pozycja XZ w swiecie (przed pochyleniem) - do rzedzenia smug

void main()
{
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lmcoord  = clamp((lmcoord - 0.03125) * 1.06667, 0.0, 1.0);
    glcolor  = gl_Color;
    normal   = gl_NormalMatrix * gl_Normal;

    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
    rainCol = (gbufferModelViewInverse * vp).xz + cameraPosition.xz;

#ifdef FANTASY_RAIN
    if (RAIN_SLANT > 0.001)
    {
        // pozycja wzgledem kamery w osiach swiata (dziala niezaleznie od tego, jak dana wersja MC sklada macierze)
        vec4  ep    = gbufferModelViewInverse * vp;
        float t     = frameTimeCounter;
        float gust  = 0.5 + 0.5 * sin(t * 0.7);                                   // wolne podmuchy (jak w wind.glsl)
        float lean  = RAIN_SLANT * (0.65 + 0.35 * gust) * (0.7 + 0.6 * rainStrength);
        ep.xz += vec2(0.87, 0.49) * ep.y * lean;                                  // kierunek wiatru roslin
        vp = gbufferModelView * ep;
    }
#endif

    viewPosV    = vp.xyz;
    gl_Position = gl_ProjectionMatrix * vp;
}
