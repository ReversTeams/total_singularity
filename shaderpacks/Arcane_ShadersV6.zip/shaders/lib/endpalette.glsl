// =====================================================================
//  lib/endpalette.glsl - paleta Endu (styl END_STYLE) + poswiata blokow Endu.
//  Wspolne dla nieba (endsky.glsl), blokow (terrain / block), encji i oczu.
// =====================================================================
#ifndef ENDPALETTE_GLSL
#define ENDPALETTE_GLSL

// ---- palety (kolory liniowe, HDR): A - glowna mglawica, B - druga, C - akcent (zyly, korona, pierscien)
#if END_STYLE == 1          // Szkarlatna Szczelina
  #define END_COL_A vec3(0.55, 0.045, 0.20)
  #define END_COL_B vec3(0.20, 0.06, 0.50)
  #define END_COL_C vec3(1.00, 0.42, 0.55)
  #define END_HORIZON vec3(0.032, 0.0070, 0.022)
#elif END_STYLE == 2        // Szmaragdowa Otchlan
  #define END_COL_A vec3(0.03, 0.38, 0.30)
  #define END_COL_B vec3(0.10, 0.08, 0.52)
  #define END_COL_C vec3(0.45, 1.00, 0.80)
  #define END_HORIZON vec3(0.006, 0.026, 0.030)
#else                       // Fioletowa Pustka (domyslna)
  #define END_COL_A vec3(0.30, 0.060, 0.60)
  #define END_COL_B vec3(0.03, 0.28, 0.50)
  #define END_COL_C vec3(0.75, 0.42, 1.00)
  #define END_HORIZON vec3(0.020, 0.0075, 0.046)
#endif
#define END_ZENITH vec3(0.0025, 0.0012, 0.0110)
#define END_VOID   vec3(0.0050, 0.0020, 0.0120)

// kolor mgly terenu w Endzie (zgodny z horyzontem nieba, zeby wyspy gasly w tle)
#define END_FOG_COLOR (END_HORIZON * 0.9)


// Poswiata blokow Endu: swieca nasycone, jasniejsze piksele tekstury (magenta, fiolet, cyjan, roz),
// ciemne i szare fragmenty zostaja ciemne. Wejscie: albedo LINIOWE.
float endGlowStrength(vec3 albedoLinear)
{
    float m   = max(albedoLinear.r, max(albedoLinear.g, albedoLinear.b));
    float sat = m - min(albedoLinear.r, min(albedoLinear.g, albedoLinear.b));
    return smoothstep(0.12, 0.45, m) * smoothstep(0.04, 0.22, sat);
}

// poza Endem te same bloki (purpur, ametyst, chorus) swieca slabiej
#if defined(DIM_END)
  #define END_GLOW_DIM 1.0
#else
  #define END_GLOW_DIM 0.4
#endif
#endif
