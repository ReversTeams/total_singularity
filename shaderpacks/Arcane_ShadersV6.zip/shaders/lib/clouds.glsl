// =====================================================================
//  lib/clouds.glsl (v27) - PROCEDURALNE CHMURY OBJETOSCIOWE  (CLOUD_STYLE 2 i 3), liczone w composite1
//
//  Ray-marching po calym niebie - NIE zalezy od geometrii ani tekstury chmur z gry (vanilla / Sodium / inne wersje MC).
//
//  STYL 3 "Poduszki" (domyslny): klasyczny uklad Minecrafta - siatka komorek CLOUD_CELL x CLOUD_CELL blokow (12 jak w vanilla),
//   kazda zajeta komorka to ZAOKRAGLONY BLOK (SDF zaokraglonego prostopadloscianu). Sasiednie komorki lacza sie gladko (smooth-min),
//   wiec powstaja pikowane, "pluszowe" masy. Gestosc spada miekko z odlegloscia od powierzchni SDF (brak ostrych, pikselowych krawedzi).
//   Ktore komorki sa zajete: wolny szum po INDEKSIE komorki (klastry kilku blokow, jak w vanilla), grubosc kazdej komorki sie zmienia.
//  STYL 2: wolnostojace chmury z szumu 3D (patrz CLOUD_STYLE w settings.glsl).
//
//  Oswietlenie: marsz w strone slonca / ksiezyca (3 probki), Beer + wielokrotne rozproszenie, rozpraszanie do przodu
//   i "SSS" - mocna miekka poswiata krawedzi, gdy patrzymy w strone swiatla; jasna gora, lagodny spod i zaglebienia (AO bez ostrych kontrastow).
//  Atmosfera: dalekie chmury traca kontrast, przyjmuja kolor nieba / mgly (zalezny od FOG_DENSITY) i znikaja plynnie, bez ciecia na zasiegu.
//  Wspolrzedne absolutne (swiat): chmury stoja w miejscu i dryfuja z wiatrem.
// =====================================================================
#ifndef CLOUDS_GLSL
#define CLOUDS_GLSL
#include "/lib/settings.glsl"
#include "/lib/noise.glsl"

#if CLOUD_STYLE >= 3
const float CLOUD_RANGE = 2200.0;       // maksymalna odleglosc marszu; cienka warstwa => chmury widac juz od ~3 stopni nad horyzontem
#else
const float CLOUD_RANGE = 1300.0;
#endif
#ifdef CLOUD_SHADING
const float CLOUD_SHADE = CLOUD_SHADING_STRENGTH;     // istniejacy suwak sily cieniowania
#else
const float CLOUD_SHADE = 0.6;
#endif
#ifdef CLOUD_SILVER_ON
const float CLD_SILVER = CLOUD_SILVER;                // istniejacy suwak srebrnej obwodki
#else
const float CLD_SILVER = 0.0;
#endif
#ifdef FOG
const float CLD_FOG = FOG_DENSITY;                    // mgla globalna skaluje, jak szybko chmury ginaa w oddali
#else
const float CLD_FOG = 0.35;
#endif

// parametry ksztaltu stylow 3 (Poduszki) i 4 (Vanilla): ta sama siatka komorek, inne zasady
#if CLOUD_STYLE == 4
const float CLD_THICK = CLOUD_VTHICK;     // vanilla: ~4 bloki grubosci
const float CLD_ROUND = 0.10;             // prawie kwadratowe naroza
const float CLD_SOFT  = 0.7;              // ostre krawedzie
const float CLD_MERGE = 0.26;             // tylko tyle, by zakryc szwy miedzy blokami
const float CLD_RND   = 0.10;             // waga losowych dziur w zajetosci (vanilla ma zwarte klastry)
#elif CLOUD_STYLE == 5
const float CLD_THICK = CLOUD_BTHICK;     // miekkie bloki: cienka warstwa (~10 blokow)
const float CLD_SOFT  = 0.8;              // margines plastra nad / pod chmura
#elif CLOUD_STYLE == 3
const float CLD_THICK = CLOUD_THICKNESS;
const float CLD_ROUND = CLOUD_ROUNDNESS;
const float CLD_SOFT  = CLOUD_SOFTNESS;
const float CLD_MERGE = CLOUD_MERGE;
const float CLD_RND   = 0.25;
#endif

float cHash31(vec3 p)
{
    p = fract(p * 0.1031);
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
}

float cNoise3(vec3 p)
{
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = cHash31(i);
    float b = cHash31(i + vec3(1.0, 0.0, 0.0));
    float c = cHash31(i + vec3(0.0, 1.0, 0.0));
    float d = cHash31(i + vec3(1.0, 1.0, 0.0));
    float e = cHash31(i + vec3(0.0, 0.0, 1.0));
    float g = cHash31(i + vec3(1.0, 0.0, 1.0));
    float h = cHash31(i + vec3(0.0, 1.0, 1.0));
    float k = cHash31(i + vec3(1.0, 1.0, 1.0));
    return mix(mix(mix(a, b, f.x), mix(c, d, f.x), f.y),
               mix(mix(e, g, f.x), mix(h, k, f.x), f.y), f.z);
}

#if CLOUD_STYLE == 3 || CLOUD_STYLE == 4
// ---------------------------------------------------------------------
//  STYL 3 i 4: siatka zaokraglonych blokow
//  v28 (wydajnosc): zajetosc komorki = 1 oktawa szumu + 1 hash (5 odczytow zamiast 8+), wczesne odrzucenie pustych
//  miejsc (4 odczyty), tani gladki model gestosci do marszu w strone swiatla / AO / dalekich krokow.
// ---------------------------------------------------------------------
float cellNoise(vec2 c) { return vnoise(c * 0.30 + 11.0); }        // gladkie pokrycie; c w jednostkach komorek

float smin(float a, float b, float k)                               // wielomianowe gladkie minimum
{
    float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
    return mix(b, a, h) - k * h * (1.0 - h);
}

// odleglosc (ze znakiem) od zaokraglonego bloku komorki 'cell'; 1000 = komorka pusta
float cellSDF(vec3 pw, vec2 cell, float thr, float rain)
{
    float rnd = hash21(cell + 3.0);
    float n   = (1.0 - CLD_RND) * cellNoise(cell) + CLD_RND * rnd;                                               // zajetosc: klastry (szum) + losowe dziury
    if (n < thr) return 1000.0;
    float core = smoothstep(thr, thr + 0.14, n);                                                   // rdzen klastra = grubszy
#if CLOUD_STYLE == 4
    float ht   = CLD_THICK * (1.0 + 0.30 * rain);                                                  // vanilla: wszystkie bloki tej samej wysokosci => plaskie gory, bez szwow
#else
    float var  = 0.38 * (1.0 - 0.55 * CLD_MERGE);                                                // im mocniej laczymy bloki, tym mniejsze skoki grubosci miedzy nimi
    float ht   = CLD_THICK * ((1.0 - var) + var * fract(rnd * 7.31)) * (0.72 + 0.28 * core) * (1.0 + 0.30 * rain);
#endif
    float hb   = 0.5 * ht;
    float hc   = 0.5 * CLOUD_CELL;
    float r    = min(CLOUD_CELL * 0.5 * CLD_ROUND, hb * 0.98);                               // promien zaokraglenia
    vec3  c    = vec3((cell.x + 0.5) * CLOUD_CELL, CLOUD_HEIGHT + hb, (cell.y + 0.5) * CLOUD_CELL);
    vec3  q    = abs(pw - c) - vec3(hc - r, hb - r, hc - r);
    return length(max(q, 0.0)) + min(max(q.x, max(q.y, q.z)), 0.0) - r;
}

// tani, gladki model: pokrycie z szumu * profil wysokosci (srednia grubosc). Do swiatla, AO i dalekich krokow.
float cloudSmooth(vec3 p, float nS, float thr, float rain)
{
    float cov = smoothstep(thr - 0.06, thr + 0.12, (1.0 - CLD_RND) * nS + 0.5 * CLD_RND);
    float hh  = (p.y - CLOUD_HEIGHT) / (CLD_THICK * (0.8 + 0.3 * rain));
    return cov * smoothstep(-0.1, 0.25, hh) * (1.0 - smoothstep(0.6, 1.1, hh));
}

// oct > 2: pelny model (zaokraglone bloki); oct <= 2: tani gladki model. lod: 0..1 przejscie do gladkiego (aliasing przy dlugim kroku).
float cloudDensity(vec3 p, int oct, float rain, float lod)
{
    if (p.y < CLOUD_HEIGHT - CLD_SOFT * 2.0 || p.y > CLOUD_HEIGHT + CLD_THICK * 1.3 + CLD_SOFT * 2.0 + 2.0) return 0.0;
    vec2  w   = p.xz + vec2(frameTimeCounter * 0.9, frameTimeCounter * 0.45);                      // wiatr (kierunek jak u roslin)
    float thr = 0.54 - (CLOUD_COVERAGE - 1.0) * 0.15 - rain * 0.10;
    vec2  cc  = w / CLOUD_CELL;
    float nS  = cellNoise(cc - 0.5);
    if ((1.0 - CLD_RND) * nS + CLD_RND < thr - 0.07) return 0.0;                                                 // w poblizu nie ma zadnej zajetej komorki
    if (oct <= 2 || lod > 0.999) return cloudSmooth(p, nS, thr, rain);

    vec2  cell = floor(cc);
    vec2  f    = cc - cell;
    vec2  sg   = vec2(f.x < 0.5 ? -1.0 : 1.0, f.y < 0.5 ? -1.0 : 1.0);                           // 3 najblizsi sasiedzi
    vec3  pw   = vec3(w.x, p.y, w.y);
    float k    = CLOUD_CELL * CLD_MERGE;                                                          // sila laczenia komorek (wypelnia rowki miedzy blokami)
    float d    = cellSDF(pw, cell, thr, rain);
    d = smin(d, cellSDF(pw, cell + vec2(sg.x, 0.0), thr, rain), k);
    d = smin(d, cellSDF(pw, cell + vec2(0.0, sg.y), thr, rain), k);
    d = smin(d, cellSDF(pw, cell + sg, thr, rain), k);
    float dens = 1.0 - smoothstep(-CLD_SOFT, CLD_SOFT, d);                             // miekka krawedz (nie ostry prog)
    if (lod > 0.001) dens = mix(dens, cloudSmooth(p, nS, thr, rain), lod);
    return dens;
}

#if CLOUD_STYLE == 4
// Stale cieniowanie scian jak w vanilla (fancy clouds): gora 1.0, spod 0.7, sciany E/W 0.8, N/S 0.9. Ktora sciane widzimy - z najblizszej
// plaszczyzny prostopadloscianu komorki; sciana, za ktora jest zajeta komorka, to wnetrze masy (nie sciana), wiec nie ma szwow w srodku chmury.
float vanillaFace(vec3 p, float rain)
{
    vec2  w    = p.xz + vec2(frameTimeCounter * 0.9, frameTimeCounter * 0.45);
    vec2  cell = floor(w / CLOUD_CELL);
    float hb   = 0.5 * CLD_THICK * (1.0 + 0.30 * rain);
    vec3  o    = vec3(w.x - (cell.x + 0.5) * CLOUD_CELL, p.y - (CLOUD_HEIGHT + hb), w.y - (cell.y + 0.5) * CLOUD_CELL);
    vec3  q    = abs(o) - vec3(0.5 * CLOUD_CELL, hb, 0.5 * CLOUD_CELL);
    float vert = o.y > 0.0 ? 1.0 : 0.70;
    if (q.y >= q.x && q.y >= q.z) return vert;
    float thr  = 0.54 - (CLOUD_COVERAGE - 1.0) * 0.15 - rain * 0.10;
    vec2  nd   = (q.x > q.z) ? vec2(o.x > 0.0 ? 1.0 : -1.0, 0.0) : vec2(0.0, o.z > 0.0 ? 1.0 : -1.0);
    vec2  nc   = cell + nd;
    if ((1.0 - CLD_RND) * cellNoise(nc) + CLD_RND * hash21(nc + 3.0) >= thr) return vert;
    return (q.x > q.z) ? 0.80 : 0.90;
}
#endif
#elif CLOUD_STYLE == 5
// ---------------------------------------------------------------------
//  STYL 5 "Miekkie bloki" (v31): chmury w stylu "chunky soft" - uklad komorek jak w vanilla, ale kazda komorka to miekki, zaokraglony
//  klab z kopulastym wierzchem i sciętym spodem, a sasiednie komorki zlewaja sie bez szwow.
//  1) Pole pokrycia M(x,z) w 0..1: wartosc komorek (wolny szum + losowosc) interpolowana dwuliniowo, ale z "splaszczonymi" wagami -
//     srodek komorki jest plaski (plateau), a przejscie jest krotkie i zaokraglone na granicy komorek. Dwie pelne sasiednie komorki
//     daja M = 1 na granicy, wiec w chmurze nie ma kratki.
//  2) Profil pionowy: chmura istnieje na wysokosci u (0 = spod, 1 = gora) tylko tam, gdzie M przekracza prog rosnacy ku gorze i spodowi
//     => grube komorki sa pelne, cienkie to soczewki, brzegi maja sciecie / kopule. Gora zaokraglona mocniej niz spod.
//  3) Prawie nieprzezroczyste: marsz tylko zbiera pokrycie, a kolor liczymy RAZ w srednim punkcie trafienia
//     (jasniej ku gorze, miekki cien w strone slonca, poswiata cienkich brzegow, w oddali kolor nieba).
// ---------------------------------------------------------------------
vec2 sbWind() { return vec2(frameTimeCounter * 0.9, frameTimeCounter * 0.45); }       // wiatr (kierunek jak u roslin)

float sbThr(float rain) { return 0.54 - (CLOUD_COVERAGE - 1.0) * 0.15 - rain * 0.10; }

float sbValue(vec2 cell, float thr)                                // ile chmury w komorce: 0 = pusta, 1 = pelna
{
    float n = 0.82 * vnoise(cell * 0.30 + 11.0) + 0.18 * hash21(cell + 3.0);
    return smoothstep(thr, thr + 0.24, n);
}

// zaokraglone pokrycie 0..1; lod = 1: tanie, gladkie pokrycie (swiatlo, dalekie kroki - bez siatki)
float sbField(vec2 w, float thr, float lod)
{
    vec2 c = w / CLOUD_CELL - 0.5;                                  // wezly siatki = srodki komorek
    if (lod > 0.999) return smoothstep(thr, thr + 0.24, 0.82 * vnoise(c * 0.30 + 11.0) + 0.09);
    vec2 i = floor(c);
    vec2 f = c - i;
    vec2 k = clamp((f - 0.5) / (2.0 * CLOUD_BROUND) + 0.5, 0.0, 1.0);       // waga: 0 / 1 na plateau, krotki zakret przy granicy
    k = k * k * (3.0 - 2.0 * k);
    float v00 = sbValue(i, thr);
    float v10 = sbValue(i + vec2(1.0, 0.0), thr);
    float v01 = sbValue(i + vec2(0.0, 1.0), thr);
    float v11 = sbValue(i + vec2(1.0, 1.0), thr);
    float m = mix(mix(v00, v10, k.x), mix(v01, v11, k.x), k.y);
    if (lod > 0.001) m = mix(m, smoothstep(thr, thr + 0.24, 0.82 * vnoise(c * 0.30 + 11.0) + 0.09), lod);
    return m;
}

// oct <= 2: tani gladki model (do cienia); lod: przejscie do gladkiego, gdy krok marszu jest dluzszy niz komorka
float cloudDensity(vec3 p, int oct, float rain, float lod)
{
    float th = CLD_THICK * (1.0 + 0.3 * rain);
    float u  = (p.y - CLOUD_HEIGHT) / th;
    if (u < -0.04 || u > 1.04) return 0.0;
    float m = sbField(p.xz + sbWind(), sbThr(rain), oct <= 2 ? 1.0 : lod);
    if (m < 0.02) return 0.0;
    float s    = abs(2.0 * u - 1.0);                                // 0 = polowa grubosci, 1 = gora / spod
    // prog rosnie PONAD 1 przy samej gorze / spodzie, wiec gestosc schodzi do zera plynnie, zanim plaster sie skonczy (bez "uciętej" krawedzi)
    float need = (u > 0.5) ? 0.08 + 1.10 * s * s * s                // gora: mocna kopula
                           : 0.08 + 1.10 * pow(s, 8.0);             // spod: prawie plaski, ale z zaokraglonym brzegiem
    return smoothstep(0.0, 0.26, m - need);
}

// kolor chmury w punkcie ph (srednie trafienie): jedno liczenie na piksel
vec3 sbShade(vec3 ph, float rain, float cosT, vec3 Lw, vec3 lightCol, vec3 ambCol)
{
    float th  = CLD_THICK * (1.0 + 0.3 * rain);
    float u   = clamp((ph.y - CLOUD_HEIGHT) / th, 0.0, 1.0);
    float occ = 0.5 * cloudDensity(ph + Lw * (th * 0.45), 2, rain, 1.0)
              + 0.5 * cloudDensity(ph + Lw * (th * 1.20), 2, rain, 1.0);              // miekki cien: ile chmury w strone swiatla
    float lit = (0.25 + 0.75 * smoothstep(0.05, 0.95, u)) * (1.0 - 0.65 * occ * CLOUD_SHADE);
    float g   = 0.80 + 0.20 * max(cosT, 0.0);
    vec3  base = ambCol * mix(vec3(0.74, 0.82, 0.96), vec3(1.0), u) * 0.95;           // spod chlodniejszy
    vec3  col  = base * (1.0 - rain * 0.35) + lightCol * (1.0 - rain * 0.75) * 0.70 * lit * g;
    float edge = 1.0 - sbField(ph.xz + sbWind(), sbThr(rain), 1.0);                   // cienkie brzegi
    col += lightCol * (0.9 * CLD_SILVER) * pow(max(cosT, 0.0), 3.0) * edge * (1.0 - rain * 0.8);
    return mix(col, vec3(luma(col)) * vec3(0.92, 0.97, 1.06), rain * 0.7);
}
#else
// ---------------------------------------------------------------------
//  STYL 2: chmury z szumu 3D
// ---------------------------------------------------------------------
float cloudDensity(vec3 p, int oct, float rain, float lod)
{
    float h = (p.y - CLOUD_HEIGHT) / CLOUD_DEPTH;
    if (h <= 0.0 || h >= 1.0) return 0.0;

    vec3  w   = vec3(p.x + frameTimeCounter * 0.9, p.y, p.z + frameTimeCounter * 0.45);
    float cov = vnoise(w.xz * 0.0042 + 17.0);
    float covE = smoothstep(0.28, 0.66, cov + (CLOUD_COVERAGE - 1.0) * 0.30 + rain * 0.28);
    if (covE < 0.003) return 0.0;

    float s = 0.55 * cNoise3(w * vec3(0.0185, 0.0260, 0.0185))
            + 0.30 * cNoise3(w * vec3(0.0420, 0.0580, 0.0420) + 7.7);
    if (oct > 2) s += 0.15 * cNoise3(w * 0.105 + 3.1);
    else         s += 0.075;

    float prof = smoothstep(0.0, 0.14, h) * (1.0 - smoothstep(0.30 + 0.50 * covE, 1.0, h));
    float thr  = 0.80 - 0.42 * covE;
    float val  = s - thr - (1.0 - prof) * 0.50;
    return smoothstep(0.0, 0.12, val) * smoothstep(0.0, 0.20, covE);
}
#endif

// grubosc plastra i "sigma" (gestosc optyczna na blok) - wspolne dla ray-marchingu, cieni chmur i promieni swiatla
float cloudThickness(float rain)
{
#if CLOUD_STYLE >= 3
    return CLD_THICK * (1.0 + 0.3 * rain);
#else
    return CLOUD_DEPTH;
#endif
}

float cloudSigma(float rain)
{
#if CLOUD_STYLE == 5
    return 0.42 * CLOUD_DENSITY * (1.0 + 0.3 * rain);
#elif CLOUD_STYLE == 4
    return 0.55 * CLOUD_DENSITY * (1.0 + 0.3 * rain);
#elif CLOUD_STYLE == 3
    return 0.21 * CLOUD_DENSITY * (1.0 + 0.5 * rain);
#else
    return 0.13 * CLOUD_DENSITY * (1.0 + 0.5 * rain);
#endif
}

// v36: nieprzezroczystosc chmur (0..1) w kierunku dir z kamery camPos - DWIE probki gestosci w plastrze (dol i gora), bez marszu.
// Do promieni swiatla (composite.fsh): ta sama funkcja gestosci co widoczne chmury, wiec dziury w chmurach i krawedzie sa te same.
float cloudSkyOpacity(vec3 dir, vec3 camPos, float rain)
{
    float th   = cloudThickness(rain);
    float yMid = float(CLOUD_HEIGHT) + 0.5 * th - camPos.y;
    if (dir.y < 0.015) return 0.0;
    float t = yMid / dir.y;
    if (t <= 0.0 || t > CLOUD_RANGE) return 0.0;                   // plaster za kamera / poza zasiegiem
    float lod = smoothstep(220.0, 640.0, t);                       // daleko: gladkie pokrycie (bez aliasingu siatki)
    vec3  p0  = camPos + dir * ((yMid - 0.25 * th) / dir.y);
    vec3  p1  = camPos + dir * ((yMid + 0.25 * th) / dir.y);
    float d   = 0.5 * (cloudDensity(p0, 3, rain, lod) + cloudDensity(p1, 3, rain, lod));
    float tau = d * cloudSigma(rain) * th / clamp(dir.y, 0.2, 1.0);
    return (1.0 - exp(-tau)) * (1.0 - smoothstep(0.70 * CLOUD_RANGE, CLOUD_RANGE, t));
}

#ifndef CLOUDS_DENSITY_ONLY      // v35: cienie chmur (lib/cloudshadow.glsl) potrzebuja tylko cloudDensity(), bez calego ray-marchingu
// Zwraca (rgb PRZEDMNOZONE przez pokrycie, przezroczystosc T): kolor = scena * T + rgb.
//   dir  - kierunek promienia w osiach swiata, maxDist - odleglosc do geometrii (niebo = bardzo duzo),
//   camPos - absolutna pozycja kamery, Lw - kierunek DO swiatla (slonce / ksiezyc) w osiach swiata,
//   fogCol - kolor nieba / mgly w tym kierunku (do zanikania dalekich chmur).
vec4 proceduralClouds(vec3 dir, float maxDist, vec3 camPos, vec3 Lw, vec3 lightCol, vec3 ambCol,
                      vec3 fogCol, float rain, vec2 fragCoord, float jitOff, out float hitDistance)
{
    const vec4 NONE = vec4(0.0, 0.0, 0.0, 1.0);
    hitDistance = 0.0;
#if CLOUD_STYLE >= 3
    float slabTop = CLD_THICK * (1.0 + 0.3 * rain) + 2.0 * CLD_SOFT;
    float slabBot = -2.0 * CLD_SOFT;
#else
    float slabTop = CLOUD_DEPTH;
    float slabBot = 0.0;
#endif
    float y0 = CLOUD_HEIGHT + slabBot - camPos.y;
    float y1 = CLOUD_HEIGHT + slabTop - camPos.y;
    float t0, t1;
    if (abs(dir.y) < 0.0006)
    {
        if (y0 > 0.0 || y1 < 0.0) return NONE;
        t0 = 0.0; t1 = CLOUD_RANGE;
    }
    else
    {
        float ta = y0 / dir.y, tb = y1 / dir.y;
        t0 = max(min(ta, tb), 0.0);
        t1 = max(ta, tb);
        if (t1 <= 0.0) return NONE;                      // plaster za kamera
    }
    t1 = min(t1, maxDist);
    if (t0 >= CLOUD_RANGE || t1 <= t0) return NONE;
    float span = min(t1 - t0, CLOUD_RANGE - t0);
    if (span < 0.5) return NONE;

#if CLOUD_STYLE >= 3
    // v32: STALY krok (ciagly w zaleznosci od kata), a nie stala liczba krokow zmieniajaca sie skokami - skoki dawaly kolowe pierscienie wokol zenitu.
    // Krok rosnie dopiero wtedy, gdy zabraknie budzetu CLOUD_QUALITY (niski kat nad horyzontem).
    float dt     = max(CLOUD_CELL * 0.30, span / float(CLOUD_QUALITY));
    int   nSteps = int(min(ceil(span / dt), float(CLOUD_QUALITY)));
#else
    int   nSteps = CLOUD_QUALITY;
    float dt    = span / float(nSteps);
#endif
    float jit   = fract(interleavedNoise(fragCoord) + jitOff);                 // jitOff: zmienne w czasie przesuniecie szumu (akumulacja czasowa)
#if CLOUD_STYLE == 5
    float sigma = 0.42 * CLOUD_DENSITY * (1.0 + 0.3 * rain);          // miekkie bloki: gesto, ale pojedynczy krok nie nasyca sie od razu (brak kreskowanych krawedzi)
    float lod   = smoothstep(0.33 * CLOUD_CELL, 0.95 * CLOUD_CELL, dt);
    float lStep = CLD_THICK;
#elif CLOUD_STYLE == 4
    float sigma = 0.55 * CLOUD_DENSITY * (1.0 + 0.3 * rain);          // vanilla: cienkie (4 bloki), ale prawie pelne bloki
    float lod   = smoothstep(0.33 * CLOUD_CELL, 0.95 * CLOUD_CELL, dt);
    float lStep = CLD_THICK;
#elif CLOUD_STYLE == 3
    float sigma = 0.21 * CLOUD_DENSITY * (1.0 + 0.5 * rain);          // poduszki sa prawie nieprzezroczyste, mieknie je krawedz SDF
    float lod   = smoothstep(0.33 * CLOUD_CELL, 0.95 * CLOUD_CELL, dt);
    float lStep = CLD_THICK;                                     // skala marszu w strone swiatla
#else
    float sigma = 0.13 * CLOUD_DENSITY * (1.0 + 0.5 * rain);
    float lod   = 0.0;
    float lStep = CLOUD_DEPTH;
#endif
    float cosT  = dot(dir, Lw);
    const float G = 0.62;
    float hgF   = (1.0 - G * G) / pow(1.0 + G * G - 2.0 * G * cosT, 1.5);               // rozpraszanie do przodu
    float phase = 0.50 + 0.10 * min(hgF, 10.0) * CLD_SILVER * (1.0 - rain * 0.85) + 0.10 * max(-cosT, 0.0);

    float T = 1.0, aw = 0.0, tw = 0.0;
    vec3  acc = vec3(0.0);
    for (int i = 0; i < 32; i++)
    {
        if (i >= nSteps || T < 0.05) break;
        float t = t0 + (float(i) + jit) * dt;
        vec3  p = camPos + dir * t;
        float d = cloudDensity(p, 3, rain, lod);
#if CLOUD_STYLE == 5
        if (d > 0.01)
        {
            float a = 1.0 - exp(-d * sigma * dt);                          // kolor liczymy raz, po petli (sbShade)
            aw += T * a;
            tw += T * a * t;
            T  *= 1.0 - a;
        }
#else
        if (d > 0.01)
        {
            // glebokosc optyczna w strone swiatla (3 probki, rosnace kroki)
#if CLOUD_STYLE == 4
            // vanilla: bez marszu w strone swiatla (plaskie cieniowanie scian)
#elif CLOUD_STYLE == 3
            // swiatlo: 2 tanie probki gladkiego modelu (pelny model w kazdym kroku byl glownym kosztem)
            float tau = cloudDensity(p + Lw * (lStep * 0.14), 2, rain, 0.0) * (lStep * 0.24)
                      + cloudDensity(p + Lw * (lStep * 0.45), 2, rain, 0.0) * (lStep * 0.52);
#else
            float tau = cloudDensity(p + Lw * (lStep * 0.08), 2, rain, 0.0) * (lStep * 0.12)
                      + cloudDensity(p + Lw * (lStep * 0.22), 2, rain, 0.0) * (lStep * 0.20)
                      + cloudDensity(p + Lw * (lStep * 0.50), 2, rain, 0.0) * (lStep * 0.40);
#endif
#if CLOUD_STYLE == 4
            float face = vanillaFace(p, rain);
            vec3  sc   = (ambCol * 0.62 + lightCol * (1.0 - rain * 0.75) * 0.40) * face * 1.30;      // kolor pory dnia x staly wspolczynnik sciany
            sc = mix(sc, vec3(luma(sc)), 0.70);                                                       // vanilla chmury sa prawie neutralnie biale
#elif CLOUD_STYLE == 3
            float lt = 0.20 + 0.80 * exp(-tau * sigma * CLOUD_SHADE);                  // lagodniejszy kontrast: miekkie, rozproszone cienie
            float h  = clamp((p.y - CLOUD_HEIGHT) / (CLD_THICK * (1.0 + 0.3 * rain)), 0.0, 1.0);
            float occ = cloudDensity(p + vec3(0.0, 3.0, 0.0), 2, rain, 0.0);            // AO: ile chmury nad nami (zaglebienia i spod)
            vec3  amb = ambCol * 0.95 * (0.55 + 0.45 * h) * (1.0 - 0.34 * occ);
            amb *= mix(vec3(0.80, 0.86, 0.96), vec3(1.0), h);                          // lekko chlodniejszy spod
            vec3  sc = lightCol * (1.0 - rain * 0.75) * 0.74 * phase * lt + amb * (1.0 - rain * 0.35);
            // SSS: gdy swiatlo jest za chmura / blisko niej, cienkie krawedzie swieca miekka, szeroka poswiata
            float rim = pow(max(cosT, 0.0), 3.0) * exp(-tau * sigma * 0.22) * (0.45 + 0.55 * (1.0 - d)) * (1.0 - rain * 0.8);
            sc += lightCol * (1.15 * CLD_SILVER) * rim;
#else
            float lt = 0.12 + 0.88 * exp(-tau * sigma * CLOUD_SHADE);
            float h  = clamp((p.y - CLOUD_HEIGHT) / CLOUD_DEPTH, 0.0, 1.0);
            vec3  amb = ambCol * 0.95 * (0.42 + 0.58 * h);
            amb *= mix(vec3(0.62, 0.70, 0.90), vec3(1.0), h);
            vec3  sc = lightCol * (1.0 - rain * 0.75) * 0.78 * phase * lt + amb * (1.0 - rain * 0.35);
#endif
            sc = mix(sc, vec3(luma(sc)) * vec3(0.92, 0.97, 1.06), rain * 0.7);         // deszczowa chmura: szara
            float a = 1.0 - exp(-d * sigma * dt);
            acc += T * a * sc;
            aw  += T * a;
            tw  += T * a * t;
            T   *= 1.0 - a;
        }
#endif
    }

    T = clamp((T - 0.05) / 0.95, 0.0, 1.0);                          // petla konczy sie przy T < 0.05 - ten reszta przepuszczalaby tarcze slonca
    float alpha = 1.0 - T;
    if (alpha < 0.003) return NONE;
    float tHit = tw / max(aw, 0.0001);
    hitDistance = tHit;                                                       // srednia glebokosc trafienia - do reprojekcji TAA z paralaksa
#if CLOUD_STYLE == 5
    vec3  col  = sbShade(camPos + dir * tHit, rain, cosT, Lw, lightCol, ambCol);
#else
    vec3  col  = acc / alpha;
#endif
    // integracja z mgla: kontrast spada z odlegloscia, kolor -> kolor nieba / mgly, a przy koncu zasiegu chmura znika plynnie (bez ciecia)
    float fogD = 950.0 / (0.35 + CLD_FOG) * (1.0 / (1.0 + 0.8 * rain));
    float f    = 1.0 - exp(-pow(tHit / fogD, 1.35));
    col   = mix(col, fogCol, f);
#if CLOUD_STYLE == 4
    alpha *= 0.90;                                                                 // vanilla chmury maja alfe ~0.8: niebo lekko przeswieca
#endif
    alpha *= (1.0 - 0.92 * f) * (1.0 - smoothstep(0.70 * CLOUD_RANGE, CLOUD_RANGE, tHit));
    return vec4(col * alpha, 1.0 - alpha);
}
#endif   // CLOUDS_DENSITY_ONLY
#endif
