// =====================================================================
//  lib/water.glsl - plynne falowanie wody (suma sinusoid)
//  waterWave() zwraca vec3(wysokosc, d/dx, d/dz) - gradient analityczny,
//  uzywany do normalnych (odbicia / blyski) w gbuffers_water.fsh
// =====================================================================
#ifndef WATER_GLSL
#define WATER_GLSL
#include "/lib/noise.glsl"

vec3 waveLayer(vec2 p, float t, vec2 dir, float freq, float speed, float amp)
{
    float ph = dot(p, dir) * freq + t * speed;
    float s  = sin(ph);
    float c  = cos(ph) * amp * freq;
    return vec3(s * amp, c * dir.x, c * dir.y);
}

vec3 waterWave(vec2 p, float t)
{
    vec3 w = vec3(0.0);
    w += waveLayer(p, t, normalize(vec2( 0.65,  0.76)), 0.85, 1.00, 0.50);   // duze, wolne fale
    w += waveLayer(p, t, normalize(vec2(-0.80,  0.60)), 1.60, 1.35, 0.30);
    w += waveLayer(p, t, normalize(vec2( 0.30, -0.95)), 2.90, 1.90, 0.15);   // drobne zmarszczki
    w += waveLayer(p, t, normalize(vec2( 0.95,  0.31)), 4.70, 2.60, 0.07);
    return w;
}

// ---------------------------------------------------------------------
//  v17: nowa woda. Zadne z ponizszych nie uzywa kolorow palety (WATER_COLOR),
//  bo ten plik jest dolaczany tez w gbuffers_water.vsh (bez common.glsl).
// ---------------------------------------------------------------------

// Nachylenie powierzchni (dx, dz). Sinusy na wspolrzednych zaburzonych szumem
// (domain warp) + dwie warstwy zmarszczek z szumu => brak widocznego wzoru/kafelkowania.
vec2 waterSlope(vec2 p, float t)
{
    vec2 warp = vec2(vnoise(p * 0.21 + vec2(t * 0.04, 3.7)),
                     vnoise(p * 0.21 + vec2(11.3, -t * 0.03))) * 2.0 - 1.0;
    vec2 q = p + warp * 1.6;
    vec2 s = waterWave(q, t).yz * 0.6;

    const float e = 0.08;
    vec2 r1 = q * 1.9 + vec2(t * 0.35, t * 0.22);
    float n0 = vnoise(r1);
    s += vec2(vnoise(r1 + vec2(e, 0.0)) - n0, vnoise(r1 + vec2(0.0, e)) - n0) / e * 0.22;

    vec2 r2 = q * 4.3 + vec2(-t * 0.50, t * 0.41);
    n0 = vnoise(r2);
    s += vec2(vnoise(r2 + vec2(e, 0.0)) - n0, vnoise(r2 + vec2(0.0, e)) - n0) / e * 0.08;
    return s;
}

// ---------------------------------------------------------------------
//  v24: kregi od kropli deszczu. Siatka komorek; kazda komorka co okres (1.1-1.8 s) dostaje kroplę w losowym
//  punkcie, z ktorej rosnie pierscien (waski grzbiet + slad za nim), gasnacy z wiekiem. Srodek lezy w 0.35-0.65,
//  a promien <= 0.2, wiec pierscien zostaje w swojej komorce - 1 odczyt zamiast 9, bez szwow na granicach.
//  Zwraca nachylenie (dx, dz). rain = rainStrength: slabszy deszcz = mniej aktywnych komorek.
// ---------------------------------------------------------------------
vec2 rippleCell(vec2 p, float t, float rain, float seed)
{
    vec2  cell = floor(p);
    vec2  f    = p - cell;
    float h0   = hash21(cell + seed);
    float ph   = t / (1.1 + 0.7 * h0) + h0 * 7.0;
    float cyc  = floor(ph);
    float age  = ph - cyc;
    if (hash21(cell * 1.37 + cyc * 3.71 + seed * 5.3) > rain * 0.85) return vec2(0.0);
    vec2  ctr  = vec2(0.35) + 0.30 * vec2(hash21(cell + cyc * 1.91 + seed + 2.0), hash21(cell - cyc * 2.53 + seed + 9.0));
    vec2  d    = f - ctr;
    float r    = length(d);
    float x    = r - (0.03 + 0.17 * age);                 // odleglosc od grzbietu pierscienia
    const float w = 0.05;                                  // szerokosc obwiedni
    const float k = 55.0;                                  // gestosc oscylacji (grzbiet + slad)
    float env  = exp(-(x * x) / (w * w));
    float dh   = env * (-k * sin(k * x) - 2.0 * x / (w * w) * cos(k * x));   // d(wysokosc)/dr
    float amp  = 0.012 * smoothstep(0.0, 0.08, age) * (1.0 - age) * (1.0 - age);
    return (d / max(r, 0.001)) * dh * amp;
}

vec2 rainRipples(vec2 p, float t, float rain)
{
    vec2 s = rippleCell(p, t, rain, 0.0);
    // druga warstwa: obrocona (36.9 st.) i wieksza (~1.6 bloku), zeby nie bylo widac regularnej kratki
    const float c = 0.8, sn = 0.6, k2 = 0.62;
    vec2 q = vec2(c * p.x - sn * p.y, sn * p.x + c * p.y) * k2;
    vec2 g = rippleCell(q, t + 3.3, rain, 41.0) * k2;
    s += vec2(c * g.x + sn * g.y, -sn * g.x + c * g.y);   // gradient wraca do osi swiata (R transponowane)
    return s;
}

// Normalna tafli w swiecie. dist = odleglosc od kamery (drobne fale znikaja daleko -> brak migotania).
vec3 waterNormalWorld(vec2 p, float t, float dist, float rain)
{
    vec2 s = waterSlope(p, t) * WATER_NORMAL_STRENGTH;
    s *= 1.0 - 0.7 * smoothstep(60.0, 160.0, dist);
#ifdef RAIN_RIPPLES
    if (rain > 0.02 && dist < 40.0)
        s += rainRipples(p, t, rain) * RAIN_RIPPLE_STRENGTH * (1.0 - smoothstep(14.0, 40.0, dist));
#endif
    return normalize(vec3(-s.x, 1.0, -s.y));
}

vec3 waterNormalWorld(vec2 p, float t, float dist)
{
    return waterNormalWorld(p, t, dist, 0.0);
}

// Kaustyka: siatka jasnych linii (grzbiety dwoch przesuwajacych sie szumow). 0..1
float causticPattern(vec2 p, float t)
{
    vec2 a = p * 0.9 + vec2(t * 0.20, t * 0.13);
    vec2 b = p * 1.35 + vec2(-t * 0.16, t * 0.21) + 7.7;
    a += (vec2(vnoise(a * 0.7 + 3.1), vnoise(a * 0.7 + 9.4)) - 0.5) * 1.6;
    float c1 = 1.0 - abs(vnoise(a) * 2.0 - 1.0);
    float c2 = 1.0 - abs(vnoise(b) * 2.0 - 1.0);
    return smoothstep(0.30, 0.85, c1 * c2 * 1.6);
}

// Szum piany przy brzegu (0..1)
float foamNoise(vec2 p, float t)
{
    return vnoise(p * 2.2 + vec2(t * 0.25, -t * 0.18)) * 0.6
         + vnoise(p * 5.5 + vec2(-t * 0.35, t * 0.30)) * 0.4;
}

// Magiczne iskry na tafli: male, krotko blyskajace punkty. Zwraca jasnosc 0..1,
// h (out) = losowa wartosc komorki do zroznicowania koloru.
float waterSparkle(vec2 p, float time, out float h)
{
    vec2 g = p * 4.0;
    vec2 cell = floor(g);
    h = hash21(cell + 17.0);
    if (h < 0.90) return 0.0;
    vec2 jit = (vec2(hash21(cell + 3.1), hash21(cell + 8.7)) - 0.5) * 0.5;
    float d  = length(fract(g) - 0.5 - jit);
    float tw = pow(max(0.0, sin(time * (1.5 + 3.0 * h) + h * 80.0)), 8.0);
    return (1.0 - smoothstep(0.0, 0.16, d)) * tw;
}

// Kolor wody widziany spod powierzchni (jak w composite1 przy isEyeInWater)
#define UNDERWATER_COLOR(day) (pow(WATER_DEEP_COLOR * 1.1, vec3(2.2)) * (0.15 + 0.85 * (day)) * 1.2)

#endif
