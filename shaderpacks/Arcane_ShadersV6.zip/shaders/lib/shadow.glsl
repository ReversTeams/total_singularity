// =====================================================================
//  lib/shadow.glsl - miekkie cienie ze shadow mapy (PCF, obrotowy dysk)
//  Zwraca 1.0 = w pelni oswietlone, 0.0 = w cieniu.
//  Dolaczac tylko w plikach .fsh (deklaruje uniformy).
// =====================================================================
#ifndef SHADOW_GLSL
#define SHADOW_GLSL
#include "/lib/settings.glsl"
#include "/lib/distort.glsl"
#include "/lib/noise.glsl"
#include "/lib/cloudshadow.glsl"

// Jeden odczyt cienia: 1.0 = swiatlo, 0.0 = cien. p = (xy w shadow mapie, glebokosc odniesienia).
// HW_SHADOW_FILTER: sprzet porownuje glebokosc i miesza 4 sasiednie teksele (PCF 2x2) w jednym odczycie.
#ifdef HW_SHADOW_FILTER
uniform sampler2DShadow shadowtex1;        // glebia tylko nieprzezroczystych obiektow (porownanie sprzetowe)
float shadowTap(vec3 p) { return shadow2D(shadowtex1, p).r; }
  #define SHADOW_TAPS (((SHADOW_SAMPLES) + 1) / 2 > 3 ? ((SHADOW_SAMPLES) + 1) / 2 : 3)   // odczyt = 4 teksele, wiec polowa probek
  #define SHADOW_EDGE_EPS 0.02
#else
uniform sampler2D shadowtex1;              // glebia tylko nieprzezroczystych obiektow
float shadowTap(vec3 p) { return step(p.z, texture2D(shadowtex1, p.xy).r); }
  #define SHADOW_TAPS SHADOW_SAMPLES
  #define SHADOW_EDGE_EPS 0.5
#endif
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform mat4 gbufferModelViewInverse;
uniform vec3 shadowLightPosition;          // slonce w dzien, ksiezyc w nocy
uniform vec3 cameraPosition;              // v35: pozycja absolutna (cienie chmur)
uniform float rainStrength;               // v35: deklarowany tu (programy gbuffers / deferred go juz nie deklaruja)


// lite = true: tylko tani etap 1 (4 probki) - dla roslin i lisci (duzo overdrawu, cien i tak zlagodzony)
float shadowImpl(vec3 viewPos, vec3 nView, float lmSky, vec2 fragCoord, bool lite)
{
#if defined(SHADOWS) && !defined(HAND_PASS) && !defined(DIM_NETHER) && !defined(DIM_END)
    vec3  L    = normalize(shadowLightPosition);
    float cosT = dot(nView, L);
    if (lmSky < 0.12 || cosT < -0.3) return 1.0;      // jaskinie / tylne scianki: cien bez znaczenia

    float dist = length(viewPos);
    if (dist > shadowDistance) return 1.0;                  // poza zasiegiem cieni
    float fade = smoothstep(shadowDistance * 0.80, shadowDistance, dist);

    float cosC = clamp(cosT, 0.0, 1.0);
    vec3 eye   = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
    vec3 nW    = mat3(gbufferModelViewInverse) * nView;
    eye += nW * (0.06 + 0.25 * (1.0 - cosC)) * (1.0 + dist * 0.01);   // offset po normalnej (anty-acne)

    vec3 sp = (shadowProjection * (shadowModelView * vec4(eye, 1.0))).xyz;
    sp.xy   = distortShadow(sp.xy);
    sp      = sp * 0.5 + 0.5;
    if (sp.x < 0.0 || sp.x > 1.0 || sp.y < 0.0 || sp.y > 1.0 || sp.z > 1.0) return 1.0;

    float bias = 0.0007 + 0.0007 * (1.0 - cosC);
    float zRef = sp.z - bias;
    float ang  = 6.2831853 * interleavedNoise(fragCoord);
    vec2  cs   = vec2(cos(ang), sin(ang));                  // jedyny sin/cos na piksel
    float rad  = SHADOW_SOFTNESS / float(shadowMapResolution);

    // ETAP 1 (tani): 4 probki na krawedzi dysku (obrot o 90 stopni = zamiana skladowych).
    // Jesli wszystkie takie same -> piksel jest wyraznie w cieniu albo w swietle.
    vec2  o1 = cs * rad;
    vec2  o2 = vec2(-cs.y, cs.x) * rad;
    float edge = shadowTap(vec3(sp.xy + o1, zRef))
               + shadowTap(vec3(sp.xy + o2, zRef))
               + shadowTap(vec3(sp.xy - o1, zRef))
               + shadowTap(vec3(sp.xy - o2, zRef));
    float lit;
    if (edge < SHADOW_EDGE_EPS)             lit = 0.0;
    else if (edge > 4.0 - SHADOW_EDGE_EPS)  lit = 1.0;
    else if (lite || dist > 36.0) lit = edge * 0.25;      // daleko / rosliny: 4 probki wystarczaja
    else
    {
        // ETAP 2 (tylko na krawedziach cieni): pelny miekki filtr (spirala Vogela bez sin/cos na probke)
        const vec2 GA = vec2(-0.7373689, 0.6754903);        // cos / sin kata zlotego (2.39996 rad)
        vec2 d = cs;
        lit = 0.0;
        for (int i = 0; i < SHADOW_TAPS; i++)
        {
            float r = sqrt((float(i) + 0.5) / float(SHADOW_TAPS));
            lit += shadowTap(vec3(sp.xy + d * (r * rad), zRef));
            d = vec2(d.x * GA.x - d.y * GA.y, d.x * GA.y + d.y * GA.x);
        }
        lit /= float(SHADOW_TAPS);
    }
    return mix(lit, 1.0, fade);
#else
    return 1.0;
#endif
}

// v35: cien chmur - mnoznik swiatla bezposredniego (1 = brak cienia). Niezalezny od shadowDistance (dziala na calym widocznym terenie).
// Pomijamy te same piksele, ktore i tak nie dostaja swiatla bezposredniego: jaskinie i tylne scianki.
float getCloudShadow(vec3 viewPos, vec3 nView, float lmSky)
{
#ifdef CLOUD_SHADOWS_ACTIVE
    vec3 L = normalize(shadowLightPosition);
    if (lmSky < 0.12 || dot(nView, L) < -0.3) return 1.0;
    vec3 Lw = mat3(gbufferModelViewInverse) * L;
    if (Lw.y < 0.08) return 1.0;                                    // slonce prawie na horyzoncie: bez cieni chmur
    vec3 wp = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz + cameraPosition;
    return cloudShadowFactor(wp, Lw, clamp(rainStrength, 0.0, 1.0), length(viewPos));
#else
    return 1.0;
#endif
}

float getShadow(vec3 viewPos, vec3 nView, float lmSky, vec2 fragCoord)
{
    return shadowImpl(viewPos, nView, lmSky, fragCoord, false) * getCloudShadow(viewPos, nView, lmSky);
}

float getShadowLite(vec3 viewPos, vec3 nView, float lmSky, vec2 fragCoord)
{
    return shadowImpl(viewPos, nView, lmSky, fragCoord, true) * getCloudShadow(viewPos, nView, lmSky);
}
#endif
