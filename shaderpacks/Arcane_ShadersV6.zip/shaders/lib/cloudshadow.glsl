// =====================================================================
//  lib/cloudshadow.glsl (v35) - CIENIE CHMUR NA TERENIE
//
//  Ten sam model chmur, ktory rysuje composite.fsh (lib/clouds.glsl: cloudDensity), jest odpytywany z punktu terenu
//  wzdluz promienia DO swiatla (slonce / ksiezyc). Promien przecina plaster chmur CLOUD_HEIGHT .. CLOUD_HEIGHT + grubosc;
//  gestosc w CLOUD_SHADOW_QUALITY punktach tego odcinka daje glebokosc optyczna tau, a przepuszczalnosc exp(-tau)
//  osłabia swiatlo BEZPOSREDNIE (shadow w calcLighting). Swiatlo otoczenia zostaje, wiec cien jest chlodny i miekki.
//
//  Wspolrzedne sa absolutne (swiat) i maja ten sam dryf z wiatrem (frameTimeCounter), co widoczne chmury - cien sunie
//  po krajobrazie razem z nimi i pasuje do ich ksztaltu. Dziala poza zasiegiem shadow mapy (shadowDistance).
//  Wymaga stylu chmur >= 2 (styl 0/1 uzywa chmur z gry - ich tekstury nie ma jak odczytac w oswietleniu terenu).
//
//  Koszt: QUALITY x cloudDensity (pelny model; w oddali plynnie przechodzi w tani gladki). Piksele bez slonca na ziemi,
//  w jaskiniach, powyzej chmur lub przy slonku tuz nad horyzontem wychodza od razu.
// =====================================================================
#ifndef CLOUDSHADOW_GLSL
#define CLOUDSHADOW_GLSL
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

#if defined(CLOUD_SHADOWS) && CLOUD_STYLE >= 2 && !defined(DIM_NETHER) && !defined(DIM_END) && !defined(HAND_PASS)
#define CLOUD_SHADOWS_ACTIVE
#define CLOUDS_DENSITY_ONLY
#include "/lib/clouds.glsl"

// wp - absolutna pozycja punktu na ziemi, Lw - kierunek DO swiatla w osiach swiata (znormalizowany, Lw.y > 0),
// dist - odleglosc od kamery (LOD: daleko cien przechodzi w gladkie pokrycie, bez migotania siatki komorek).
// Zwraca mnoznik swiatla bezposredniego: 1 = brak cienia, 1 - CLOUD_SHADOW_STRENGTH = pod najgrubsza chmura.
float cloudShadowFactor(vec3 wp, vec3 Lw, float rain, float dist)
{
    float th = cloudThickness(rain);
    float y0 = float(CLOUD_HEIGHT);
    float y1 = y0 + th;
    if (wp.y >= y1) return 1.0;                                   // szczyt gory nad chmurami

    float ta = max((y0 - wp.y) / Lw.y, 0.0);                      // wejscie promienia w plaster (0, gdy punkt jest juz w srodku)
    float tb = (y1 - wp.y) / Lw.y;                                // wyjscie z plastra
    float len = tb - ta;
    if (len <= 0.0) return 1.0;

    float lod = smoothstep(220.0, 640.0, dist);                   // styl 3-5: do pelnego modelu (blokowe krawedzie) dla bliskiego terenu
    float acc = 0.0;
    const int NS = CLOUD_SHADOW_QUALITY;
    for (int i = 0; i < 4; i++)
    {
        if (i >= NS) break;
        float t = ta + len * ((float(i) + 0.5) / float(NS));
        acc += cloudDensity(wp + Lw * t, 3, rain, lod);
    }
    float tau = cloudSigma(rain) * (len / float(NS)) * acc;
    float T   = exp(-tau);

    float lowSun = smoothstep(0.08, 0.30, Lw.y);                  // slonce przy horyzoncie: cien robi sie nieskonczenie dlugi - wygaszamy
    float k = CLOUD_SHADOW_STRENGTH * lowSun * (1.0 - clamp(rain, 0.0, 1.0));   // w deszczu niebo i tak jest przyciemnione (rainDim)
    return 1.0 - k * (1.0 - T);
}
#endif   // CLOUD_SHADOWS_ACTIVE
#endif
