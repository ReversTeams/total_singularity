// =====================================================================
//  lib/lava.glsl - lawa (fantasy, ale w stylu Minecrafta): gladka, pikselowana lawa od szkarlatu przez pomarancz po zloto,
//  z delikatnymi, powoli plynacymi plamami; ziarno oryginalnej tekstury zostaje. Wlasny, prosty wzor (nie skopiowany).
//  Uzywane w gbuffers_terrain.fsh (flaga emissive = 5, block.properties: 10020).
// =====================================================================
#ifndef LAVA_GLSL
#define LAVA_GLSL

// Rampa temperatury: 0 = zimna skorupa ... 1+ = najgoretszy rdzen (HDR)
vec3 lavaRamp(float h)
{
    vec3 crust  = vec3(0.045, 0.008, 0.014);    // skorupa, lekko fioletowa
    vec3 deep   = vec3(0.90, 0.050, 0.014);     // szkarlat
    vec3 molten = vec3(2.30, 0.58, 0.045);      // pomaranczowo-zlota
    vec3 core   = vec3(4.40, 2.70, 0.80);       // jasnozolty rdzen
    vec3 c = mix(crust, deep, smoothstep(0.05, 0.38, h));
    c = mix(c, molten, smoothstep(0.35, 0.72, h));
    return mix(c, core, smoothstep(0.78, 1.15, h));
}

// Temperatura powierzchni w punkcie p (swiat, 2D) w chwili t. Prosto, jak w Minecrafcie: jedna miekka, powoli
// plynaca warstwa plam, "pikselowana" do siatki 2 px tekstury, a ziarno oryginalnej tekstury ma wiekszosc glosu.
float lavaHeat(vec2 p, float t, float texLuma)
{
    vec2  flow = vec2(t * 0.030, t * 0.018) * LAVA_FLOW_SPEED;
    vec2  pq   = floor(p * 8.0) / 8.0;                              // klocki 2 px (1 blok = 16 px tekstury)

    float blob = vnoise(pq * 0.45 + flow) * 0.65 + vnoise(pq * 1.10 - flow * 1.4 + 7.3) * 0.35;   // 0..1, plamy

    float crust = clamp(LAVA_CRUST, 0.0, 1.0);
    float h = 0.62 + (blob - 0.5) * (0.9 + 0.8 * crust);            // wiecej skorupy = wiekszy kontrast plam
    h *= 0.94 + 0.06 * sin(t * 0.8 + vnoise(p * 0.05) * 12.0);      // bardzo delikatny oddech
    return h * mix(1.0, 0.45 + 1.10 * texLuma, 0.80);               // oryginalna tekstura: glowny wzor
}

// wp = pozycja w swiecie, Nw = normalna w swiecie, N/viewPos w przestrzeni widoku.
// Gora: wzor z (x, z). Sciany (lawospady): kazda sciana to wlasna plaszczyzna 2D (x,y lub z,y), z przesunieciem
// zaleznym od tej plaszczyzny i jej kierunku - wiec sasiednie lawospady (rowniez prostopadle) maja rozne wzory,
// a wzor splywa w dol.
void shadeLava(vec3 wp, vec3 Nw, vec3 N, vec3 viewPos, float texLuma, out vec3 color, out float emis)
{
    vec3  aN = abs(Nw);
    vec2  p  = wp.xz;
    if (aN.y < max(aN.x, aN.z))
    {
        bool  xFace = aN.x > aN.z;
        p = xFace ? vec2(wp.z, wp.y) : vec2(wp.x, wp.y);
        float pl = xFace ? floor(wp.x + 0.5) * 2.0 + step(0.0, Nw.x)
                         : floor(wp.z + 0.5) * 2.0 + step(0.0, Nw.z) + 513.0;
        float off = hash11(pl * 0.173 + 3.7) * 61.0 + 1.0;
        p += vec2(off * 7.31, off * 4.17);                       // duze przesuniecie: kazda sciana ma niezalezny wzor
        p.y += frameTimeCounter * 0.30 * LAVA_FLOW_SPEED;                // splywa w dol
    }
    float h = lavaHeat(p, frameTimeCounter, texLuma);

    color = lavaRamp(h) * LAVA_BRIGHTNESS;

    // przy ostrych katach swiatla wiecej (goracy "polysk")
    float fr = pow(1.0 - clamp(dot(N, -normalize(viewPos)), 0.0, 1.0), 3.0);
    color += vec3(1.1, 0.28, 0.03) * fr * 0.35 * clamp(h, 0.0, 1.0) * LAVA_BRIGHTNESS;

    emis = smoothstep(0.10, 0.90, h) * 0.85;       // maska bloomu
}

#endif
