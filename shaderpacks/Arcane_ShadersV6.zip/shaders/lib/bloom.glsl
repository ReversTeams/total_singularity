// =====================================================================
//  lib/bloom.glsl - BLOOM w zredukowanej rozdzielczosci (piramida 1/2 -> 1/4 -> 1/8)
//  Kazdy poziom jest rysowany w lewo-dolnej czesci bufora o rozmiarze floor(res * s),
//  reszta pikseli konczy prace od razu (tanio). Rozmycie = 9-punktowy Gauss liczony
//  5 odczytami (sztuczka z filtrowaniem liniowym).
//    poziom 1 (s = 0.5)   -> colortex5   (waskie halo)
//    poziom 2 (s = 0.25)  -> colortex6   (srednie halo)
//    poziom 3 (s = 0.125) -> colortex4   (szerokie halo)
// =====================================================================
#ifndef BLOOM_GLSL
#define BLOOM_GLSL
#include "/lib/settings.glsl"
// viewWidth / viewHeight pochodza z noise.glsl
#include "/lib/noise.glsl"

#define BLOOM_LV1 0.5
#define BLOOM_LV2 0.25
#define BLOOM_LV3 0.125

vec2 bloomRes()        { return vec2(viewWidth, viewHeight); }
vec2 bloomReg(float s) { return floor(bloomRes() * s); }            // rozmiar poziomu w pikselach

// odczyt z poziomu o skali s; p = wspolrzedne w pikselach regionu (z ucieciem do regionu)
vec3 bloomTap(sampler2D t, vec2 p, float s)
{
    vec2 reg = bloomReg(s);
    p = clamp(p, vec2(0.5), reg - 0.5);
    return texture2D(t, p / bloomRes()).rgb;
}

// ten sam poziom, jeden kierunek (dir = (1,0) lub (0,1)); k = rozstaw probek (1 = co teksel)
vec3 bloomBlur(sampler2D t, vec2 c, vec2 dir, float s, float k)
{
    vec2 o1 = dir * (1.3846153846 * k);
    vec2 o2 = dir * (3.2307692308 * k);
    vec3 sum = bloomTap(t, c, s) * 0.2270270270;
    sum += (bloomTap(t, c + o1, s) + bloomTap(t, c - o1, s)) * 0.3162162162;
    sum += (bloomTap(t, c + o2, s) + bloomTap(t, c - o2, s)) * 0.0702702703;
    return sum;
}

// zmniejszenie 2x z poziomu sS do poziomu sD: 4 odczyty liniowe = okno 4x4 (bez aliasingu)
vec3 bloomDown(sampler2D t, vec2 c, float sD, float sS)
{
    vec2 sp = c / bloomReg(sD) * bloomReg(sS);
    vec3 a = bloomTap(t, sp + vec2(-1.0, -1.0), sS);
    a     += bloomTap(t, sp + vec2( 1.0, -1.0), sS);
    a     += bloomTap(t, sp + vec2(-1.0,  1.0), sS);
    a     += bloomTap(t, sp + vec2( 1.0,  1.0), sS);
    return a * 0.25;
}

// zmniejszenie 2x + rozmycie poziome w jednym przebiegu (poziomy sa male, wiec to tanie)
vec3 bloomDownBlurH(sampler2D t, vec2 c, float sD, float sS, float k)
{
    vec2 o1 = vec2(1.3846153846 * k, 0.0);
    vec2 o2 = vec2(3.2307692308 * k, 0.0);
    vec3 sum = bloomDown(t, c, sD, sS) * 0.2270270270;
    sum += (bloomDown(t, c + o1, sD, sS) + bloomDown(t, c - o1, sD, sS)) * 0.3162162162;
    sum += (bloomDown(t, c + o2, sD, sS) + bloomDown(t, c - o2, sD, sS)) * 0.0702702703;
    return sum;
}

// czy piksel lezy w regionie poziomu s
bool bloomInside(float s)
{
    vec2 reg = bloomReg(s);
    return gl_FragCoord.x < reg.x && gl_FragCoord.y < reg.y;
}

// odczyt w final: uv ekranu -> poziom s (filtrowanie liniowe daje gladkie powiekszenie)
vec3 bloomSample(sampler2D t, vec2 uv, float s)
{
    return bloomTap(t, uv * bloomReg(s), s);
}
#endif
