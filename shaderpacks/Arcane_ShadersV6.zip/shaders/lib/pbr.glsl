// =====================================================================
//  lib/pbr.glsl - wsparcie labPBR (normal mapy + specular z resource packa)
//   normals : rg = normalna XY, b = AO, a = height
//   specular: r = perceptual smoothness, g = F0 (>=230 = metal), a = emisja (255 = brak)
//  Gdy paczka nie ma tekstur _n/_s, wszystko dziala jak zwykly shader.
// =====================================================================
#ifndef PBR_GLSL
#define PBR_GLSL
#include "/lib/common.glsl"

uniform sampler2D normals;
uniform sampler2D specular;

struct PBRData
{
    vec3  N;            // normalna (po normal mapie), przestrzen widoku
    float smoothness;
    vec3  F0;
    float metal;
    float emission;
    float ao;
};

PBRData noPBR(vec3 N)
{
    PBRData p;
    p.N = N; p.smoothness = 0.0; p.F0 = vec3(0.04); p.metal = 0.0; p.emission = 0.0; p.ao = 1.0;
    return p;
}

// dist = odleglosc od kamery. Normal mapa i polysk zanikaja z odlegloscia (pod-pikselowe detale tylko migotaly),
// a daleko normal-mapa nie jest w ogole czytana. Emisja i F0 zostaja - swiecace rudy widac z daleka.
// Metal zanika razem z polyskiem (metal = ciagle 0..1), wiec daleko dostaje zwykle swiatlo rozproszone zamiast byc czarny.
PBRData readPBR(vec2 uv, vec3 Ng, vec3 T, vec3 B, vec3 albedo, float dist)
{
    PBRData p = noPBR(Ng);
#ifdef LABPBR
    float nf = 1.0 - smoothstep(PBR_FADE_NEAR, PBR_FADE_FAR, dist);        // 1 blisko -> 0 daleko
    vec4 st = texture2D(specular, uv);
    // brak tekstury => czarna lub biala probka: ignorujemy
    bool hasS = (st.r + st.g + st.b + st.a) > 0.01 && !(st.r > 0.999 && st.g > 0.999 && st.b > 0.999 && st.a > 0.999);
    if (nf > 0.001)
    {
        vec4 nt = texture2D(normals, uv);
        bool hasN = (nt.r + nt.g + nt.b) > 0.01 && !(nt.r > 0.999 && nt.g > 0.999 && nt.b > 0.999) && dot(T, T) > 0.1;
        if (hasN)
        {
            vec2  xy = (nt.rg * 2.0 - 1.0) * PBR_NORMAL_STRENGTH;
            float z  = sqrt(max(1.0 - dot(xy, xy), 0.0));
            p.N  = normalize(mix(Ng, normalize(T * xy.x + B * xy.y + Ng * z), nf));
            p.ao = mix(1.0, nt.b, nf);
        }
    }
    if (hasS)
    {
        p.smoothness = st.r * nf;
        float g = st.g * 255.0;
        if (g >= 229.5) { p.metal = nf; p.F0 = albedo; }
        else            { p.F0 = vec3(g / 255.0); }
        float a = st.a * 255.0;
        p.emission = (a < 254.5) ? a / 254.0 : 0.0;
    }
#endif
    return p;
}

PBRData readPBR(vec2 uv, vec3 Ng, vec3 T, vec3 B, vec3 albedo)
{
    return readPBR(uv, Ng, T, B, albedo, 0.0);
}

// Odbicia: GGX (slonce/ksiezyc) + odbicie nieba dla gladkich powierzchni
vec3 pbrSpecular(PBRData p, vec3 viewPos, vec3 sunVec, vec3 moonVec, vec3 upVec, vec2 lm, float shadow, float rain)
{
#ifdef LABPBR
    if (p.smoothness < 0.02) return vec3(0.0);
    vec3 V = -normalize(viewPos);
    float NdV = max(dot(p.N, V), 0.001);

    vec3 direct = vec3(0.0);
  #if !defined(DIM_NETHER) && !defined(DIM_END)
    float sunHeight = dot(sunVec, upVec);
    vec3  L  = (dayFactor(sunHeight) > 0.5) ? sunVec : moonVec;
    float rough = max((1.0 - p.smoothness) * (1.0 - p.smoothness), 0.03);
    float a2 = rough * rough * rough * rough;
    vec3  H  = normalize(L + V);
    float NdH = max(dot(p.N, H), 0.0);
    float NdL = max(dot(p.N, L), 0.0);
    float VdH = max(dot(V, H), 0.0);
    float dd = NdH * NdH * (a2 - 1.0) + 1.0;
    float D  = a2 / (3.14159265 * dd * dd);
    float k  = (rough + 1.0) * (rough + 1.0) / 8.0;
    float G  = (NdL / (NdL * (1.0 - k) + k)) * (NdV / (NdV * (1.0 - k) + k));
    vec3  F  = p.F0 + (1.0 - p.F0) * pow(1.0 - VdH, 5.0);
    vec3  spec = min(D * G * F / (4.0 * NdV), vec3(12.0));
    float skyOcc = smoothstep(0.15, 0.60, lm.y);
    direct = spec * getLightColor(sunHeight) * shadow * skyOcc * (1.0 - rain * 0.8);
  #endif

    vec3 R   = reflect(-V, p.N);
    vec3 env = getSkyColor(R, sunVec, moonVec, upVec) * lm.y * lm.y;
    vec3 Fe  = p.F0 + (max(vec3(p.smoothness), p.F0) - p.F0) * pow(1.0 - NdV, 5.0);
    vec3 reflection = env * Fe * p.smoothness * p.smoothness;

    return (direct + reflection) * PBR_SPECULAR;
#else
    return vec3(0.0);
#endif
}
#endif
