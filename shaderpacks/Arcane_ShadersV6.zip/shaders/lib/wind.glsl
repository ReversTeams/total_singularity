// =====================================================================
//  lib/wind.glsl - wspolna funkcja wiatru (gbuffers_terrain / block / shadow)
//  Dzieki temu cienie lisci ruszaja sie dokladnie tak jak same liscie.
//  wp = pozycja w swiecie, weight = waga (0 = nieruchome), t = czas
// =====================================================================
#ifndef WIND_GLSL
#define WIND_GLSL
#include "/lib/settings.glsl"

// dist = odleglosc od kamery, fadeNear/fadeFar = zakres wygaszania wiatru (0 = pelny wiatr, potem plynnie do 0).
// Daleko przesuniecie liscia (ok. 0.1 bloku) jest mniejsze niz piksel, a szybkie drzenie ("flutter")
// jest niewidoczne juz od ok. 30 blokow - wiec dalej nie liczymy ani jednego, ani drugiego.
vec3 windOffset(vec3 wp, float weight, float t, float rain, float dist, float fadeNear, float fadeFar)
{
    float lod = 1.0 - smoothstep(fadeNear, fadeFar, dist);
    if (lod <= 0.0 || weight <= 0.0) return vec3(0.0);
    float storm   = 1.0 + rain * 1.2;                                              // podczas deszczu wiatr mocniejszy
    float gust    = sin(t * 0.7 + dot(wp.xz, vec2(0.12, 0.08))) * 0.5 + 0.5;       // wolne podmuchy 0..1
    float sway    = sin(t * 1.6 + wp.x * 0.55 + wp.z * 0.35 + wp.y * 0.25);        // kolysanie
    float flutter = 0.0;
    if (dist < 40.0)                                                               // drzenie tylko z bliska
        flutter = sin(t * 3.1 + wp.x * 1.90 - wp.z * 1.30 + wp.y * 0.90) * (1.0 - smoothstep(24.0, 40.0, dist));
    float push    = (0.04 + 0.10 * gust) * (0.6 + 0.4 * sway) + 0.025 * flutter;
    float amp     = WAVE_STRENGTH * storm * weight * lod;
    return vec3(0.87 * push * amp, 0.015 * flutter * amp, 0.49 * push * amp);      // kierunek wiatru (0.87, 0.49)
}

// bez wygaszania (zgodnosc wsteczna)
vec3 windOffset(vec3 wp, float weight, float t, float rain)
{
    return windOffset(wp, weight, t, rain, 0.0, 1.0e6, 2.0e6);
}
#endif
