// lib/distort.glsl - deformacja shadow mapy: wiecej rozdzielczosci blisko kamery
#ifndef DISTORT_GLSL
#define DISTORT_GLSL
#include "/lib/settings.glsl"
vec2 distortShadow(vec2 xy)
{
    float d = length(xy);
    float f = (1.0 - SHADOW_DISTORT) + d * SHADOW_DISTORT;
    return xy / f;
}
#endif
