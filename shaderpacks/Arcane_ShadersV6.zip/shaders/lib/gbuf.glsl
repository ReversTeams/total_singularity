// =====================================================================
//  lib/gbuf.glsl - wspolne funkcje G-buffera dla ODROCZONEGO oswietlenia terenu
//  (gbuffers_terrain.fsh zapisuje dane, deferred.fsh liczy swiatlo raz na piksel ekranu)
//
//  Uklad G-buffera dla pikseli terenu (zanim deferred.fsh je zastapi wynikiem):
//    colortex0.rgb = albedo (liniowe)             colortex1.rg = lightmapa (blok, niebo), a = DEFER_MARK
//    colortex2.rgb = normalna geometryczna, a = 1 zwykly blok / 0.6 roslina (SSAO)
//    colortex4     = (pbr.ao, emisja _s, kod materialu)          [R11G11B10F]
//    colortex5     = (normalna po normal-mapie (oktaedr.xy), gladkosc, F0 [<1] albo 1 + ilosc_metalu [>=1])
//  Kod materialu = 1 + klasa_emisji + 6 * rodzaj_roslinnosci  (male liczby calkowite - dokladne w float).
// =====================================================================
#ifndef GBUF_GLSL
#define GBUF_GLSL

#define DEFER_MARK 0.2          // znacznik "ten piksel ma byc oswietlony w deferred" w colortex1.a (51/255)

// normalna jednostkowa <-> 2 liczby 0..1 (oktaedr); dokladnosc 16-bit (colortex5 = RGBA16F)
vec2 octEnc(vec3 n)
{
    n /= max(abs(n.x) + abs(n.y) + abs(n.z), 0.0001);
    vec2 e = n.xy;
    if (n.z < 0.0)
        e = (1.0 - abs(e.yx)) * vec2(n.x >= 0.0 ? 1.0 : -1.0, n.y >= 0.0 ? 1.0 : -1.0);
    return e * 0.5 + 0.5;
}

vec3 octDec(vec2 f)
{
    f = f * 2.0 - 1.0;
    vec3 n = vec3(f, 1.0 - abs(f.x) - abs(f.y));
    float t = max(-n.z, 0.0);
    n.x += n.x >= 0.0 ? -t : t;
    n.y += n.y >= 0.0 ? -t : t;
    return normalize(n);
}
#endif
