// =====================================================================
//  lib/nether.glsl - Nether w stylu fantasy (uzywane tylko z DIM_NETHER, w composite1.fsh)
//   * netherFog      - objetosciowa, wirujaca mgla (szum gradientowy 3D) w kolorze biomu z poswiata lawy
//   * netherEmbers   - swiecace iskry / zarodniki / popiol unoszace sie w powietrzu (3D, w swiecie gry)
//   * netherHeatHaze - drganie powietrza nad lawa (przesuniecie UV)
//  Kolor akcentu biomu: netherAccent() z lib/common.glsl.
// =====================================================================
#ifndef NETHER_GLSL
#define NETHER_GLSL

vec3 nHash3(vec3 p)
{
    p = fract(p * vec3(0.1031, 0.1030, 0.0973));
    p += dot(p, p.yxz + 33.33);
    return fract((p.xxy + p.yxx) * p.zyx);
}

// ---------------------------------------------------------------------
//  Mgla: szum gradientowy 3D (Perlin). Wspolrzedne komorek sa zawijane (mod 256), wiec precyzja nie spada
//  z odlegloscia od zera - stary szum wartosciowy 2D (hash21 na duzych wspolrzednych) dawal blokowe,
//  powtarzalne wzory. Interpolacja quintic = bez widocznych krawedzi komorek.
// ---------------------------------------------------------------------
float gnoise3(vec3 p)
{
    vec3 i  = floor(p);
    vec3 f  = p - i;
    vec3 u  = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
    vec3 i0 = mod(i, 256.0);
    vec3 i1 = mod(i + 1.0, 256.0);
    float n000 = dot(nHash3(vec3(i0.x, i0.y, i0.z)) * 2.0 - 1.0, f - vec3(0.0, 0.0, 0.0));
    float n100 = dot(nHash3(vec3(i1.x, i0.y, i0.z)) * 2.0 - 1.0, f - vec3(1.0, 0.0, 0.0));
    float n010 = dot(nHash3(vec3(i0.x, i1.y, i0.z)) * 2.0 - 1.0, f - vec3(0.0, 1.0, 0.0));
    float n110 = dot(nHash3(vec3(i1.x, i1.y, i0.z)) * 2.0 - 1.0, f - vec3(1.0, 1.0, 0.0));
    float n001 = dot(nHash3(vec3(i0.x, i0.y, i1.z)) * 2.0 - 1.0, f - vec3(0.0, 0.0, 1.0));
    float n101 = dot(nHash3(vec3(i1.x, i0.y, i1.z)) * 2.0 - 1.0, f - vec3(1.0, 0.0, 1.0));
    float n011 = dot(nHash3(vec3(i0.x, i1.y, i1.z)) * 2.0 - 1.0, f - vec3(0.0, 1.0, 1.0));
    float n111 = dot(nHash3(vec3(i1.x, i1.y, i1.z)) * 2.0 - 1.0, f - vec3(1.0, 1.0, 1.0));
    return mix(mix(mix(n000, n100, u.x), mix(n010, n110, u.x), u.y),
               mix(mix(n001, n101, u.x), mix(n011, n111, u.x), u.y), u.z);       // ok. -0.9 .. 0.9
}

// Gestosc mgly w punkcie swiata (0..1, srodek 0.5): dwie oktawy plynace w roznych kierunkach,
// z jednym wolnym znieksztalceniem domeny (warp) na piksel - to daje \"zawijasy\".
float netherFogDensity(vec3 wp, vec3 warp, float t)
{
    vec3 p = wp * 0.036 + warp + vec3(t * 0.022, t * 0.007, -t * 0.017);
    float n = gnoise3(p) * 0.66 + gnoise3(p * 2.13 + vec3(5.3, 1.7, 9.1) - vec3(t * 0.030, 0.0, -t * 0.020)) * 0.34;
    return clamp(n * 0.85 + 0.5, 0.0, 1.0);
}

// Kolor i gestosc mgly liczone WZDLUZ promienia (objetosciowo), a nie w punkcie trafienia - dzieki temu wzor
// nie \"przykleja sie\" do powierzchni jak tekstura i ma poprawny paralaks. dist = dlugosc promienia; dla nieba
// i dla w pelni zamglonego terenu podajemy ten sam dystans (far * DIM_FOG_RANGE), wiec maja identyczny kolor -
// nie ma szwu na horyzoncie, a niebo faluje razem z mgla.
vec3 netherFog(vec3 camPos, vec3 dirW, float dist, float t, vec3 accent, inout float fogAmount)
{
    vec3 mid  = camPos + dirW * dist * 0.5;
    vec3 warp = vec3(gnoise3(mid * 0.012 + vec3(13.1, 0.0, t * 0.010)),
                     gnoise3(mid * 0.012 + vec3(71.7, 9.0, -t * 0.008)),
                     gnoise3(mid * 0.012 + vec3(37.3, 4.0, t * 0.006))) * 1.1;

    float dens = 0.0;
    float lava = 0.0;
    for (int i = 0; i < NETHER_FOG_STEPS; i++)
    {
        float k  = (float(i) + 0.5) / float(NETHER_FOG_STEPS);
        vec3  sp = camPos + dirW * dist * k;
        dens += netherFogDensity(sp, warp, t);
        lava += exp(-max(sp.y - 31.0, 0.0) / 22.0);                          // poziom lawy w Netherze = y 31
    }
    dens /= float(NETHER_FOG_STEPS);
    lava /= float(NETHER_FOG_STEPS);

    float sw    = dens - 0.5;                                               // ok. -0.35 .. 0.35
    vec3  base  = toLinear(fogColor) * 1.2;
    vec3  accL  = toLinear(accent);
    vec3  glowC = mix(accL, vec3(1.0, 0.38, 0.08), 0.45);

    fogAmount *= clamp(1.0 + min(sw, 0.0) * 1.2 * NETHER_FOG_SWIRL, 0.70, 1.0);          // tylko rzedsza w ciemnych wstegach, nigdy gestsza niz bazowa

    vec3 col = base * (1.0 + sw * 1.0 * NETHER_FOG_SWIRL);
    col += accL * smoothstep(0.02, 0.22, sw) * 0.03 * NETHER_FOG_SWIRL;      // jasne \"wstegi\" mgly w kolorze biomu
    col += glowC * lava * (0.06 + 0.03 * sw) * NETHER_LAVA_GLOW;             // poswiata lawy od dolu
    return max(col, vec3(0.0));
}

// Iskry: 3 warstwy komorek 3D (2 / 4 / 8 blokow), w kazdej 6 probek wzdluz promienia (krok = pol komorki).
// Czasteczka lezy w srodku komorki (margines 25%), wiec kazda jest liczona dokladnie raz.
// Unosza sie w gore z delikatnym kolysaniem, migocza, blizej kamery sa wieksze (perspektywa).
vec3 netherEmbers(vec3 dirW, float sceneDist, vec3 camPos, float t, vec3 accent)
{
    vec3 acc = vec3(0.0);
    float prob = clamp(0.38 * NETHER_EMBER_AMOUNT, 0.0, 0.95);
    for (int L = 0; L < 3; L++)
    {
        float fL    = float(L);
        float cell  = L == 0 ? 2.0 : (L == 1 ? 4.0 : 8.0);
        float stepL = cell * 0.5;
        float t0    = L == 0 ? 0.5 : (L == 1 ? 6.5 : 18.5);
        float rise  = 0.45 + 0.12 * fL;                              // bloki / s
        float rad   = cell * 0.0175;
        for (int i = 0; i < 6; i++)
        {
            float ts = t0 + (float(i) + 0.5) * stepL;
            if (ts - stepL * 0.5 > sceneDist) break;                 // dalej juz za sciana
            vec3 P = camPos + dirW * ts - vec3(0.0, rise * t, 0.0);
            vec3 c = floor(P / cell);
            vec3 h = nHash3(c + fL * 17.0);
            if (h.x > prob) continue;
            vec3 h2 = nHash3(c.zxy + 41.7 + fL * 5.3);
            vec3 inner = 0.5 + (h2 - 0.5) * 0.4 + 0.05 * sin(t * (0.7 + h2 * 1.2) + h2 * 40.0);
            vec3 q   = (c + inner) * cell + vec3(0.0, rise * t, 0.0);
            vec3 rel = q - camPos;
            float tq = dot(rel, dirW);
            if (abs(tq - ts) > stepL * 0.5 || tq > sceneDist) continue;
            float v = length(rel - dirW * tq) / (rad * (0.6 + 0.8 * h.y));
            if (v > 5.0) continue;
            float core = exp(-v * v * 1.6);
            float halo = exp(-v * 0.9) * 0.10;
            float tw   = 0.55 + 0.45 * sin(t * (2.0 + h.z * 5.0) + h.y * 50.0);
            float fade = smoothstep(0.7, 2.0, tq) * exp(-tq * 0.035);
            vec3  col  = mix(accent, vec3(1.0, 0.82, 0.50), core * 0.6);
            acc += col * (core * 3.0 + halo) * tw * fade;
        }
    }
    return acc;
}

// Przesuniecie UV (drganie ciepla): najsilniejsze nisko nad lawa, na srednim dystansie
vec2 netherHeatHaze(vec3 wp, float dist, float t)
{
    float band  = exp(-max(wp.y - 31.0, 0.0) / 14.0);
    float distF = smoothstep(6.0, 22.0, dist) * (1.0 - smoothstep(70.0, 120.0, dist));
    float amp   = 0.0016 * NETHER_HEAT_HAZE * band * distF;
    vec2  off;
    off.x = sin(wp.y * 1.7 + t * 2.3 + wp.x * 0.31) + sin(wp.y * 3.1 - t * 1.7 + wp.z * 0.27) * 0.5;
    off.y = sin(wp.x * 0.9 + t * 1.9 + wp.z * 0.7) * 0.25;
    return off * amp;
}

#endif
