// =====================================================================
//  lib/handlight.glsl - swiatlo z trzymanego swiecacego bloku / przedmiotu
//  Gra podaje poziom swiatla przedmiotu w kazdej rece (0-15):
//    heldBlockLightValue = glowna reka, heldBlockLightValue2 = druga reka
//  Kolor zalezy od przedmiotu (item.properties): standardowo cieple swiatlo pochodni.
//  Dolaczac w plikach .fsh (deklaruje uniformy).
// =====================================================================
#ifndef HANDLIGHT_GLSL
#define HANDLIGHT_GLSL
#include "/lib/settings.glsl"

uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
uniform int heldItemId;
uniform int heldItemId2;

vec3 handLightColor(int id)
{
    if (id == 11001) return vec3(0.35, 0.85, 1.05);   // dusze: cyjan
    if (id == 11002) return vec3(1.00, 0.25, 0.18);   // redstone: czerwien
    if (id == 11003) return vec3(0.70, 0.95, 1.00);   // sea lantern / end rod: chlodna biel
    if (id == 11004) return vec3(0.55, 1.00, 0.50);   // verdant froglight: zielen
    if (id == 11005) return vec3(1.00, 0.60, 0.95);   // pearlescent froglight: roz
    return BLOCKLIGHT_COLOR;                          // domyslnie: cieple swiatlo pochodni
}

// Swiatlo punktowe w pozycji gracza. viewPos = pozycja fragmentu w przestrzeni widoku
// (kamera w zerze), n = normalna w przestrzeni widoku. Zwraca swiatlo do pomnozenia przez albedo.
vec3 handLight(vec3 viewPos, vec3 n)
{
#ifdef HAND_LIGHT
    float dist = length(viewPos);
    vec3  toL  = -viewPos / max(dist, 0.001);
    float diff = clamp(dot(n, toL) * 0.7 + 0.3, 0.0, 1.0);
    vec3  acc  = vec3(0.0);

    float v1 = float(heldBlockLightValue);
    if (v1 > 0.5)
    {
        float a = clamp(1.0 - dist / (v1 * HAND_LIGHT_RANGE), 0.0, 1.0);
        acc += handLightColor(heldItemId) * (a * a * v1 / 15.0);
    }
    float v2 = float(heldBlockLightValue2);
    if (v2 > 0.5)
    {
        float a = clamp(1.0 - dist / (v2 * HAND_LIGHT_RANGE), 0.0, 1.0);
        acc += handLightColor(heldItemId2) * (a * a * v2 / 15.0);
    }
    return acc * diff * BLOCKLIGHT_INTENSITY * HAND_LIGHT_INTENSITY * 1.5;
#else
    return vec3(0.0);
#endif
}
#endif
