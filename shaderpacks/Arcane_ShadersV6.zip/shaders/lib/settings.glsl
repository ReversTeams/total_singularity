// =====================================================================
//  FANTASY MAGICAL SHADERS  -  lib/settings.glsl
//  Wszystkie parametry w jednym miejscu. Wartosci z komentarzem [ ... ]
//  pojawiaja sie w grze jako suwaki (Opcje shaderow).
//  Kolory oznaczone (display) sa podawane w przestrzeni "ekranowej"
//  (0-1, gamma) i konwertowane do liniowej w kodzie.
// =====================================================================
#ifndef SETTINGS_GLSL
#define SETTINGS_GLSL

// ----------------------------- OSWIETLENIE ----------------------------
#define SUN_INTENSITY 1.0          // Sila swiatla slonca/ksiezyca [0.5 0.75 1.0 1.25 1.5 2.0]
#define AMBIENT_INTENSITY 1.0      // Sila swiatla otoczenia (cienie) [0.5 0.75 1.0 1.25 1.5 2.0]
#define BLOCKLIGHT_INTENSITY 1.0   // Sila swiatla pochodni itp. [0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define EMISSIVE_BRIGHTNESS 2.0    // Jasnosc swiecacych blokow (aura) [0.5 1.0 1.5 2.0 2.5 3.0 4.0]
#define BLOCKLIGHT_FALLOFF 3.0     // Im wyzej tym krotszy zasieg swiatla pochodni
#define TORCH_FLICKER 0.5          // Migotanie swiatla pochodni [0.0 0.25 0.5 0.75 1.0]
#define LIGHT_WRAP 0.25            // Miekkosc cieniowania (0 = twardy, 0.5 = bardzo miekki)

// Kolory swiatla (LINIOWE, zawieraja juz intensywnosc)
#define SOUL_EMISSIVE_COLOR vec3(0.35, 0.85, 1.05)  // cyanowa poswiata ognia dusz
#define MIN_LIGHT vec3(0.020, 0.018, 0.035)      // minimalne oswietlenie (lekko fioletowe)

// ------------------------------- NIEBO --------------------------------
// (display) kolory nieba
#define SUN_GLOW_COLOR    vec3(1.0, 0.72, 0.38)
#define MOON_GLOW_COLOR   vec3(0.35, 0.30, 0.70)

#define SUN_BRIGHTNESS 3.0         // Jasnosc tarczy slonca (HDR, napedza bloom)
#define MOON_BRIGHTNESS 1.6

#define STAR_BRIGHTNESS 2.0        // Jasnosc gwiazd [0.0 0.5 1.0 1.5 2.0 3.0 4.0]
#define STAR_DENSITY 60.0          // Rozmiar siatki gwiazd (wiecej = drobniejsze gwiazdy)
#define STAR_AMOUNT 0.15           // Ile komorek zawiera gwiazde (0-1)

// -------------------------------- MGLA --------------------------------
#define FOG                        // Wlacz mgle
#define FOG_DENSITY 1.0            // Gestosc mgly [0.0 0.5 0.75 1.0 1.5 2.0 3.0]
#define FOG_DISTANCE 0             // Odleglosc mgly w blokach, 0 = automatycznie z 'far' [0 96 128 192 256 384 512]
#define CLOUD_STYLE 5              // Styl chmur: 0 plaskie (oryginal), 1 objetosciowe nad plaszczyzna z gry, 2 szum 3D, 3 poduszki (zaokraglone bloki), 4 vanilla (ostre bloki, plaskie sciany), 5 miekkie bloki (kopulaste, zlane, jak w Reimagined) [0 1 2 3 4 5]
#define CLOUD_TAA                  // Akumulacja czasowa chmur: wygladza krawedzie i usuwa ziarno (jitter + historia klatek, tylko chmury)
#define FXAA                       // FXAA: wygladzanie krawedzi calego obrazu (lekko mekszy obraz; wylacz, jesli tekstury sa za miekkie)
#define CLOUD_HEIGHT 192.0         // Styl 2 i 3: wysokosc podstawy chmur (Y swiata) [128.0 160.0 192.0 224.0 256.0]
#define CLOUD_DEPTH 48.0           // Styl 2: grubosc warstwy chmur w blokach [24.0 36.0 48.0 64.0 80.0]
#define CLOUD_COVERAGE 1.0         // Styl 2 i 3: ile nieba pokrywaja chmury [0.6 0.8 1.0 1.2 1.4]
#define CLOUD_QUALITY 12           // Styl 2 i 3: maksymalna liczba krokow ray-marchingu (jakosc / FPS) [6 8 12 16 24 32]
#define CLOUD_THICKNESS 14.0       // Styl 1 i 3: grubosc chmur (blokow) [8.0 11.0 14.0 18.0 24.0]
#define CLOUD_BTHICK 10.0          // Styl 5 (Miekkie bloki): grubosc chmur w blokach [6.0 8.0 10.0 14.0 18.0]
#define CLOUD_BROUND 0.20          // Styl 5: zaokraglenie granic komorek (male = ostre bloki, duze = bardzo miekkie) [0.08 0.14 0.20 0.30 0.42]
#define CLOUD_VTHICK 5.0           // Styl 4 (Vanilla): grubosc chmur w blokach (vanilla = 4) [3.0 4.0 5.0 6.0 8.0]
#define CLOUD_CELL 12.0            // Styl 3: rozmiar komorki siatki w blokach (12 = jak vanilla) [8.0 12.0 16.0 24.0]
#define CLOUD_ROUNDNESS 0.65       // Styl 3: zaokraglenie blokow (0.2 prawie kanciaste, 1.0 maksymalnie okragle) [0.2 0.4 0.65 0.8 1.0]
#define CLOUD_MERGE 0.7            // Styl 3: laczenie blokow w jedna chmure (niskie = widac kostki, wysokie = jedna puchata masa) [0.22 0.45 0.7 0.9]
#define CLOUD_SOFTNESS 2.4         // Styl 3: miekkosc krawedzi w blokach (wyzej = bardziej puchate, mgliste brzegi) [1.0 1.6 2.4 3.2 4.5]
#define CLOUD_DENSITY 1.0          // Gestosc chmur (styl 1 i 2): wyzej = bardziej zbite, ciemniejsze spody [0.6 0.8 1.0 1.25 1.5]
#define CLOUD_VOLUME_STEPS 8       // Styl 1: kroki w chmurze [4 6 8 12]
#define CLOUD_SILVER_ON            // Srebrna obwodka chmur
#define CLOUD_SILVER 1.0           // Sila srebrnej obwodki [0.0 0.5 1.0 1.5 2.0]
#define CLOUD_SHADING              // Cieniowanie chmur: zacienione spody i krawedzie, jasne strony zwrocone do slonca
#define CLOUD_SHADING_STRENGTH 1.0 // Sila cieniowania chmur [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define CLOUD_SHADING_STEPS 4      // Probki w strone slonca (jakosc) [2 3 4 6 8]
//#define CLOUD_LIGHT_FLIP         // Ukryte: odwroc kierunek cienia, jesli wersja MC mapuje tekstury chmur odwrotnie
#define CLOUD_SHAFTS               // Promienie swiatla przechodza przez luki w chmurach (wymaga GODRAYS)
#define CLOUD_SHADOWS              // Cienie chmur na ziemi: chmury zaslaniaja slonce / ksiezyc, a ich cien dryfuje po krajobrazie (styl chmur 2-5; dziala tez poza zasiegiem shadow mapy)
#define CLOUD_SHADOW_STRENGTH 0.8  // Jak ciemny jest cien pod gruba chmura (0.8 = zostaje ok. 20% swiatla bezposredniego; otoczenie nie ciemnieje) [0.3 0.5 0.65 0.8 0.9 1.0]
#define CLOUD_SHADOW_QUALITY 3     // Probki przez warstwe chmur (jakosc krawedzi cienia / FPS) [2 3 4]
#define FOG_HEIGHT_BASE 64.0       // Ponizej tej wysokosci mgla jest pelna
#define FOG_HEIGHT_FALLOFF 0.012   // Jak szybko mgla rzednie wraz z wysokoscia
#define UNDERWATER_FOG_DENSITY 0.07

// -------------------------------- WODA --------------------------------
#define WATER_ABSORPTION 0.15      // Metnosc wody: im wiecej, tym szybciej gasnie dno [0.05 0.10 0.15 0.25 0.40]
#define WATER_WAVE_HEIGHT 1.0      // Wysokosc fal (geometria) [0.0 0.5 1.0 1.5 2.0]
#define WATER_WAVE_SPEED 1.0       // Szybkosc fal [0.25 0.5 1.0 1.5 2.0]
#define WATER_NORMAL_STRENGTH 0.30 // Sila zmarszczek (odbicia) [0.0 0.15 0.30 0.50 0.80]
#define WATER_REFLECTION 1.0       // Sila odbic nieba [0.0 0.5 0.75 1.0 1.25]
#define WATER_GLINT 3.0            // Blyski slonca na wodzie [0.0 1.5 3.0 5.0]
#define WATER_REFRACTION 0.5       // Zalamanie swiatla - dno faluje pod woda [0.0 0.5 1.0 1.5 2.0]
#define WATER_CAUSTICS 0.8         // Kaustyka (siatka swiatla) na dnie [0.0 0.4 0.8 1.2 1.6]
#define WATER_FOAM 1.0             // Piana i poswiata przy brzegu [0.0 0.5 1.0 1.5]
#define WATER_SPARKLES 0.0         // Magiczne iskry na tafli [0.0 0.5 1.0 1.5 2.0]
#define WATER_SKY_FX               // Woda odbija gwiazdy, zorze i mglawice
#define WATER_MODE 0               // Tryb wody: 0 Auto (zgodnosc na MC 26+), 1 Krysztalowa (nowa), 2 Zgodnosci (prosta, klasyczna) [0 1 2]
// Auto: nowa woda dziala w 1.16.5-1.21.x; w nowszych wersjach (MC_VERSION >= 200000, np. 26.1 = 260100) wybierana jest prosta woda.
// WATER_USE_COMPAT ma wartosc, wiec nie jest pokazywany jako opcja w menu.
#if WATER_MODE == 2
  #define WATER_USE_COMPAT 1
#elif WATER_MODE == 0 && defined(MC_VERSION)
  #if MC_VERSION >= 200000
    #define WATER_USE_COMPAT 1
  #endif
#endif

// -------------------------------- DESZCZ ------------------------------
// v24: deszcz / snieg rysowany do osobnej warstwy (colortex7) i doklejany w composite1 PO mgle i wodzie.
#define FANTASY_RAIN               // Nowy deszcz / snieg: warstwa po mgle i wodzie, miekkie swietliste smugi. Wylacz = klasyczny (stary) deszcz
#define RAIN_OVERCAST 1.0          // Jak mocno deszcz zachmurza i przyciemnia niebo i mgle (0 = jak dawniej, lekko) [0.0 0.5 0.75 1.0 1.25 1.5]
#define RAIN_DENSITY 0.5           // Ile smug deszczu / platkow zostaje (1 = tyle co w vanilla, mniej = rzadszy deszcz) [0.15 0.25 0.35 0.5 0.7 1.0]
#define RAIN_OPACITY 1.0           // Widocznosc smug deszczu / platkow [0.25 0.5 0.75 1.0 1.25 1.5]
#define RAIN_BRIGHTNESS 1.0        // Jasnosc smug [0.5 0.75 1.0 1.25 1.5 2.0]
#define RAIN_MAGIC 1.0             // Magiczny wyglad: perlowy odcien, nocna poswiata, rzadkie blyski (0 = realistyczny) [0.0 0.5 1.0 1.5 2.0]
#define RAIN_SLANT 0.12            // Pochylenie smug przez wiatr (0 = pionowy deszcz) [0.0 0.06 0.12 0.2 0.3]
#define RAIN_RIPPLES               // Kregi na wodzie podczas deszczu
#define RAIN_RIPPLE_STRENGTH 1.0   // Wyrazistosc kregow na wodzie [0.5 0.75 1.0 1.5 2.0]

// ------------------------------ ROSLINNOSC ----------------------------
#define WAVING_FOLIAGE             // Machanie lisci i trawy
#define WAVE_STRENGTH 1.0          // Sila wiatru [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define WAVE_SPEED 1.0             // Szybkosc wiatru [0.5 0.75 1.0 1.5 2.0]
#define WIND_FADE_NEAR 64.0        // Wiatr na lisciach/trawie zanika od tej odleglosci (bloki)...
#define WIND_FADE_FAR 96.0         // ...i znika calkiem (przesuniecie mniejsze niz piksel)
#define WIND_SHADOW_FADE_NEAR 40.0 // W shadow mapie wiatr zanika wczesniej (przesuniecie < 1 teksel mapy)
#define WIND_SHADOW_FADE_FAR 60.0

// --------------------------- BLOOM / GOD RAYS -------------------------
#define BLOOM                      // Poswiata swiecacych blokow
#define BLOOM_STRENGTH 0.75         // Sila bloomu [0.25 0.5 0.75 1.0 1.5 2.0 3.0]
#define BLOOM_RADIUS 3.0           // Promien rozmycia (skaluje rozstaw probek na kazdym poziomie) [1.5 2.0 3.0 4.0 5.0]
#define BLOOM_WIDE 0.5             // Szerokie halo bloomu (0 = wylaczone) [0.0 0.5 1.0 1.5 2.0 3.0]
#define BLOOM_THRESHOLD 1.4        // Prog jasnosci dla bloomu od slonca/jasnych powierzchni [0.8 1.0 1.4 2.0 3.0]

#define GODRAYS                    // Promienie swiatla
#define GODRAYS_STRENGTH 0.45      // Sila promieni [0.1 0.25 0.45 0.7 1.0 1.5]
#define GODRAYS_LENGTH 0.9         // Dlugosc promieni (ulamek ekranu) [0.5 0.7 0.9 1.0]
#define GODRAYS_SAMPLES 12         // Liczba probek (jakosc / wydajnosc) [8 12 16 24 32]
#define GODRAYS_DECAY 0.90         // Zanik promieni wzdluz drogi
#define GODRAYS_FOCUS 8.0          // Im wiecej tym promienie widoczne tylko patrzac w strone slonca

// ------------------------------ POST-PROCESS --------------------------
#define EXPOSURE 1.0               // Ekspozycja [0.6 0.8 1.0 1.2 1.4 1.6]
#define VIBRANCE 0.35              // Vibrance - podbija tylko blade kolory [0.0 0.15 0.25 0.35 0.5 0.75 1.0]
#define SATURATION 1.05            // Globalne nasycenie [0.8 0.9 1.0 1.05 1.1 1.2 1.3]
#define SPLIT_TONING               // Fioletowe cienie, zlote swiatla
#define VIGNETTE                   // Winieta
#define VIGNETTE_STRENGTH 0.35     // Sila winiety [0.1 0.2 0.35 0.5 0.7]
#define VIGNETTE_POWER 0.30        // Im mniej tym winieta siega dalej do srodka


// ------------------------------- CIENIE -------------------------------
#define DEFERRED_LIGHTING          // Swiatlo terenu liczone raz na piksel ekranu (mniej pracy w lisciach/trawie). Wylacz = klasyczny tryb
#define SHADOWS                    // Prawdziwe cienie (shadow map)
#define SHADOW_SOFTNESS 1.5        // Miekkosc krawedzi cieni (teksele) [1.0 1.5 2.0 3.0 4.0]
#define HW_SHADOW_FILTER           // Sprzetowe filtrowanie cieni: 1 odczyt = porownanie 2x2 tekseli. Mniej odczytow przy tej samej miekkosci. Wylacz przy bledach cieni
#ifdef HW_SHADOW_FILTER
const bool shadowHardwareFiltering = true;   // Iris/OptiFine: shadowtex1 jako sampler2DShadow z filtrowaniem liniowym
#endif
#define SHADOW_SAMPLES 8           // Probki filtra cieni (jakosc / wydajnosc) [4 6 8 12 16]
#define SHADOW_DISTORT 0.85        // Ostrzejsze cienie blisko gracza [0.6 0.7 0.85 0.9]
// Te stale czyta sam Iris/OptiFine (suwaki w menu)
const int   shadowMapResolution = 2048;  // [1024 2048 3072 4096]
const float shadowDistance      = 96.0;  // [56.0 64.0 72.0 96.0 128.0 160.0 192.0 216.0]
const float sunPathRotation     = -20.0; // [-40.0 -30.0 -20.0 -10.0 0.0 10.0 20.0 30.0]
// Iris/OptiFine: przebieg cieni rysuje TYLKO geometrie w zasiegu shadowDistance od kamery.
// Domyslnie (-1) gra rysowala do shadow mapy caly teren az do granicy renderowania, ktory mogl rzucac cien
// w strone kamery - najwiecej, gdy stoimy TYLEM do slonca (wtedy caly widoczny teren lezy "pod sloncem").
// To byl glowny powod spadku FPS przy patrzeniu w strone przeciwna do slonca.
const float shadowDistanceRenderMul = 1.0;  // [-1.0 0.75 1.0 1.25 1.5 2.0]


// -------------------------------- SSAO --------------------------------
#define SSAO                       // Ambient occlusion w przestrzeni ekranu (polowa rozdzielczosci)
#define SSAO_STRENGTH 0.8          // Sila zaciemnienia naroznikow [0.3 0.5 0.8 1.0]
#define SSAO_RADIUS 1.2            // Promien w blokach [0.6 1.0 1.2 1.6 2.0]
#define SSAO_SAMPLES 8             // Probki (jakosc / wydajnosc) [4 6 8 12 16]

// ------------------------- labPBR (resource pack) ---------------------
#define LABPBR                     // Normal mapy + specular z paczek tekstur labPBR (bez paczki nic nie zmienia)
#define PBR_NORMAL_STRENGTH 1.0    // Sila normal map [0.0 0.5 1.0 1.5]
#define PBR_SPECULAR 1.0           // Sila odbic / blyskow [0.0 0.5 1.0 1.5 2.0]
#define PBR_FADE_NEAR 32.0         // Normal mapy i polysk zaczynaja zanikac od tej odleglosci (bloki)
#define PBR_FADE_FAR 56.0          // ...i znikaja calkiem (emisja i kolor zostaja). Mniej odczytow tekstur daleko
#define PBR_EMISSION 1.0           // Sila emisji z tekstur [0.0 0.5 1.0 1.5 2.0]

// ----------------------------- WYMIARY (Nether / End) -----------------
#define NETHER_AMBIENT vec3(0.50, 0.24, 0.18)    // czerwonawe swiatlo otoczenia
#define NETHER_EMISSIVE_BOOST 1.3                // mocniejsza lawa i swiecace bloki
#define FANTASY_LAVA               // Lawa: pikselowana, glebsze kolory (szkarlat -> pomarancz -> zloto), powoli plynace plamy
#define LAVA_BRIGHTNESS 1.0        // Jasnosc lawy [0.5 0.75 1.0 1.25 1.5 2.0]
#define LAVA_CRUST 0.3             // Kontrast plam: ciemniejsze czerwone plamy (0 = rowna lawa, 1 = mocny kontrast) [0.0 0.25 0.3 0.5 0.75 1.0]
#define LAVA_FLOW_SPEED 1.0        // Szybkosc plyniecia plam [0.0 0.5 1.0 1.5 2.0]
#define LAVA_WAVES                 // Delikatne falowanie powierzchni lawy
#define LAVA_WAVE_HEIGHT 1.0       // Wysokosc fal lawy [0.5 1.0 1.5 2.0]
#define NETHER_EMBERS              // Nether: unoszace sie zarzace iskry / zarodniki / popiol (kolor zalezy od biomu)
#define NETHER_EMBER_AMOUNT 1.0    // Ilosc iskier [0.0 0.5 1.0 1.5 2.0 3.0]
#define NETHER_FOG_AMOUNT 0.75     // Gestosc mgly w Netherze: mniej = dalej widac [0.25 0.5 0.75 1.0 1.5]
#define NETHER_FOG_SWIRL 1.0       // Wirujaca, falujaca mgla; 0 = rowna mgla [0.0 0.5 1.0 1.5 2.0]
#define NETHER_FOG_STEPS 3         // Jakosc mgly: probek szumu wzdluz promienia [2 3 4 6]
#define NETHER_LAVA_GLOW 1.0       // Poswiata lawy w mgle na dolnych poziomach [0.0 0.5 1.0 1.5 2.0]
#define NETHER_HEAT_HAZE 1.0       // Drganie powietrza nad lawa [0.0 0.5 1.0 1.5 2.0]
#define NETHER_BIOME_TINT 1.0      // Barwa swiatla i iskier zalezna od biomu [0.0 0.5 1.0 1.5 2.0]
#define END_AMBIENT    vec3(0.20, 0.15, 0.34)    // fioletowe swiatlo
#define END_EMISSIVE_BOOST 1.5
#define END_SKY_COLOR  vec3(0.030, 0.012, 0.085) // (display) ciemny fiolet
#define END_STYLE 0                // Styl nieba Endu: 0 Fioletowa Pustka, 1 Szkarlatna Szczelina, 2 Szmaragdowa Otchlan [0 1 2]
#define END_NEBULA 1.0             // Jasnosc mglawicy w Endzie [0.0 0.5 1.0 1.5 2.0]
#define END_STARS 1.0              // Jasnosc gwiazd w Endzie [0.0 0.5 1.0 1.5 2.0]
#define END_VOID_MOON              // Pusty Ksiezyc na niebie Endu
#define END_AO 1.5                 // Sila ambient occlusion w Endzie: ciemniejsze, glebsze zakamarki, 0 = jak w Overworld [0.0 0.5 1.0 1.5 2.0]
#define END_DEPTH 1.0              // Glebia Endu: wyzsza winieta i ciemniejsze krawedzie ekranu, 0 = wylaczone [0.0 0.5 1.0 1.5]
#define END_GLOW 0.5               // Poswiata blokow Endu: chorus, purpur, ametyst, portal, krysztal [0.0 0.5 1.0 1.5 2.0]
#define DIM_FOG_RANGE 0.55                       // zasieg mgly w Nether/End jako ulamek 'far'
#define DIM_FOG_DENSITY 1.3

// ------------------------------ NOC ------------------------------------
#define NIGHT_BRIGHTNESS 0.70      // Jasnosc nocy (swiatlo ksiezyca, cienie, niebo) [0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2]

// ---------------------------- PALETA KOLOROW ---------------------------
// 0 Fantasy Gold (domyslna) | 1 Emerald Forest | 2 Amethyst Dream | 3 Rose Sunset | 4 Frost | 5 Custom (suwaki ponizej)
#define PALETTE 0 // [0 1 2 3 4 5]

// Paleta "Custom": kolory jako H (odcien 0-350), S (nasycenie), V (jasnosc).
// Dzialaja tylko gdy PALETTE = 5. Wartosci startowe odpowiadaja palecie Fantasy Gold.
#define CUSTOM_SKYTOP_H 220 // [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200 210 220 230 240 250 260 270 280 290 300 310 320 330 340 350]
#define CUSTOM_SKYTOP_S 0.75 // [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1]
#define CUSTOM_SKYTOP_V 0.85 // [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1]
#define CUSTOM_SKYHOR_H 40 // [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200 210 220 230 240 250 260 270 280 290 300 310 320 330 340 350]
#define CUSTOM_SKYHOR_S 0.2 // [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1]
#define CUSTOM_SKYHOR_V 0.85 // [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1]
#define CUSTOM_SUNSET_H 30 // [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200 210 220 230 240 250 260 270 280 290 300 310 320 330 340 350]
#define CUSTOM_SUNSET_S 0.7 // [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1]
#define CUSTOM_SUNSET_V 1 // [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1]
#define CUSTOM_NIGHTTOP_H 240 // [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200 210 220 230 240 250 260 270 280 290 300 310 320 330 340 350]
#define CUSTOM_NIGHTTOP_S 0.85 // [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1]
#define CUSTOM_NIGHTTOP_V 0.14 // [0 0.02 0.04 0.06 0.08 0.1 0.12 0.14 0.16 0.18 0.2 0.22 0.24 0.26 0.28 0.3 0.32 0.34 0.36 0.38 0.4]
#define CUSTOM_NIGHTHOR_H 250 // [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200 210 220 230 240 250 260 270 280 290 300 310 320 330 340 350]
#define CUSTOM_NIGHTHOR_S 0.75 // [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1]
#define CUSTOM_NIGHTHOR_V 0.26 // [0 0.02 0.04 0.06 0.08 0.1 0.12 0.14 0.16 0.18 0.2 0.22 0.24 0.26 0.28 0.3 0.32 0.34 0.36 0.38 0.4]
#define CUSTOM_SUNLIGHT_H 40 // [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200 210 220 230 240 250 260 270 280 290 300 310 320 330 340 350]
#define CUSTOM_SUNLIGHT_S 0.45 // [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1]
#define CUSTOM_MOONLIGHT_H 230 // [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200 210 220 230 240 250 260 270 280 290 300 310 320 330 340 350]
#define CUSTOM_MOONLIGHT_S 0.7 // [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1]
#define CUSTOM_TORCH_H 30 // [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200 210 220 230 240 250 260 270 280 290 300 310 320 330 340 350]
#define CUSTOM_TORCH_S 0.75 // [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1]
#define CUSTOM_WATER_H 170 // [0 10 20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 180 190 200 210 220 230 240 250 260 270 280 290 300 310 320 330 340 350]
#define CUSTOM_WATER_S 0.85 // [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1]
#define CUSTOM_WATER_V 0.7 // [0 0.05 0.1 0.15 0.2 0.25 0.3 0.35 0.4 0.45 0.5 0.55 0.6 0.65 0.7 0.75 0.8 0.85 0.9 0.95 1]
#include "/lib/palette.glsl"

// ------------------------ MAGICZNE NIEBO (noc) ------------------------
#define AURORA                     // Zorza polarna na nocnym niebie
#define AURORA_STRENGTH 0.8        // Jasnosc zorzy [0.3 0.5 0.8 1.0 1.5 2.0]
#define AURORA_STYLE 0             // Kolory zorzy: 0 zielono-fioletowa, 1 turkusowo-niebieska, 2 rozowo-fioletowa, 3 zlota [0 1 2 3]
#define NEBULA                     // Delikatna mgławica miedzy gwiazdami
#define NEBULA_STRENGTH 1.0        // Jasnosc mgławicy [0.5 1.0 1.5 2.0]
#define SHOOTING_STARS             // Spadajace gwiazdy

#if AURORA_STYLE == 0
    #define AURORA_LOW  vec3(0.12, 1.00, 0.50)
    #define AURORA_HIGH vec3(0.55, 0.28, 1.00)
#elif AURORA_STYLE == 1
    #define AURORA_LOW  vec3(0.10, 0.90, 0.85)
    #define AURORA_HIGH vec3(0.20, 0.45, 1.00)
#elif AURORA_STYLE == 2
    #define AURORA_LOW  vec3(1.00, 0.35, 0.75)
    #define AURORA_HIGH vec3(0.50, 0.25, 1.00)
#else
    #define AURORA_LOW  vec3(0.55, 1.00, 0.30)
    #define AURORA_HIGH vec3(1.00, 0.75, 0.20)
#endif

// ------------------------------ ROSLINNOSC+ ---------------------------
#define FOLIAGE_SSS                // Swiatlo prześwitujace przez liscie i trawe (patrzac pod slonce)
#define FOLIAGE_SSS_STRENGTH 0.6   // Sila prześwitywania [0.2 0.4 0.6 0.8 1.0 1.5]
#define FOLIAGE_VARIATION 0.6      // Zmiennosc koloru lak i lasow (zlote / szmaragdowe plamy) [0.0 0.3 0.6 1.0 1.5]
#define FOLIAGE_SHADE 0.8          // Przyciemnienie podstawy traw przy ziemi [0.0 0.4 0.8 1.0]
#define PLANT_SHADOWS              // Trawa, kwiaty i uprawy rzucaja cienie
#define PLANT_SHADOW_STRENGTH 0.7  // Sila cieni na roslinach i od roslin [0.3 0.5 0.7 0.85 1.0]

// ------------------------------ MOTION BLUR ---------------------------
//#define MOTION_BLUR              // Rozmycie ruchu przy obracaniu kamery / poruszaniu sie
#define MOTION_BLUR_STRENGTH 0.5   // Sila rozmycia (0.5 = migawka 180 stopni) [0.2 0.35 0.5 0.75 1.0]
#define MOTION_BLUR_SAMPLES 8      // Probki rozmycia [4 6 8 12 16]

// ------------------------- SWIATLO Z RAK (dynamiczne) ------------------
#define HAND_LIGHT                 // Swiecacy blok / przedmiot w rece (obu) oswietla otoczenie
#define HAND_LIGHT_INTENSITY 1.0   // Sila swiatla z reki [0.5 0.75 1.0 1.5 2.0]
#define HAND_LIGHT_RANGE 0.6       // Zasieg: poziom swiatla x ta wartosc = bloki (pochodnia 14 -> ok. 8 blokow) [0.3 0.45 0.6 0.8 1.0]

#endif
