// =====================================================================
//  lib/common.glsl - wspolne funkcje: pory dnia, kolor nieba, oswietlenie
//  Uwaga: kolory ze settings.glsl oznaczone (display) sa konwertowane
//  do przestrzeni liniowej tutaj (toLinear). Caly pipeline HDR jest liniowy,
//  gamma wraca dopiero w final.fsh.
// =====================================================================
#ifndef COMMON_GLSL
#define COMMON_GLSL
#include "/lib/settings.glsl"

uniform float frameTimeCounter;   // do migotania pochodni
uniform vec3  fogColor;           // kolor mgly z gry (w Netherze zalezy od biomu - patrz netherAccent)

// HSV -> RGB (h w zakresie 0-1) - uzywane przez paleta "Custom"
vec3 hsv2rgb(float h, float s, float v)
{
    vec3 k = clamp(abs(mod(h * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0);
    return v * mix(vec3(1.0), k, s);
}

float luma(vec3 c)      { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }
vec3  toLinear(vec3 c)  { return pow(max(c, vec3(0.0)), vec3(2.2)); }

// sunHeight = dot(kierunek slonca, kierunek "w gore") w przestrzeni widoku: -1..1
float dayFactor(float sunHeight)    { return smoothstep(-0.14, 0.14, sunHeight); }           // 0 noc, 1 dzien
float goldenFactor(float sunHeight) { return 1.0 - smoothstep(0.0, 0.5, max(sunHeight, 0.0)); } // 1 przy horyzoncie

// ---------------------------------------------------------------------
//  Gradient nieba. h = wysokosc kierunku nad horyzontem (0-1)
// ---------------------------------------------------------------------
vec3 skyGradientOverworld(float h, float sunDot, float moonDot, float sunHeight)
{
    float day  = dayFactor(sunHeight);
    float gold = goldenFactor(sunHeight);
    float hz   = pow(1.0 - clamp(h, 0.0, 1.0), 3.0);      // 1 = horyzont, 0 = zenit

    // dzien (przechodzi w zloto rano/wieczorem)
    vec3 zenDay = mix(SKY_DAY_ZENITH,  SKY_GOLD_ZENITH,  gold);
    vec3 horDay = mix(SKY_DAY_HORIZON, SKY_GOLD_HORIZON, gold);
    vec3 dayCol = mix(zenDay, horDay, hz);
    dayCol += SUN_GLOW_COLOR * pow(max(sunDot, 0.0), 6.0) * (0.10 + 0.45 * gold) * (0.4 + 0.6 * hz);

    // noc: granat -> fiolet przy horyzoncie + poswiata ksiezyca
    vec3 nightCol = mix(SKY_NIGHT_ZENITH, SKY_NIGHT_HORIZON, hz);
    nightCol += MOON_GLOW_COLOR * pow(max(moonDot, 0.0), 10.0) * 0.30;
    nightCol *= mix(1.0, NIGHT_BRIGHTNESS, 0.6);                 // ciemniejsze nocne niebo i mgla

    vec3 col = mix(nightCol, dayCol, day);

    // zorza po zachodzie / przed switem (fiolet -> pomarancz)
    float tw = smoothstep(-0.30, -0.02, sunHeight) * (1.0 - day);
    vec3 afterglow = mix(vec3(0.65, 0.28, 0.45), vec3(1.0, 0.45, 0.25), smoothstep(-0.2, 0.0, sunHeight));
    col += afterglow * pow(max(sunDot, 0.0), 2.5) * hz * tw * 0.5;

    return toLinear(col);
}

// Wymiary: Nether / End maja stale kolory "nieba" (uzywane m.in. w odbiciach wody)
vec3 skyGradient(float h, float sunDot, float moonDot, float sunHeight)
{
#if defined(DIM_NETHER)
    return toLinear(vec3(0.40, 0.10, 0.06));
#elif defined(DIM_END)
    return toLinear(END_SKY_COLOR * 2.0 + vec3(0.04, 0.0, 0.08) * pow(1.0 - clamp(h, 0.0, 1.0), 2.0));
#else
    return skyGradientOverworld(h, sunDot, moonDot, sunHeight);
#endif
}

vec3 getSkyColor(vec3 dir, vec3 sunVec, vec3 moonVec, vec3 upVec)
{
    return skyGradient(dot(dir, upVec), dot(dir, sunVec), dot(dir, moonVec), dot(sunVec, upVec));
}


// ---------------------------------------------------------------------
//  NETHER: kolor akcentu biomu wyliczony z fogColor (bez uniformu biomu - dziala wszedzie).
//  Nether Wastes / Crimson Forest (czerwona mgla) -> ognista pomaranczowa iskra
//  Warped Forest (fioletowa mgla)                 -> turkusowe zarodniki (kontrast z fioletem)
//  Soul Sand Valley (cyjanowa mgla)               -> blekitne dusze
//  Basalt Deltas (szaro-fioletowa mgla)           -> jasny, lawendowy popiol
//  Biomy plynnie sie mieszaja, bo fogColor w grze tez jest plynnie mieszany.
// ---------------------------------------------------------------------
vec3 netherAccent()
{
    vec3  n = fogColor / max(max(fogColor.r, fogColor.g), max(fogColor.b, 0.001));
    float sat   = 1.0 - min(n.r, min(n.g, n.b));
    float wRed  = clamp((n.r - max(n.g, n.b)) * 2.0, 0.0, 1.0) * smoothstep(0.15, 0.4, sat);
    float wWarp = smoothstep(0.5, 0.8, n.b) * smoothstep(0.5, 0.8, n.r) * (1.0 - smoothstep(0.35, 0.6, n.g)) * smoothstep(0.15, 0.4, sat);
    float wSoul = smoothstep(0.2, 0.5, (n.g + n.b) * 0.5 - n.r) * smoothstep(0.15, 0.4, sat);
    float wAsh  = 1.0 - smoothstep(0.15, 0.4, sat);
    float ws    = wRed + wWarp + wSoul + wAsh;
    vec3  a = vec3(1.00, 0.42, 0.10) * wRed
            + vec3(0.10, 0.95, 0.80) * wWarp
            + vec3(0.30, 0.85, 1.00) * wSoul
            + vec3(0.85, 0.80, 1.00) * wAsh;
    return ws > 0.001 ? a / ws : vec3(1.00, 0.42, 0.10);
}

// deszcz: zachmurzone, szaro-granatowe i wyraznie ciemniejsze niebo i mgla (v24.3; RAIN_OVERCAST skaluje sile).
// Ta sama funkcja kolorzy niebo, mgle i smugi deszczu, wiec wszystko do siebie pasuje.
vec3 applyRainToSky(vec3 c, float rain)
{
    float k = clamp(rain * 0.9 * RAIN_OVERCAST, 0.0, 1.0);
    vec3 grey = vec3(luma(c)) * vec3(0.92, 0.97, 1.06) * 0.46;
    return mix(c, grey, k);
}

// Kolor swiatla (uzywany przez promienie, blyski na wodzie, chmury)
vec3 getLightColor(float sunHeight)
{
    float day  = dayFactor(sunHeight);
    float gold = goldenFactor(sunHeight);
    return mix(LIGHT_NIGHT * NIGHT_BRIGHTNESS, mix(LIGHT_DAY, LIGHT_GOLD, gold), day);
}

vec3 getAmbientColor(float sunHeight)
{
    float day  = dayFactor(sunHeight);
    float gold = goldenFactor(sunHeight);
    return mix(AMBIENT_NIGHT * NIGHT_BRIGHTNESS, mix(AMBIENT_DAY, AMBIENT_GOLD, gold), day);
}

// Ile "emisji" ma piksel: tylko jasne fragmenty tekstury swieca (plomien, nie patyk pochodni)
float emissiveStrength(vec3 albedoLinear, float flag)
{
    float m = max(albedoLinear.r, max(albedoLinear.g, albedoLinear.b));
    return flag * smoothstep(0.06, 0.45, m);
}

// ---------------------------------------------------------------------
//  Glowne oswietlenie (forward; shadow = wynik getShadow, 1 = jasno):
//  slonce/ksiezyc (miekkie, z "wrap"), ambient z nieba, swiatlo blokow, emisja
//  lm = lightmap (x = block, y = sky), n = normalna w przestrzeni widoku
// ---------------------------------------------------------------------
vec3 calcLightingAO(vec3 albedo, vec2 lm, vec3 n, vec3 sunVec, vec3 moonVec, vec3 upVec, float emis, float rain, float shadow, float ao)
{
    float upAmt = dot(n, upVec) * 0.5 + 0.5;
    float fl = sin(frameTimeCounter * 9.3) * 0.5
             + sin(frameTimeCounter * 23.7) * 0.3
             + sin(frameTimeCounter * 3.1 + 1.7) * 0.2;      // migotanie plomienia

#if defined(DIM_NETHER)
    // Nether (fantasy): brak slonca; dwutonowe swiatlo otoczenia - cieple odbicie lawy od dolu,
    // rozowo-fioletowa magiczna mgla z gory; barwa zalezna od biomu (netherAccent)
    vec3 ambTone = mix(vec3(1.35, 1.10, 0.60), vec3(0.95, 0.80, 1.50), upAmt);
    vec3 biome   = mix(vec3(1.0), netherAccent() * 1.25 + 0.15, 0.55 * clamp(NETHER_BIOME_TINT, 0.0, 2.0));
    vec3 ambient = NETHER_AMBIENT * ambTone * biome * mix(0.70, 1.20, upAmt) * AMBIENT_INTENSITY * ao;
    float bl = pow(lm.x, BLOCKLIGHT_FALLOFF) * (1.0 + fl * 0.18 * TORCH_FLICKER);
    vec3 block = BLOCKLIGHT_COLOR * bl * BLOCKLIGHT_INTENSITY * 1.8;
    return albedo * (MIN_LIGHT + ambient + block + emis * EMISSIVE_BRIGHTNESS * NETHER_EMISSIVE_BOOST);
#elif defined(DIM_END)
    // End: fioletowe, miekkie swiatlo z gory; mocne emisje
    vec3 ambient = END_AMBIENT * mix(0.60, 1.25, upAmt) * AMBIENT_INTENSITY * ao * mix(1.0, ao, 0.8 * clamp(END_AO, 0.0, 1.5));   // ao^~1.8: glebsze naroza
    float bl = pow(lm.x, BLOCKLIGHT_FALLOFF) * (1.0 + fl * 0.18 * TORCH_FLICKER);
    vec3 block = BLOCKLIGHT_COLOR * bl * BLOCKLIGHT_INTENSITY * 1.5;
    return albedo * (MIN_LIGHT + ambient + block + emis * EMISSIVE_BRIGHTNESS * END_EMISSIVE_BOOST);
#else
    float sunHeight = dot(sunVec, upVec);
    float sunAmt  = smoothstep(-0.05, 0.20, sunHeight);
    float moonAmt = 1.0 - smoothstep(-0.20, 0.05, sunHeight);
    float gold    = goldenFactor(sunHeight);
    float day     = dayFactor(sunHeight);

    vec3  sunCol = mix(LIGHT_DAY, LIGHT_GOLD, gold);
    float ndlS = clamp((dot(n, sunVec)  + LIGHT_WRAP) / (1.0 + LIGHT_WRAP), 0.0, 1.0);
    float ndlM = clamp((dot(n, moonVec) + LIGHT_WRAP) / (1.0 + LIGHT_WRAP), 0.0, 1.0);

    float skyOcc  = smoothstep(0.15, 0.60, lm.y);   // ochrona przed "przeciekiem" slonca do jaskin
    float rainDim = 1.0 - rain * 0.75;
    vec3 direct = (sunCol * sunAmt * ndlS + LIGHT_NIGHT * NIGHT_BRIGHTNESS * moonAmt * ndlM) * skyOcc * shadow * rainDim * SUN_INTENSITY;

    vec3  ambCol  = mix(AMBIENT_NIGHT * NIGHT_BRIGHTNESS, mix(AMBIENT_DAY, AMBIENT_GOLD, gold), day);
    vec3 ambient  = ambCol * mix(0.70, 1.15, upAmt) * pow(lm.y, 1.6) * AMBIENT_INTENSITY * (1.0 - rain * 0.3) * ao;

    float bl = pow(lm.x, BLOCKLIGHT_FALLOFF);
    bl *= 1.0 - 0.55 * sunAmt * lm.y;               // w dzien pochodnie na zewnatrz mniej dominuja
    bl *= 1.0 + fl * 0.18 * TORCH_FLICKER;
    vec3 block = BLOCKLIGHT_COLOR * bl * BLOCKLIGHT_INTENSITY * 1.5;

    vec3 light = MIN_LIGHT * mix(NIGHT_BRIGHTNESS, 1.0, day) + ambient + direct + block;
    return albedo * (light + emis * EMISSIVE_BRIGHTNESS);
#endif
}

// wersja bez dodatkowego AO (woda, czasteczki itp.)
vec3 calcLighting(vec3 albedo, vec2 lm, vec3 n, vec3 sunVec, vec3 moonVec, vec3 upVec, float emis, float rain, float shadow)
{
    return calcLightingAO(albedo, lm, n, sunVec, moonVec, upVec, emis, rain, shadow, 1.0);
}

#endif
