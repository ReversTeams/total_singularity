// =====================================================================
//  lib/skyfx.glsl - proceduralne efekty nocnego nieba (gwiazdy, zorza, mglawica,
//  spadajace gwiazdy). Wspolne dla gbuffers_skybasic.fsh i gbuffers_water.fsh
//  (woda odbija gwiazdy i zorze). Dolaczac tylko w plikach .fsh.
// =====================================================================
#ifndef SKYFX_GLSL
#define SKYFX_GLSL
#include "/lib/common.glsl"
#include "/lib/noise.glsl"

uniform float sunAngle;

float hash13(vec3 p)
{
    p = fract(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return fract((p.x + p.y) * p.z);
}

// obrot do ukladu nieba wokol osi nachylonej o sunPathRotation (wzor Rodriguesa)
vec3 celestialDir(vec3 dirW)
{
    float phi = -sunAngle * 6.2831853;
    float tilt = sunPathRotation * 0.0174533;
    vec3 k = vec3(0.0, sin(tilt), cos(tilt));
    return dirW * cos(phi) + cross(k, dirW) * sin(phi) + k * dot(k, dirW) * (1.0 - cos(phi));
}

// Gwiazdy w komorkach 3D wokol kierunku; obrot zgodny z ruchem slonca
vec3 stars(vec3 dirW)
{
    vec3 d = celestialDir(dirW);

    vec3 p    = d * STAR_DENSITY;
    vec3 cell = floor(p);
    vec3 f    = fract(p);

    float h = hash13(cell);
    if (h < 1.0 - STAR_AMOUNT) return vec3(0.0);

    vec3 jitter = vec3(hash13(cell + 11.7), hash13(cell + 37.1), hash13(cell + 71.3)) * 0.5 + 0.25;
    float dist  = length(f - jitter);
    float size  = 0.08 + 0.14 * hash13(cell + 5.3);
    float core  = 1.0 - smoothstep(0.0, size, dist);

    float tw  = 0.65 + 0.35 * sin(frameTimeCounter * (1.5 + 3.0 * hash13(cell + 2.9)) + h * 100.0);   // migotanie
    vec3 col  = mix(vec3(0.65, 0.78, 1.00), vec3(1.00, 0.82, 0.95), hash13(cell + 9.1));               // blekitne / rozowe
    return col * core * tw;
}

// ---------------------- ZORZA POLARNA ----------------------
// Kilka "zaslon" na roznych wysokosciach; kazda to wstega szumu rozciagnieta wzdluz horyzontu.
vec3 aurora(vec3 d, float t)
{
    vec3 acc = vec3(0.0);
    for (int i = 0; i < 6; i++)
    {
        float fi  = float(i);
        float hgt = (0.55 + fi * 0.08) / (d.y + 0.12);
        vec2  p   = d.xz * hgt;
        float n   = vnoise(vec2(p.x * 0.28 + t * 0.020 + fi * 3.1, p.y * 0.55 - t * 0.010));
        n        += 0.5 * vnoise(vec2(p.x * 0.75 - t * 0.035, p.y * 1.4 + fi));
        float curtain = pow(clamp(1.0 - abs(n * 0.66 - 0.5) * 3.4, 0.0, 1.0), 2.5);
        vec3  c   = mix(AURORA_LOW, AURORA_HIGH, clamp(fi / 5.0 + 0.25 * sin(p.x * 0.25 + t * 0.15), 0.0, 1.0));
        acc += c * curtain * (1.0 - fi / 7.0);
    }
    float act = 0.55 + 0.45 * sin(t * 0.04);                    // zorza slabnie i przybiera
    float elev = smoothstep(0.02, 0.30, d.y) * (1.0 - 0.5 * smoothstep(0.75, 1.0, d.y));
    return acc / 3.0 * act * elev;
}

// ---------------------- MGLAWICA ----------------------
vec3 nebula(vec3 dc)
{
    float s = 3.0;
    float n = (vnoise(dc.xy * s) + vnoise(dc.yz * s + 7.0) + vnoise(dc.zx * s + 13.0)) / 3.0 * 0.6
            + (vnoise(dc.xy * s * 2.3 + 5.0) + vnoise(dc.yz * s * 2.3 + 21.0) + vnoise(dc.zx * s * 2.3 + 33.0)) / 3.0 * 0.4;
    float cloud = pow(smoothstep(0.42, 0.78, n), 2.0);
    float hue   = vnoise(dc.xz * 2.0 + dc.y * 3.0 + 40.0);
    return mix(vec3(0.35, 0.10, 0.55), vec3(0.08, 0.35, 0.55), hue) * cloud * 0.22;
}

// ---------------------- SPADAJACE GWIAZDY ----------------------
vec3 shootingStar(vec3 d, float t)
{
    const float period = 7.0;
    float slot = floor(t / period);
    float lt   = t - slot * period;
    if (hash11(slot) < 0.55 || lt > 0.9) return vec3(0.0);       // nie w kazdym oknie czasowym
    float prog = lt / 0.9;

    float az = hash11(slot + 17.3) * 6.2831853;
    float el = 0.35 + 0.5 * hash11(slot + 41.7);
    vec3  start = normalize(vec3(cos(az) * cos(el), sin(el), sin(az) * cos(el)));
    vec3  tang  = normalize(cross(start, vec3(0.0, 1.0, 0.0)));
    float ang   = hash11(slot + 63.1) * 6.2831853;
    vec3  vel   = normalize(tang * cos(ang) + cross(start, tang) * sin(ang));

    vec3 head = normalize(start + vel * prog * 0.35);
    vec3 tail = normalize(start + vel * max(prog - 0.25, 0.0) * 0.35);
    vec3 e = head - tail;
    float L = max(dot(e, e), 1e-6);
    float u = clamp(dot(d - tail, e) / L, 0.0, 1.0);
    float dist = length(d - (tail + e * u));
    float core = (1.0 - smoothstep(0.0, 0.0025, dist)) * u;
    return vec3(1.0, 0.95, 0.85) * core * sin(prog * 3.14159) * 3.0;
}

// Wszystkie wlaczone efekty nocy naraz. dirW = kierunek w swiecie, nightVis = noc*(1-deszcz),
// h = wysokosc nad horyzontem (0-1) do wygaszania przy ziemi.
vec3 nightSkyEffects(vec3 dirW, float nightVis, float h)
{
    vec3 r = stars(dirW) * STAR_BRIGHTNESS * smoothstep(0.0, 0.15, h);
#ifdef NEBULA
    r += nebula(celestialDir(dirW)) * NEBULA_STRENGTH * smoothstep(0.0, 0.2, h);
#endif
#ifdef AURORA
    if (dirW.y > 0.02) r += aurora(dirW, frameTimeCounter) * AURORA_STRENGTH * 0.5;
#endif
#ifdef SHOOTING_STARS
    r += shootingStar(dirW, frameTimeCounter) * smoothstep(0.0, 0.1, h);
#endif
    return r * nightVis;
}

// Wersja dla odbic w wodzie: BEZ gwiazd i spadajacych gwiazd. Punktowe gwiazdy odbite w
// falujacej tafli migaly jako male, "wedrujace" biale kropki (aliasing) - zorza i mglawica sa gladkie.
vec3 nightSkyEffectsSoft(vec3 dirW, float nightVis, float h)
{
    vec3 r = vec3(0.0);
#ifdef NEBULA
    r += nebula(celestialDir(dirW)) * NEBULA_STRENGTH * smoothstep(0.0, 0.2, h);
#endif
#ifdef AURORA
    if (dirW.y > 0.02) r += aurora(dirW, frameTimeCounter) * AURORA_STRENGTH * 0.5;
#endif
    return r * nightVis;
}
#endif
