// =====================================================================
//  lib/endsky.glsl - proceduralne niebo Endu: ciemna fantazja
//
//  Skladniki (od tla do szczegolu):
//   * gradient: prawie czarny indygo + slaba fioletowa poswiata przy horyzoncie, ciemna "pustka" pod nim
//   * mglawica: zaburzony szumem 3D w dwoch kolorach palety, skupiona w szerokiej wstedze (galaktyce),
//     z ciemnymi pasmami pylu i cienkimi, swiecacymi "zylami szczeliny"
//   * gwiazdy: kolorowe, gestsze w wstedze + rzadkie duze z halo
//   * Pusty Ksiezyc: ogromna czarna tarcza zaslaniajaca niebo, z korona, cienka krawedzia
//     oswietlona od strony mglawicy i pochylonym pierscieniem pylu
//   * mgielka przy horyzoncie i rzadkie spadajace gwiazdy
//  Niebo Endu jest nieruchome (jak w vanilla) - zmienia sie tylko powoli mglawica i migotanie gwiazd.
//  Dolaczac tylko w plikach .fsh.
// =====================================================================
#ifndef ENDSKY_GLSL
#define ENDSKY_GLSL
#include "/lib/common.glsl"
#include "/lib/noise.glsl"
#include "/lib/skyfx.glsl"

#include "/lib/endpalette.glsl"

// ---------------------------------------------------------------------
float vnoise3(vec3 p)
{
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash13(i);
    float b = hash13(i + vec3(1.0, 0.0, 0.0));
    float c = hash13(i + vec3(0.0, 1.0, 0.0));
    float d = hash13(i + vec3(1.0, 1.0, 0.0));
    float e = hash13(i + vec3(0.0, 0.0, 1.0));
    float g = hash13(i + vec3(1.0, 0.0, 1.0));
    float h = hash13(i + vec3(0.0, 1.0, 1.0));
    float k = hash13(i + vec3(1.0, 1.0, 1.0));
    return mix(mix(mix(a, b, f.x), mix(c, d, f.x), f.y),
               mix(mix(e, g, f.x), mix(h, k, f.x), f.y), f.z);
}

float fbm3(vec3 p)                 // 4 oktawy, wynik ~0..1
{
    float s = 0.0, a = 0.5;
    for (int i = 0; i < 4; i++)
    {
        s += a * vnoise3(p);
        p = p * 2.03 + vec3(17.1, 3.7, 9.2);
        a *= 0.5;
    }
    return s / 0.9375;
}

float fbm3lo(vec3 p)               // 2 oktawy - do zaburzen i pylu (taniej)
{
    return (0.5 * vnoise3(p) + 0.25 * vnoise3(p * 2.03 + vec3(17.1, 3.7, 9.2))) / 0.75;
}

// os wstegi (galaktyki) i polozenie Pustego Ksiezyca
#define END_BAND_N  normalize(vec3(0.30, 0.55, 0.78))
#define END_MOON_DIR normalize(vec3(0.42, 0.50, -0.75))

// ---------------------- MGLAWICA ----------------------
vec3 endNebula(vec3 d, float t, out float band)
{
    band = exp(-pow(dot(d, END_BAND_N) / 0.36, 2.0));

    vec3 q = d * 1.7;
    vec3 w = vec3(fbm3lo(q + vec3(0.0, t * 2.0, 0.0)),
                  fbm3lo(q + vec3(5.2, 1.3, t)),
                  fbm3lo(q * 0.8 + vec3(2.1, 7.7, -t))) - 0.5;

    float n1 = fbm3(q * 1.3 + w * 1.6 + vec3(t, 0.0, 0.0));
    float n2 = fbm3(q * 2.1 + w * 2.2 + vec3(11.0, 3.0, 7.0) - vec3(0.0, t, 0.0));

    float cA   = pow(smoothstep(0.42, 0.86, n1), 1.6);
    float cB   = pow(smoothstep(0.48, 0.88, n2), 1.6);
    float dust = smoothstep(0.52, 0.72, fbm3lo(q * 3.1 + w * 1.2 + vec3(3.3, 9.0, 1.0)));
    float dens = 0.10 + 1.20 * band;

    vec3 neb = (END_COL_A * cA * 0.55 + END_COL_B * cB * 0.45) * dens;
    neb *= 1.0 - 0.75 * dust;

    // cienkie, swiecace zyly szczeliny (grzbiety szumu)
    float vein = pow(smoothstep(0.82, 1.0, 1.0 - abs(2.0 * n1 - 1.0)), 2.0);
    neb += END_COL_C * vein * (cA * 0.5 + 0.10) * dens * 0.55;
    return neb * 0.34;
}

// ---------------------- GWIAZDY ----------------------
vec3 endStars(vec3 d, float band)
{
    vec3 acc = vec3(0.0);

    // gesta warstwa drobnych gwiazd, wiecej w wstedze
    vec3  p    = d * 95.0;
    vec3  cell = floor(p);
    float h    = hash13(cell);
    if (h > 0.925 - 0.050 * band)
    {
        vec3  jit  = vec3(hash13(cell + 11.7), hash13(cell + 37.1), hash13(cell + 71.3)) * 0.5 + 0.25;
        float dist = length(fract(p) - jit);
        float size = 0.08 + 0.14 * hash13(cell + 5.3);
        float core = 1.0 - smoothstep(0.0, size, dist);
        float tw   = 0.60 + 0.40 * sin(frameTimeCounter * (1.2 + 2.5 * hash13(cell + 2.9)) + h * 100.0);
        vec3  col  = mix(mix(vec3(0.70, 0.80, 1.00), END_COL_C, hash13(cell + 9.1)),
                         vec3(1.00, 0.90, 0.75), step(0.88, hash13(cell + 3.3)));
        acc += col * core * tw * (0.6 + 1.6 * hash13(cell + 8.8));
    }

    // rzadkie, jasne gwiazdy z halo
    p    = d * 26.0;
    cell = floor(p);
    h    = hash13(cell + 91.0);
    if (h > 0.962)
    {
        vec3  jit  = vec3(hash13(cell + 1.7), hash13(cell + 3.1), hash13(cell + 7.3)) * 0.5 + 0.25;
        float dist = length(fract(p) - jit);
        float core = 1.0 - smoothstep(0.0, 0.07, dist);
        float halo = exp(-dist * 11.0) * 0.30;
        float tw   = 0.75 + 0.25 * sin(frameTimeCounter * 1.7 + h * 200.0);
        vec3  col  = mix(vec3(0.80, 0.88, 1.00), END_COL_C, hash13(cell + 4.4) * 0.8);
        acc += col * (core * 2.4 + halo) * tw;
    }
    return acc;
}

// ---------------------- PUSTY KSIEZYC ----------------------
// Zwraca dodatkowe swiatlo (korona, krawedz, pierscien); occ (out) = 1 tam, gdzie tarcza zaslania niebo.
vec3 endVoidMoon(vec3 d, float t, out float occ)
{
    occ = 0.0;
    vec3  M    = END_MOON_DIR;
    float cosA = dot(d, M);
    if (cosA < 0.55) return vec3(0.0);                 // daleko od ksiezyca - nic nie liczymy

    vec3 E1 = normalize(cross(M, vec3(0.0, 1.0, 0.0)));
    vec3 E2 = cross(M, E1);
    vec2 p  = vec2(dot(d, E1), dot(d, E2)) / cosA;     // rzut gnomoniczny (jednostki: tan kata)
    float R = 0.125;                                   // promien tarczy (~7 stopni)
    float r = length(p);
    vec2  n = p / max(r, 1e-5);
    vec2  L = normalize(vec2(-0.55, 0.83));            // strona oswietlona (ku mglawicy)

    vec3 add = vec3(0.0);

    // tarcza: czarna, z cienka, oswietlona krawedzia
    float disc = 1.0 - smoothstep(R - 0.0015, R + 0.0015, r);
    occ = disc;
    float limb = smoothstep(0.62 * R, R, r) * disc;
    float lit  = smoothstep(0.10, 1.0, dot(n, L));
    float surf = 0.6 + 0.8 * fbm3lo(vec3(p / R * 2.2, 4.0));
    add += END_COL_C * limb * lit * surf * 0.16;

    // korona: ostry pierscien tuz za krawedzia + szeroka poswiata z wolno obracajacymi sie promieniami
    float out_r = max(r - R, 0.0) / R;
    float phi   = atan(p.y, p.x);
    float spoke = 0.75 + 0.25 * sin(phi * 9.0 + t * 40.0) * sin(phi * 4.0 - t * 25.0);
    float rim   = exp(-out_r * 30.0) * (1.0 - disc);
    float halo  = exp(-out_r * 1.6) * (1.0 - disc);
    add += END_COL_C * rim * 2.6;
    add += mix(END_COL_A, END_COL_C, 0.35) * halo * spoke * 0.13;

    // pochylony pierscien pylu: z tylu zaslaniany tarcza, z przodu przechodzi przed nia
    const float tilt = 0.52;
    float cs = cos(tilt), sn = sin(tilt);
    vec2  q  = vec2(cs * p.x + sn * p.y, -sn * p.x + cs * p.y);
    float rr = length(vec2(q.x, q.y / 0.30)) / R;
    float ring = smoothstep(1.35, 1.52, rr) * (1.0 - smoothstep(2.35, 2.58, rr));
    ring *= smoothstep(0.0, 0.035, abs(rr - 1.98));                                // przerwa (jak w Saturnie)
    ring *= 0.50 + 0.50 * sin(rr * 13.0 + fbm3lo(vec3(q * 9.0, 2.0)) * 4.0);
    float front = step(q.y, 0.0);
    float visible = max(front, 1.0 - disc);                                        // tyl pierscienia ukryty za tarcza
    float side  = 0.45 + 0.55 * clamp(dot(n, L) * 0.5 + 0.7, 0.0, 1.0);
    add += mix(END_COL_C, END_COL_B * 2.0, 0.45) * ring * visible * side * 0.22;
    return add;
}

// ---------------------- CALE NIEBO ----------------------
vec3 endSky(vec3 d)
{
    float t  = frameTimeCounter * 0.004;
    float hz = pow(1.0 - abs(d.y), 3.0);

    vec3 col = mix(END_ZENITH, END_HORIZON, hz);
    if (d.y < 0.0) col = mix(col, END_VOID, smoothstep(0.0, -0.45, d.y) * 0.85);

    float band;
    vec3  neb = endNebula(d, t, band);
    col += neb * END_NEBULA * smoothstep(-0.30, 0.10, d.y);

    col += endStars(d, band) * END_STARS * smoothstep(-0.05, 0.12, d.y);

    // rzadkie spadajace gwiazdy w kolorze akcentu
    if (d.y > 0.05) col += shootingStar(d, frameTimeCounter) * mix(vec3(1.0), END_COL_C, 0.6) * 0.8;

    // mgielka przy horyzoncie (powoli plynie)
    float mist = fbm3lo(vec3(d.x * 2.4, d.y * 4.5, d.z * 2.4) + vec3(t * 6.0, 0.0, 0.0));
    col += END_COL_A * mist * pow(1.0 - abs(d.y), 6.0) * 0.045;

#ifdef END_VOID_MOON
    float occ;
    vec3  moonAdd = endVoidMoon(d, t, occ);
    col = col * (1.0 - occ) + moonAdd;
#endif
    return col;
}
#endif
