#version 120
// =====================================================================
//  gbuffers_water.vsh - falowanie tafli wody (ID 10008 z block.properties)
// =====================================================================
#include "/lib/settings.glsl"
#include "/lib/water.glsl"

attribute vec4 mc_Entity;

uniform mat4  gbufferModelView;
uniform mat4  gbufferModelViewInverse;
uniform vec3  cameraPosition;
uniform float frameTimeCounter;

varying vec2  texcoord;
varying vec2  lmcoord;
varying vec4  glcolor;
varying vec3  normal;
varying vec3  viewPos;
varying vec3  worldPos;
varying float isWater;
varying float topFace;

void main()
{
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lmcoord  = clamp((lmcoord - 0.03125) * 1.06667, 0.0, 1.0);
    glcolor  = gl_Color;
    normal   = normalize(gl_NormalMatrix * gl_Normal);
    topFace  = float(gl_Normal.y > 0.5);
    isWater  = float(abs(mc_Entity.x - 10008.0) < 0.5);

    vec4 vp  = gl_ModelViewMatrix * gl_Vertex;
    vec4 ep  = gbufferModelViewInverse * vp;
    worldPos = ep.xyz + cameraPosition;

    // Subtelne, plynne falowanie geometrii tafli.
    // Funkcja zalezy tylko od pozycji XZ w swiecie -> brak szczelin miedzy blokami.
    if (isWater > 0.5)
    {
        vec3 w = waterWave(worldPos.xz, frameTimeCounter * WATER_WAVE_SPEED);
        ep.y  += (w.x - 0.35) * 0.06 * WATER_WAVE_HEIGHT;
    }

    vp       = gbufferModelView * ep;
    viewPos  = vp.xyz;
    gl_Position = gl_ProjectionMatrix * vp;
}
