#version 120
// shadow.vsh - przebieg cieni. Woda nie rzuca cieni; rosliny rzucaja je, gdy wlaczone PLANT_SHADOWS.
// Liscie ruszaja sie w cieniu tak samo jak w gbuffers_terrain (wspolny lib/wind.glsl).
#include "/lib/settings.glsl"
#include "/lib/distort.glsl"
#include "/lib/wind.glsl"

attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;

uniform mat4  shadowModelView;
uniform mat4  shadowModelViewInverse;
uniform vec3  cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;

varying vec2 texcoord;
varying vec4 glcolor;

void main()
{
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor  = gl_Color;
    gl_Position = ftransform();
#ifndef SHADOWS
    gl_Position = vec4(2.0, 2.0, 2.0, 1.0);        // cienie wylaczone: pusty przebieg cieni (prawie darmowy)
    return;
#endif

    float id = mc_Entity.x;
    bool isPlantId = (id > 10001.5 && id < 10004.5);
#ifdef PLANT_SHADOWS
    if (abs(id - 10008.0) < 0.5)                       // tylko woda wycinana
#else
    if (isPlantId || abs(id - 10008.0) < 0.5)
#endif
    {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);        // poza ekranem -> odciete
        return;
    }

#ifdef WAVING_FOLIAGE
    bool isLeaf = abs(id - 10001.0) < 0.5;
#ifdef PLANT_SHADOWS
    if (isLeaf || isPlantId)                           // ten sam ruch co w terrain (te same wagi)
#else
    if (isLeaf)
#endif
    {
        float topV    = float(gl_MultiTexCoord0.t < mc_midTexCoord.t);
        float isPlant = float(abs(id - 10002.0) < 0.5);
        float isLower = float(abs(id - 10003.0) < 0.5);
        float isUpper = float(abs(id - 10004.0) < 0.5);
        float weight  = float(isLeaf) * 0.45 + isPlant * topV + isLower * topV * 0.5 + isUpper * (0.5 + 0.5 * topV);
        vec4 ep = shadowModelViewInverse * (gl_ModelViewMatrix * gl_Vertex);
        vec3 wp = ep.xyz + cameraPosition;
        ep.xyz += windOffset(wp, weight, frameTimeCounter * WAVE_SPEED, rainStrength, length(ep.xyz), WIND_SHADOW_FADE_NEAR, WIND_SHADOW_FADE_FAR);
        gl_Position = gl_ProjectionMatrix * (shadowModelView * ep);
    }
#endif
    gl_Position.xy = distortShadow(gl_Position.xy);
}
