#version 120
#define DIM_NETHER
// =====================================================================
//  gbuffers_weather.fsh - deszcz / snieg (v24: FANTASY RAIN)
//
//  Dlaczego osobna warstwa: wczesniej deszcz trafial do colortex0 i dopiero potem composite1 nakladal
//  mgle i wode wg glebi tego, co JEST ZA deszczem (deszcz nie zapisuje glebi). Smuga 3 bloki od kamery
//  przed odlegla gora byla wiec mgla jak 150 blokow dalej (znikala dokladnie na tle gor), a nad woda
//  przechodzila przez pochlanianie i zalamanie jak dno jeziora.
//  Teraz: FANTASY_RAIN -> kolor + alfa trafiaja do colortex7 (test glebi nadal dziala, wiec sciany i dachy
//  zaslaniaja deszcz), a composite1 doklada ta warstwe na samym koncu, PO mgle / wodzie / SSAO.
//  Kolor smugi liczymy z koloru nieba (= mgly) w jej kierunku, wiec pasuje do powietrza wokol gracza.
//
//  Wyjscia: DRAWBUFFERS:70  ->  gl_FragData[0] = colortex7 (warstwa deszczu), gl_FragData[1] = colortex0 (tylko tryb klasyczny).
//  Zapisanie alfa = 0 do nieuzywanego bufora zostawia go bez zmian (blend SRC_ALPHA), wiec jedna lista
//  buforow obsluguje oba tryby (bez #ifdef przy DRAWBUFFERS - nie kazdy parser go respektuje).
//
//  UWAGA (v24.1): Iris dokleja do programow #version 120 automatyczny test alfa na gl_FragData[0].a (zwykle < 0.1 = discard).
//  W v24 w slocie 0 byl colortex0 z alfa = 0, wiec Iris odrzucal KAZDY fragment deszczu i nic nie trafialo do colortex7.
//  Teraz slot 0 to sama warstwa deszczu (jej alfa jest "prawdziwa"), a dodatkowo alphaTest.gbuffers_weather=off w shaders.properties.
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/noise.glsl"

uniform sampler2D texture;
uniform vec3  sunPosition;
uniform vec3  moonPosition;
uniform vec3  upPosition;
uniform float rainStrength;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPosV;
varying vec2 rainCol;

/* DRAWBUFFERS:70 */
void main()
{
    vec4 tex = texture2D(texture, texcoord);
    if (tex.a * glcolor.a < 0.01) discard;

    vec3  sunVec    = normalize(sunPosition);
    vec3  moonVec   = normalize(moonPosition);
    vec3  upVec     = normalize(upPosition);
    float sunHeight = dot(sunVec, upVec);

#ifdef FANTASY_RAIN
    // ---- rzedzenie: vanilla rysuje smuge w kazdej kolumnie blokow. Dzielimy swiat na waskie pasy (4 na blok, w obu osiach,
    // wiec pasy sa pionowe i stabilne w czasie) i zostawiamy ulamek RAIN_DENSITY, z miekkim brzegiem zeby nie bylo twardych ucietych smug.
    if (RAIN_DENSITY < 0.999)
    {
        float hk = hash21(floor(rainCol * 4.0) + 5.31);
        if (hk > RAIN_DENSITY) discard;
    }

    float day  = dayFactor(sunHeight);
    float dist = length(viewPosV);
    vec3  vdir = viewPosV / max(dist, 0.001);

    // ---- zanikanie ----
    // Vanilla koduje odleglosc w alfa wierzcholka: alfa = ((1 - d^2) * 0.5 + 0.5) * poziomDeszczu, gdzie d = odleglosc / zasieg.
    // Dzielimy przez rainStrength i dostajemy ~(0.5 .. 1.0); zanikamy do zera na samej krawedzi zasiegu zamiast
    // zostawiac widoczna "sciane deszczu" (granice kilku blokow wokol gracza). Zakres celowo luzny (od 0.46), zeby
    // niewielka roznica miedzy uniformem a alfa z gry nie wycinala deszczu.
    float ratio = glcolor.a / max(rainStrength, 0.05);
    float edge  = mix(0.30, 1.0, smoothstep(0.0, 1.0, clamp((ratio - 0.46) / 0.26, 0.0, 1.0)));   // nigdy do 0: rozjazd uniformu z alfa gry nie moze wymazac deszczu
    float nearF = smoothstep(0.7, 2.6, dist);            // tuz przy kamerze smuga jest ogromna i pikselowa

    // ---- kolor: powietrze wokol gracza + rozpraszanie swiatla do przodu ----
    vec3  skyC  = applyRainToSky(getSkyColor(vdir, sunVec, moonVec, upVec), rainStrength);   // ten sam kolor co mgla w tym kierunku
    vec3  Ldir  = (sunHeight > -0.05) ? sunVec : moonVec;
    float fw    = pow(max(dot(vdir, Ldir), 0.0), 5.0);   // patrzac w strone slonca / ksiezyca smugi swieca
    vec3  scat  = getLightColor(sunHeight) * fw * 0.85 * (1.0 - rainStrength * 0.65);       // pod chmurami slonce slabiej przebija

    // odcien z palety (niebieski w Fantasy Gold, zielonkawy w Emerald...) - perlowy polysk kropli
    vec3  amb   = getAmbientColor(sunHeight);
    vec3  ambN  = amb / max(max(amb.r, amb.g), max(amb.b, 0.001));
    vec3  tint  = mix(vec3(1.0), ambN, clamp(0.5 * RAIN_MAGIC, 0.0, 0.85));

    vec3  color = (skyC * 1.9 + scat) * tint;
    color += ambN * (1.0 - day) * 0.10 * RAIN_MAGIC;     // w nocy deszcz lekko sam swieci (magia)

    // ---- rzadkie blyski na smugach / platkach (przesuwaja sie razem z tekstura, wiec "spadaja" z kroplami) ----
    if (RAIN_MAGIC > 0.001)
    {
        vec2  cell = floor(texcoord * vec2(32.0, 64.0));
        float h    = hash21(cell + 13.7);
        float tw   = pow(max(0.0, sin(frameTimeCounter * (3.0 + 5.0 * h) + h * 60.0)), 12.0);
        float spk  = step(0.90, h) * tw * RAIN_MAGIC;
        color += mix(vec3(1.0), ambN, 0.4) * spk * 0.8;
    }

    color *= RAIN_BRIGHTNESS;

    float alpha = tex.a * glcolor.a * edge * nearF * RAIN_OPACITY * 0.8;
    gl_FragData[0] = vec4(max(color, vec3(0.0)), clamp(alpha, 0.0, 1.0));    // colortex7: warstwa deszczu -> composite1
    gl_FragData[1] = vec4(0.0);                                              // colortex0 bez zmian (alfa 0 = blend nic nie zmienia)
#else
    // klasyczny deszcz (stary kod): rysowany prosto do sceny, potem przechodzi przez mgle i wode w composite1
    vec4 t2  = tex * glcolor;
    vec3 col = toLinear(t2.rgb) * (getAmbientColor(sunHeight) * 1.1 + getLightColor(sunHeight) * 0.25);
    gl_FragData[0] = vec4(0.0, 0.0, 0.0, t2.a * 0.6);   // colortex7 (w trybie klasycznym nieuzywany; alfa > 0, zeby test alfa nie wycial fragmentu)
    gl_FragData[1] = vec4(col, t2.a * 0.6);             // colortex0: klasyczny deszcz prosto do sceny
#endif
}
