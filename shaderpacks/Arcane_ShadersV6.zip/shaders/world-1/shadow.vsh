#version 120
// puste cienie - w tym wymiarze nie ma slonca
void main() { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); }
