#version 120
#define DIM_NETHER
// =====================================================================
//  composite7.fsh - BLOOM: poziom 2, rozmycie pionowe (colortex3 -> colortex6) = SREDNIE halo
//  Piramida o zredukowanej rozdzielczosci (lib/bloom.glsl) - ok. 30x mniej pracy niz
//  dawna kaskada w pelnej rozdzielczosci.
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/bloom.glsl"

uniform sampler2D colortex3;

/* DRAWBUFFERS:6 */
void main()
{
    vec3 sum = vec3(0.0);
#ifdef BLOOM
    if (bloomInside(BLOOM_LV2))
        sum = bloomBlur(colortex3, gl_FragCoord.xy, vec2(0.0, 1.0), BLOOM_LV2, BLOOM_RADIUS * 0.5);
#endif
    gl_FragData[0] = vec4(sum, 1.0);
}
