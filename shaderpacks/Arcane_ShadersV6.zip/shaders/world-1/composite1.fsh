#version 120
#define DIM_NETHER
// =====================================================================
//  composite1.fsh - PASS B (pelna rozdzielczosc, HDR liniowy)
//   upsample efektow z polowy rozdzielczosci (bilateralnie, wg glebi) ->
//   SSAO, glebia wody, mgla (zalezna od pory dnia / wymiaru), God Rays
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/noise.glsl"
#include "/lib/water.glsl"
#if defined(DIM_END)
  #include "/lib/endsky.glsl"
#endif
#if defined(DIM_NETHER)
  #include "/lib/nether.glsl"
#endif

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;      // znacznik chmury (r=1, b=0) - chmura nie jest woda
uniform sampler2D colortex3;      // odbicie powierzchni wody (z gbuffers_water)
uniform sampler2D colortex5;
uniform sampler2D colortex8;      // v28/v33: chmury z composite.fsh (polowa rozdzielczosci, alfa = przezroczystosc + 1)
#ifdef FANTASY_RAIN
uniform sampler2D colortex7;      // warstwa deszczu / sniegu: rgb juz pomnozone przez alfa, a = pokrycie
#endif
uniform sampler2D depthtex0;
uniform sampler2D depthtex1;

uniform mat4  gbufferProjectionInverse;
uniform mat4  gbufferModelView;
uniform mat4  gbufferModelViewInverse;
uniform vec3  cameraPosition;
uniform vec3  sunPosition;
uniform vec3  moonPosition;
uniform vec3  upPosition;
uniform float far;
uniform float rainStrength;
uniform int   isEyeInWater;

varying vec2 texcoord;

vec3 toView(vec2 uv, float depth)
{
    vec4 p = gbufferProjectionInverse * vec4(vec3(uv, depth) * 2.0 - 1.0, 1.0);
    return p.xyz / p.w;
}

/* DRAWBUFFERS:0 */
void main()
{
    vec2  uv    = texcoord;
    float d0    = texture2D(depthtex0, uv).r;
    float d1    = texture2D(depthtex1, uv).r;
    vec2  uvC   = uv;                                // UV do odczytu koloru sceny (Nether: drganie ciepla nad lawa)
#if defined(DIM_NETHER)
    vec3  nAccent = netherAccent();
    if (NETHER_HEAT_HAZE > 0.001 && d0 < 0.99999 && isEyeInWater == 0)
    {
        vec3  vpH = toView(uv, d0);
        vec3  wpH = (gbufferModelViewInverse * vec4(vpH, 1.0)).xyz + cameraPosition;
        uvC = uv + netherHeatHaze(wpH, length(vpH), frameTimeCounter);
    }
#endif
    vec3  color = texture2D(colortex0, uvC).rgb;
    bool  isSky = d0 > 0.99999;
    vec4  flags = texture2D(colortex1, uv);          // r emisja/iskry, g woda (0.6), b reka / skylight wody

    vec3  vp0     = toView(uv, d0);
    float dist0   = length(vp0);
    vec3  viewDir = vp0 / max(dist0, 0.0001);

    vec3  sunVec  = normalize(sunPosition);
    vec3  moonVec = normalize(moonPosition);
    vec3  upVec   = normalize(upPosition);
    float sunHeight = dot(sunVec, upVec);
    float day     = dayFactor(sunHeight);

    // ------------- upsample + odszumianie efektow z polowy rozdzielczosci -------------
    // composite.fsh rysuje SSAO / god rays wzorcem Bayera 4x4. Okno 4x4 (filtr "tent" + waga glebi)
    // usrednia wszystkie 16 przesuniec, wiec ziarno znika, a krawedzie obiektow zostaja ostre.
    vec2 res     = vec2(viewWidth, viewHeight);
    vec2 halfRes = floor(res * 0.5);
    vec4 hAcc = vec4(0.0, 1.0, 0.0, 0.0);              // r = god rays, g = AO (1 = brak)
#if defined(SSAO) || (defined(GODRAYS) && !defined(DIM_NETHER) && !defined(DIM_END))
    {
        vec2  hp = gl_FragCoord.xy * (halfRes / res) - 0.5;
        vec2  b0 = floor(hp);
        float rayAcc = 0.0, aoAcc = 0.0, wR = 0.0, wA = 0.0;
        for (int j = 0; j < 4; j++)
        {
            for (int i = 0; i < 4; i++)
            {
                vec2  pp = b0 + vec2(float(i) - 1.0, float(j) - 1.0);
                vec2  ip = clamp(pp, vec2(0.0), halfRes - 1.0);
                vec4  h  = texture2D(colortex5, (ip + 0.5) / res);
                vec2  dd = abs(pp - hp);
                float ws = max(2.0 - dd.x, 0.0) * max(2.0 - dd.y, 0.0);
                float w  = ws / (0.02 + abs(h.b - dist0) / max(dist0, 1.0));   // waga glebi: bez "krwawienia" na krawedziach
                rayAcc += h.r * w;
                wR     += w;
                aoAcc  += h.g * w * h.a;                                       // h.a = 1 tylko dla pikseli, ktore przyjmuja AO
                wA     += w * h.a;
            }
        }
        hAcc.r = rayAcc / max(wR, 0.0001);
        hAcc.g = wA > 0.0001 ? aoAcc / wA : 1.0;
    }
#endif

    // ---------------------------- SSAO ----------------------------
#ifdef SSAO
    if (!isSky && flags.b < 0.3 && abs(d0 - d1) < 0.00002 && texture2D(colortex2, uv).a > 0.9)   // alfa < 0.9 = roslina / lisc: bez SSAO
    {
#if defined(DIM_END)
        // End: mocniejsze AO z krzywa (gleboko w zakamarkach prawie czern) i fioletowym odcieniem cienia
        float s = SSAO_STRENGTH * END_AO * (1.0 - smoothstep(0.3, 0.9, flags.r)) * (1.0 - smoothstep(70.0, 128.0, dist0));
        float k = clamp((1.0 - pow(hAcc.g, 1.35)) * s, 0.0, 0.95);
        color *= mix(vec3(1.0), vec3(0.10, 0.05, 0.20), k);
#else
        float s = SSAO_STRENGTH * flags.a * (1.0 - smoothstep(0.3, 0.9, flags.r)) * (1.0 - smoothstep(40.0, 90.0, dist0));   // flags.a: slabsze AO w pelnym sloncu
        color *= mix(1.0, hAcc.g, s);
#endif
    }
#endif

#ifndef WATER_USE_COMPAT
    // ---------------- WODA (v17): cialo wody + odbicie ----------------
    // gbuffers_water zapisuje g = 0.6 (po blendzie); sky/chmury moga miec inna wartosc po czyszczeniu bufora.
    // Maska wody: g = 0.6 przy typowym blendzie, ~0.84 przy dwoch warstwach, 1.0 gdy gra nie blenduje tego bufora
    // (nowsze wersje MC). Lod/szklo przed woda zeruja maske (patrz gbuffers_water). Chmury maja wlasny znacznik.
    vec4 nd2 = texture2D(colortex2, uv);
    bool isCloudPx = nd2.r > 0.99 && nd2.b < 0.01;
    bool isWaterPx = flags.g > 0.45 && !isCloudPx;
    if (isWaterPx && !isSky && isEyeInWater == 0)
    {
        float t   = frameTimeCounter * WATER_WAVE_SPEED;
        vec3  wp0 = (gbufferModelViewInverse * vec4(vp0, 1.0)).xyz + cameraPosition;

        bool  hasFloor = d1 < 0.99999;
        vec3  vp1    = toView(uv, d1);
        vec3  wp1    = (gbufferModelViewInverse * vec4(vp1, 1.0)).xyz + cameraPosition;
        float thick  = hasFloor ? max(length(vp1) - dist0, 0.0) : 48.0;   // droga promienia w wodzie
        float depthV = hasFloor ? max(wp0.y - wp1.y, 0.0) : 48.0;        // pionowa glebokosc
        float skyL   = clamp(flags.b / 0.15, 0.0, 1.0);                  // doswietlenie niebem (jaskinie = ciemna woda)

        vec3 Nw = waterNormalWorld(wp0.xz, t, dist0, rainStrength);
        vec3 Nv = normalize(mat3(gbufferModelView) * Nw);
        if (dot(Nv, -viewDir) < 0.0) Nv = -Nv;

        // --- zalamanie: dno "faluje" pod tafla ---
        vec2 ruv = uv;
        if (WATER_REFRACTION > 0.001 && hasFloor && dist0 < 64.0)       // daleko zalamanie niewidoczne - pomijamy 2 odczyty
        {
            vec3  dn = mat3(gbufferModelView) * vec3(Nw.x, 0.0, Nw.z);
            float k  = WATER_REFRACTION * 0.05 * clamp(thick * 0.35, 0.0, 1.0) / (1.0 + dist0 * 0.03) * (1.0 - smoothstep(32.0, 64.0, dist0));
            vec2  cand = clamp(uv + dn.xy * k, vec2(0.002), vec2(0.998));
            // akceptuj probke tylko jesli to ta sama powierzchnia dna (podobna odleglosc) pod woda:
            // inaczej zalamanie "rozmazywalo" ciemne boki blokow po krawedziach sylwetek
            float cd1 = texture2D(depthtex1, cand).r;
            float cg  = texture2D(colortex1, cand).g;
            if (cg > 0.45 && cd1 > d0 && cd1 < 0.99999
                && abs(length(toView(cand, cd1)) - length(vp1)) < 0.25 + 0.015 * dist0) ruv = cand;
        }
        vec3 floorCol = texture2D(colortex0, ruv).rgb;

        // --- kaustyka na dnie (tylko plytko i w swietle nieba) ---
        if (hasFloor && WATER_CAUSTICS > 0.001 && dist0 < 70.0)      // wzor liczony tylko tam, gdzie nie jest jeszcze wygaszony
        {
            float c    = causticPattern(wp1.xz, t);
            float fade = exp(-depthV * 0.22) * (1.0 - smoothstep(30.0, 70.0, dist0));
            float sunAmt = (0.15 + 0.85 * day) * (1.0 - rainStrength) * skyL;
            floorCol *= 1.0 + c * WATER_CAUSTICS * 1.0 * fade * sunAmt;
        }

        // --- cialo wody: pochlanianie Beera-Lamberta (czerwien znika pierwsza) + rozproszenie ---
        vec3  wl      = toLinear(WATER_COLOR);
        vec3  absCoef = -log(clamp(wl, vec3(0.02), vec3(0.98))) * WATER_ABSORPTION;
        vec3  T       = exp(-absCoef * thick);
        float lightAmt = (0.12 + 0.88 * day) * (1.0 - 0.35 * rainStrength);
        lightAmt = mix(0.04, lightAmt, smoothstep(0.05, 0.9, skyL));
        float dd   = 1.0 - exp(-depthV * 0.10);
        vec3  scat = mix(wl * 0.55, toLinear(WATER_DEEP_COLOR) * 0.9, dd);        // plytko jasny turkus -> gleboko ciemny
        scat = mix(scat, scat * vec3(0.80, 0.72, 1.35), smoothstep(10.0, 45.0, depthV) * 0.4);   // glebiny lekko fioletowe
        scat *= lightAmt * 1.6 * mix(1.0, 0.55, dd);                             // glebiny sa ciemniejsze
        float inS  = 1.0 - exp(-thick * (0.06 + WATER_ABSORPTION * 0.5));
        vec3  body = floorCol * T * (1.0 - inS * 0.35) + scat * inS;

        // --- odbicie (liczone w gbuffers_water, juz pomnozone przez Fresnela) ---
        float cosT = clamp(dot(-viewDir, Nv), 0.0, 1.0);
        float R    = clamp((0.035 + 0.965 * pow(1.0 - cosT, 5.0)) * WATER_REFLECTION, 0.0, 1.0);
        color = body * (1.0 - R) + texture2D(colortex3, uv).rgb;

        // --- piana / poswiata przy brzegu (promien trafia szybko w sciane brzegu) ---
        if (WATER_FOAM > 0.001 && hasFloor && dist0 < 80.0)
        {
            float edge = 1.0 - smoothstep(0.05, 0.7, thick);
            if (edge > 0.001)
            {
                float fn   = foamNoise(wp0.xz, t);
                float lap  = 1.0 - smoothstep(0.0, 0.18, abs(thick - (0.35 + 0.2 * sin(t * 1.3 + fn * 6.0))));
                float foam = clamp(edge * smoothstep(0.30, 0.65, fn) + lap * fn * 0.5 * edge, 0.0, 1.0) * WATER_FOAM
                           * (1.0 - smoothstep(50.0, 80.0, dist0));
                vec3  foamCol = vec3(0.90, 0.97, 1.0) * lightAmt * 1.5
                              + toLinear(vec3(0.45, 0.80, 1.0)) * 0.25 * (1.0 - day) * skyL;   // nocna bioluminescencja
                color = mix(color, max(foamCol, color * 1.1), clamp(foam, 0.0, 1.0) * 0.85);
            }
        }
    }
#endif

    // ---------------------------- mgla ----------------------------
    float fogAmount = 0.0;
#ifdef FOG
    if (isEyeInWater == 1)
    {
        float d = isSky ? 64.0 : dist0;                 // pod woda: gesta, turkusowa mgla
        fogAmount = 1.0 - exp(-d * UNDERWATER_FOG_DENSITY);
        vec3 uw = toLinear(WATER_DEEP_COLOR * 1.1) * (0.15 + 0.85 * day) * 1.2;
        color = mix(color, uw, fogAmount);
    }
    else if (isEyeInWater == 2)
    {
        fogAmount = 1.0 - exp(-dist0 * 0.9);            // w lawie: gesta, szkarlatno-zlota mgla, delikatnie pulsuje
        color = mix(color, vec3(1.9, 0.42, 0.04) * (0.85 + 0.15 * sin(frameTimeCounter * 1.4)), fogAmount);
    }
    else if (isEyeInWater == 3)
    {
        fogAmount = 1.0 - exp(-dist0 * 0.9);            // w sypkim sniegu
        color = mix(color, toLinear(vec3(0.88, 0.92, 1.0)), fogAmount);
    }
    else if (!isSky)
    {
  #if defined(DIM_NETHER) || defined(DIM_END)
        // Nether: mgla w kolorze biomu (fogColor z gry); End: ciemny fiolet
        float fd = dist0 / (far * DIM_FOG_RANGE);
    #if defined(DIM_NETHER)
        float dimFogMul = NETHER_FOG_AMOUNT;
    #else
        float dimFogMul = 1.0;
    #endif
        fogAmount = max(1.0 - exp(-fd * fd * 3.0 * FOG_DENSITY * DIM_FOG_DENSITY * dimFogMul), smoothstep(0.80, 1.0, fd));
    #if defined(DIM_END)
        vec3 fogCol = END_FOG_COLOR;                  // kolor horyzontu nieba Endu (lib/endsky.glsl)
    #else
        // Nether (fantasy): objetosciowa, wirujaca mgla + poswiata lawy (lib/nether.glsl)
        vec3 dirWF  = normalize(mat3(gbufferModelViewInverse) * viewDir);
        vec3 fogCol = netherFog(cameraPosition, dirWF, min(dist0, far * DIM_FOG_RANGE), frameTimeCounter, nAccent, fogAmount);
        fogAmount   = max(fogAmount, smoothstep(0.80, 1.0, fd));                          // krawedz renderowania zawsze ukryta
    #endif
        color = mix(color, fogCol, clamp(fogAmount, 0.0, 1.0));
  #else
    #if FOG_DISTANCE > 0
        float fogEnd = float(FOG_DISTANCE);
    #else
        float fogEnd = far * 0.95;
    #endif
        float fd      = dist0 / fogEnd;
        float density = FOG_DENSITY * (1.0 + rainStrength * 1.2);

        float worldY = (gbufferModelViewInverse * vec4(vp0, 1.0)).y + cameraPosition.y;
        float hf     = exp(-max(worldY - FOG_HEIGHT_BASE, 0.0) * FOG_HEIGHT_FALLOFF);

        float haze = (1.0 - exp(-fd * fd * 3.0 * density)) * hf;
        fogAmount  = max(haze, smoothstep(0.80, 1.0, fd));       // krawedz renderowania zawsze ukryta

        vec3 fogCol = getSkyColor(viewDir, sunVec, moonVec, upVec);   // zlota rano/wieczorem, fioletowa w nocy
        fogCol = applyRainToSky(fogCol, rainStrength);
        color  = mix(color, fogCol, clamp(fogAmount, 0.0, 1.0));
  #endif
    }
  #if defined(DIM_END)
    else if (isEyeInWater == 0)
    {
        // End: niebo rysowane tutaj, w pelnoekranowym przebiegu - dla pikseli bez geometrii (glebia = 1).
        // Nie zalezy od tego, ktorym programem gra rysuje skybox Endu (skytextured / skybasic / inny w MC 26+),
        // wiec niebo jest takie samo w kazdej wersji. HDR (korona Pustego Ksiezyca) nadal wchodzi do bloomu.
        vec3 dirWE = normalize(mat3(gbufferModelViewInverse) * viewDir);
        color = endSky(dirWE);
    }
  #endif
  #if defined(DIM_NETHER)
    else if (isEyeInWater == 0)
    {
        // niebo = ta sama mgla przy pelnym zasiegu (identyczny kolor jak w pelni zamglony teren = brak szwu)
        vec3 dirWS = normalize(mat3(gbufferModelViewInverse) * viewDir);
        float faS  = 1.0;
        color = netherFog(cameraPosition, dirWS, far * DIM_FOG_RANGE, frameTimeCounter, nAccent, faS);
    }
  #endif
#endif

#if defined(DIM_NETHER) && defined(NETHER_EMBERS)
    // Iskry / zarodniki / popiol - po mgle, zeby swiecily przez nia (HDR > prog bloomu = pieknie sie rozmywaja)
    if (NETHER_EMBER_AMOUNT > 0.001 && isEyeInWater == 0)
    {
        vec3 dirW = normalize(mat3(gbufferModelViewInverse) * viewDir);
        vec3 emb  = netherEmbers(dirW, dist0, cameraPosition, frameTimeCounter, nAccent);
        color += emb * (1.0 - 0.5 * fogAmount);
    }
#endif

    // ------------------- chmury proceduralne (v26-v28, CLOUD_STYLE >= 2) -------------------
    // Ray-marching jest w composite.fsh w POLOWIE rozdzielczosci (4x mniej pikseli) -> colortex6 = (rgb przedmnozone, przezroczystosc).
    // Tu tylko upsample 2x2 z waga glebi (ta sama idea co SSAO): piksel nieba bierze teksele nieba, teren - teksele terenu, wiec bez halo na krawedziach.
#if CLOUD_STYLE >= 2 && !defined(DIM_END) && !defined(DIM_NETHER)
    if (isEyeInWater == 0)
    {
        vec2  hpc = gl_FragCoord.xy * (halfRes / res) - 0.5;
        vec2  bc  = floor(hpc);
        vec2  fc  = hpc - bc;
        vec4  cAcc = vec4(0.0);
        float cW   = 0.0;
        for (int j = 0; j < 2; j++)
        {
            for (int i = 0; i < 2; i++)
            {
                vec2  ip  = clamp(bc + vec2(float(i), float(j)), vec2(0.0), halfRes - 1.0);
                vec2  tuv = (ip + 0.5) / res;
                vec4  ct  = texture2D(colortex8, tuv);
                float hd  = texture2D(colortex5, tuv).b;                                  // odleglosc piksela polowy rozdzielczosci
                float wb  = (i == 0 ? 1.0 - fc.x : fc.x) * (j == 0 ? 1.0 - fc.y : fc.y);
                float w   = wb / (0.02 + abs(hd - dist0) / max(dist0, 1.0)) * step(0.5, ct.a);   // tekseli bez danych (pierwsza klatka) nie bierzemy
                cAcc += vec4(ct.rgb, ct.a - 1.0) * w;
                cW   += w;
            }
        }
        vec4 cl = (cW > 0.0001) ? cAcc / cW : vec4(0.0, 0.0, 0.0, 1.0);                   // brak danych = brak chmur
        float cT  = clamp(cl.a, 0.0, 1.0);
        float sunM = smoothstep(1.5, 4.0, dot(color, vec3(0.2126, 0.7152, 0.0722)));         // tarcza slonca / ksiezyca jest o wiele jasniejsza niz niebo
        color = color * mix(cT, cT * cT * cT, sunM) + cl.rgb;                               // chmura mocniej zaslania tarcze (bez bialego kola widocznego przez chmure)
    }
#endif

    // ------------------------ deszcz / snieg (v24) ------------------------
    // Doklejany PO mgle, wodzie i SSAO: smuga jest tuz przy kamerze, wiec nie moze byc mgloona wg glebi tego, co za nia.
#if defined(FANTASY_RAIN) && !defined(DIM_NETHER) && !defined(DIM_END)
    if (isEyeInWater == 0)
    {
        vec4 rl = texture2D(colortex7, uv);
        color = color * (1.0 - clamp(rl.a, 0.0, 1.0)) + rl.rgb;
    }
#endif

    // --------------------------- God Rays --------------------------
#if defined(GODRAYS) && !defined(DIM_NETHER) && !defined(DIM_END)
    if (hAcc.r > 0.0001)
    {
        bool  sunIsSource = sunHeight > -0.08;
        float moonMul = sunIsSource ? 1.0 : 0.35;                  // ksiezycowe promienie slabsze
        vec3  rayCol  = sunIsSource ? getLightColor(sunHeight) : LIGHT_NIGHT * NIGHT_BRIGHTNESS * 4.0;
        float haze    = 0.5 + 0.8 * fogAmount;                     // wyrazniejsze w zamglonym powietrzu
        float skyMul  = isSky ? 0.35 : 1.0;
        if (isEyeInWater == 1) skyMul *= 0.0;                       // pod woda brak god rays (tworzyly dziwne kolo wokol slonca)
        color += rayCol * hAcc.r * GODRAYS_STRENGTH * moonMul * haze * skyMul;
    }
#endif

    gl_FragData[0] = vec4(color, 1.0);
}
