#version 120
#define DIM_NETHER
// =====================================================================
//  deferred.fsh - ODROCZONE OSWIETLENIE TERENU (opcja DEFERRED_LIGHTING)
//  Dziala po narysowaniu nieprzezroczystej geometrii, a PRZED woda / szklem / czasteczkami.
//  gbuffers_terrain.fsh zapisal tylko albedo + dane materialu (lib/gbuf.glsl); tu liczymy
//  cien, swiatlo, PBR, swiatlo z reki i SSS RAZ na piksel ekranu. Wczesniej kazda warstwa
//  lisci / trawy (overdraw) liczyla to osobno. Reszta pikseli (niebo, byty, lawa) przechodzi bez zmian.
//  Wynik: colortex0 = gotowy kolor, colortex1 = (emisja, 0, 0, mnoznik sily SSAO) - jak w trybie klasycznym.
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/endpalette.glsl"
#include "/lib/shadow.glsl"
#include "/lib/pbr.glsl"
#include "/lib/handlight.glsl"
#include "/lib/gbuf.glsl"

uniform sampler2D colortex0;
uniform sampler2D colortex1;
uniform sampler2D colortex2;
uniform sampler2D colortex4;
uniform sampler2D colortex5;
uniform sampler2D depthtex0;
uniform mat4  gbufferProjectionInverse;
uniform vec3  sunPosition;
uniform vec3  moonPosition;
uniform vec3  upPosition;

varying vec2 texcoord;

vec3 toViewPos(vec2 uv, float depth)
{
    vec4 p = gbufferProjectionInverse * vec4(vec3(uv, depth) * 2.0 - 1.0, 1.0);
    return p.xyz / p.w;
}

/* DRAWBUFFERS:01 */
void main()
{
    vec4 c0 = texture2D(colortex0, texcoord);
    vec4 c1 = texture2D(colortex1, texcoord);
    gl_FragData[0] = c0;                 // domyslnie: przepuszczamy bez zmian
    gl_FragData[1] = c1;
#ifdef DEFERRED_LIGHTING
    if (abs(c1.a - DEFER_MARK) > 0.02) return;           // nie jest terenem do oswietlenia (niebo, byty, lawa...)
    float depth = texture2D(depthtex0, texcoord).r;
    if (depth >= 1.0) return;

    // ---- dane z G-buffera ----
    vec3 albedo = c0.rgb;
    vec2 lm     = c1.rg;
    vec4 c2     = texture2D(colortex2, texcoord);
    vec4 c4     = texture2D(colortex4, texcoord);
    vec4 c5     = texture2D(colortex5, texcoord);
    if (c2.r > 0.99 && c2.b < 0.01) return;                 // znacznik chmury (chmura narysowana nad terenem) - nie ruszamy
    vec3 N      = normalize(c2.rgb * 2.0 - 1.0);            // normalna geometryczna (cien, SSAO)

    float code     = floor(c4.b + 0.5) - 1.0;                 // 1 + klasa_emisji + 6 * rodzaj_roslinnosci
    float emisCls  = mod(code, 6.0);
    float kind     = floor(code / 6.0);                       // 0 brak, 1 liscie, 2 rosliny, 3 trawa na ziemi
    float warmFlag  = step(0.5, emisCls) * (1.0 - step(1.5, emisCls));
    float soulFlag  = step(1.5, emisCls) * (1.0 - step(2.5, emisCls));
    float endStrong = step(2.5, emisCls) * (1.0 - step(3.5, emisCls));
    float endSoft   = step(3.5, emisCls) * (1.0 - step(4.5, emisCls));
    float isLeafF   = step(0.5, kind) * (1.0 - step(1.5, kind));
    float isPlantF  = step(1.5, kind) * (1.0 - step(2.5, kind));
    float plantFlag = isPlantF;

    PBRData pbr;
    pbr.N          = octDec(c5.rg);
    pbr.smoothness = c5.b;
    float isMetal  = step(1.0, c5.a);                      // c5.a < 1: F0 dielektryka, >= 1: 1 + ilosc metalu
    pbr.metal      = isMetal * (c5.a - 1.0);
    pbr.F0         = isMetal > 0.5 ? albedo : vec3(c5.a);
    pbr.emission   = c4.g;
    pbr.ao         = c4.r;

    vec3 viewPosV = toViewPos(texcoord, depth);
    vec3 sunVec   = normalize(sunPosition);
    vec3 moonVec  = normalize(moonPosition);
    vec3 upVec    = normalize(upPosition);

    // ---- identycznie jak dawniej w gbuffers_terrain.fsh ----
    float emisWarm = emissiveStrength(albedo, warmFlag);
    float emisSoul = emissiveStrength(albedo, soulFlag);
    float emisEnd  = endGlowStrength(albedo) * (endStrong + 0.35 * endSoft) * END_GLOW * END_GLOW_DIM;

    float shadow = (plantFlag > 0.5 || isLeafF > 0.5) ? getShadowLite(viewPosV, N, lm.y, gl_FragCoord.xy)
                                                      : getShadow(viewPosV, N, lm.y, gl_FragCoord.xy);
#ifdef PLANT_SHADOWS
    if (plantFlag > 0.5) shadow = mix(1.0, shadow, PLANT_SHADOW_STRENGTH * 0.6);
#endif

    vec3 diffuseAlbedo = albedo * (1.0 - pbr.metal);
    vec3 color = calcLightingAO(diffuseAlbedo, lm, pbr.N, sunVec, moonVec, upVec, emisWarm, rainStrength, shadow, pbr.ao);
    color += diffuseAlbedo * handLight(viewPosV, pbr.N);
    color += albedo * emisSoul * SOUL_EMISSIVE_COLOR * EMISSIVE_BRIGHTNESS;
    color += albedo * mix(vec3(1.0), END_COL_C * 1.5, 0.35) * emisEnd * EMISSIVE_BRIGHTNESS * 1.6
           * (0.88 + 0.12 * sin(frameTimeCounter * 1.3));
    float emisPBR = pbr.emission * PBR_EMISSION;
    color += albedo * emisPBR * EMISSIVE_BRIGHTNESS;
    color += pbrSpecular(pbr, viewPosV, sunVec, moonVec, upVec, lm, shadow, rainStrength);

#if defined(FOLIAGE_SSS) && !defined(DIM_NETHER) && !defined(DIM_END)
    if (isLeafF + isPlantF > 0.5)
    {
        float sunH  = dot(sunVec, upVec);
        vec3  Ls    = (dayFactor(sunH) > 0.5) ? sunVec : moonVec;
        float back  = pow(clamp(dot(normalize(viewPosV), Ls), 0.0, 1.0), 3.0);
        float open  = smoothstep(0.30, 0.90, lm.y) * (1.0 - rainStrength) * getCloudShadow(viewPosV, N, lm.y);   // v35: pod cieniem chmury lisc nie jest podswietlany od tylu
        color += albedo * vec3(1.15, 1.05, 0.65) * getLightColor(sunH) * back * open * FOLIAGE_SSS_STRENGTH;
    }
#endif

    float emis = max(max(emisWarm, emisSoul), max(emisPBR, emisEnd));

    // SSAO ma przyciemniac glownie swiatlo OTOCZENIA: w pelnym sloncu AO slabnie (mnoznik 0.3..1)
    float aoMul = 1.0;
#if !defined(DIM_NETHER) && !defined(DIM_END)
    {
        float directLit = shadow * smoothstep(0.0, 0.45, dot(N, sunVec)) * smoothstep(-0.05, 0.20, dot(sunVec, upVec))
                        * smoothstep(0.15, 0.60, lm.y) * (1.0 - rainStrength * 0.75);
        aoMul = 1.0 - 0.7 * directLit;
    }
#endif
    gl_FragData[0] = vec4(color, 1.0);
    gl_FragData[1] = vec4(emis, 0.0, 0.0, aoMul);
#endif
}
