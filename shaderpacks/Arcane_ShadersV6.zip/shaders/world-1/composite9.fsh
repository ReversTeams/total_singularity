#version 120
#define DIM_NETHER
// =====================================================================
//  composite9.fsh - BLOOM: poziom 3, rozmycie pionowe (colortex3 -> colortex4) = SZEROKIE halo
//  Piramida o zredukowanej rozdzielczosci (lib/bloom.glsl) - ok. 30x mniej pracy niz
//  dawna kaskada w pelnej rozdzielczosci.
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/bloom.glsl"

uniform sampler2D colortex3;

/* DRAWBUFFERS:4 */
void main()
{
    vec3 sum = vec3(0.0);
#ifdef BLOOM
    if (BLOOM_WIDE > 0.001 && bloomInside(BLOOM_LV3))
        sum = bloomBlur(colortex3, gl_FragCoord.xy, vec2(0.0, 1.0), BLOOM_LV3, BLOOM_RADIUS * 0.6);
#endif
    gl_FragData[0] = vec4(sum, 1.0);
}
