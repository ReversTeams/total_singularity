#version 120
#define DIM_NETHER
// =====================================================================
//  composite5.fsh - BLOOM: poziom 1, rozmycie pionowe (colortex4 -> colortex5) = WASKIE halo
//  Piramida o zredukowanej rozdzielczosci (lib/bloom.glsl) - ok. 30x mniej pracy niz
//  dawna kaskada w pelnej rozdzielczosci.
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/bloom.glsl"

uniform sampler2D colortex4;

/* DRAWBUFFERS:5 */
void main()
{
    vec3 sum = vec3(0.0);
#ifdef BLOOM
    if (bloomInside(BLOOM_LV1))
        sum = bloomBlur(colortex4, gl_FragCoord.xy, vec2(0.0, 1.0), BLOOM_LV1, BLOOM_RADIUS * 0.25);
#endif
    gl_FragData[0] = vec4(sum, 1.0);
}
