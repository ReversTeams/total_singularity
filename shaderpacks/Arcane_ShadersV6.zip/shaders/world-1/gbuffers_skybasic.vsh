#version 120
#define DIM_NETHER
// gbuffers_skybasic.vsh - kopula nieba + gwiazdy vanilla (wykrywane po szarym kolorze)
varying vec4 starData;
void main()
{
    gl_Position = ftransform();
    starData = vec4(gl_Color.rgb, float(gl_Color.r == gl_Color.g && gl_Color.g == gl_Color.b && gl_Color.r > 0.0));
}
