#version 120
#define DIM_NETHER
// gbuffers_spidereyes.fsh - oczy pajakow / endermanow: swieca w ciemnosci (nieoswietlone)
#include "/lib/common.glsl"
#include "/lib/endpalette.glsl"

uniform sampler2D texture;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPosV;

/* DRAWBUFFERS:01 */
void main()
{
    vec4 tex = texture2D(texture, texcoord) * glcolor;
    if (tex.a < 0.01) discard;
#if defined(DIM_END)
    // w Endzie oczy endermanow i smoka swieca mocniej (suwak END_GLOW) i silniej blooma
    float boost = 2.0 + 1.6 * END_GLOW;
    float mask  = clamp(0.6 + 0.3 * END_GLOW, 0.0, 1.0);
#else
    float boost = 2.0;
    float mask  = 0.6;
#endif
    gl_FragData[0] = vec4(toLinear(tex.rgb) * boost, tex.a);
    gl_FragData[1] = vec4(mask, 0.0, 0.0, tex.a);   // maska bloomu
}
