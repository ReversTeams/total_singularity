#version 120
// gbuffers_textured.fsh - czasteczki, reka. Jasne czasteczki w pelnym swietle lekko swieca (bloom).
#include "/lib/common.glsl"
#include "/lib/shadow.glsl"
#include "/lib/handlight.glsl"

uniform sampler2D texture;
uniform vec3  sunPosition;
uniform vec3  moonPosition;
uniform vec3  upPosition;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPosV;

/* DRAWBUFFERS:01 */
void main()
{
    vec4 tex = texture2D(texture, texcoord) * glcolor;
    if (tex.a < 0.01) discard;
    vec3 albedo = toLinear(tex.rgb);

    vec3 sunVec = normalize(sunPosition), moonVec = normalize(moonPosition), upVec = normalize(upPosition);
    vec3 N = (dot(normal, normal) < 0.01) ? upVec : normalize(normal);

    float emis = smoothstep(0.92, 1.0, lmcoord.x) * smoothstep(0.20, 0.70, max(albedo.r, max(albedo.g, albedo.b))) * 0.6;
    float shadow = getShadow(viewPosV, N, lmcoord.y, gl_FragCoord.xy);
    vec3 color = calcLighting(albedo, lmcoord, N, sunVec, moonVec, upVec, emis, rainStrength, shadow);
    color += albedo * handLight(viewPosV, N);   // swiatlo z reki

    gl_FragData[0] = vec4(color, tex.a);
    gl_FragData[1] = vec4(emis, 0.0, 0.0, tex.a);
}
