#version 120
// gbuffers_armor_glint.fsh - blysk zaklec: addytywny, nieoswietlony
#include "/lib/common.glsl"

uniform sampler2D texture;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPosV;

/* DRAWBUFFERS:0 */
void main()
{
    vec4 tex = texture2D(texture, texcoord) * glcolor;
    if (tex.a < 0.01) discard;
    gl_FragData[0] = vec4(toLinear(tex.rgb) * 1.35, tex.a);
}
