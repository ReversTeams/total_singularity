#version 120
// =====================================================================
//  gbuffers_water.fsh (v17) - warstwa POWIERZCHNI wody
//
//  Woda jest teraz liczona w dwoch krokach:
//   1) TU: odbicie nieba (Fresnel + gwiazdy/zorza w nocy), blyski slonca,
//      magiczne iskry. Wynik trafia do colortex3 (NIE jest blendowany z dnem).
//      colortex0 zostaje nietkniety (alpha = 0), wiec dno jest czyste.
//   2) composite1.fsh: cialo wody (zalamanie, pochlanianie Beera, kaustyka,
//      piana) liczone z prawdziwej glebokosci, potem nalozenie odbicia.
//
//  colortex1: r = iskry (bloom), g = 0.6 maska wody, b = 0.15 * skylight,
//             a = 0.6 (waga blendu, patrz composite1: isWaterPixel)
//  Pod woda (isEyeInWater) tafla jest rysowana klasycznie do colortex0:
//  okno Snella (widac swiat nad woda) + lustro calkowitego odbicia na brzegach.
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/water.glsl"
#include "/lib/handlight.glsl"
#include "/lib/skyfx.glsl"
#include "/lib/shadow.glsl"

uniform sampler2D texture;
uniform mat4  gbufferModelView;
uniform vec3  sunPosition;
uniform vec3  moonPosition;
uniform vec3  upPosition;
uniform int   isEyeInWater;

varying vec2  texcoord;
varying vec2  lmcoord;
varying vec4  glcolor;
varying vec3  normal;
varying vec3  viewPos;
varying vec3  worldPos;
varying float isWater;
varying float topFace;

/* DRAWBUFFERS:013 */
void main()
{
    vec4 tex = texture2D(texture, texcoord);

    vec3 sunVec  = normalize(sunPosition);
    vec3 moonVec = normalize(moonPosition);
    vec3 upVec   = normalize(upPosition);
    float sunHeight = dot(sunVec, upVec);
    vec3 viewDir = normalize(viewPos);
    vec3 N       = normalize(normal);
    vec3 Ng      = N;                                    // geometryczna normalna tafli (do cieni)

    vec4  out0 = vec4(0.0);
    vec4  out1 = vec4(0.0);
    vec4  out3 = vec4(0.0);          // a = 1 tylko dla powierzchni wody widzianej znad wody

    if (isWater > 0.5)
    {
        float day  = dayFactor(sunHeight);
        float dist = length(viewPos);
        float t    = frameTimeCounter * WATER_WAVE_SPEED;

        if (topFace > 0.5)
        {
            vec3 nw = waterNormalWorld(worldPos.xz, t, dist, rainStrength);
            N = normalize(mat3(gbufferModelView) * nw);
        }
        if (dot(N, -viewDir) < 0.0) N = -N;                 // normalna zawsze do kamery (takze od spodu)
        float cosT = clamp(dot(-viewDir, N), 0.0, 1.0);

        if (isEyeInWater == 1)
        {
            // Patrzymy na tafle od spodu: okno Snella (~48 st.) przepuszcza swiat nad woda,
            // poza nim - total internal reflection (kolor wody pod powierzchnia).
            float window = smoothstep(0.25, 0.85, cosT);           // miekkie przejscie zamiast ostrego kola
            out0 = vec4(UNDERWATER_COLOR(day), mix(0.75, 0.05, window));
        }
        else
        {
            float skyL = pow(lmcoord.y, 2.0);                // brak odbic w jaskiniach

            // Fresnel (bazowo 3.5% - odrobine wiecej niz fizyczne 2%, zeby tafla zyla)
            float F = clamp((0.035 + 0.965 * pow(1.0 - cosT, 5.0)) * WATER_REFLECTION, 0.0, 1.0);

            vec3  refl = reflect(viewDir, N);
            float ru   = dot(refl, upVec);
            if (ru < 0.03) refl = normalize(refl + upVec * (0.03 - ru));   // odbicie nigdy "w dol"

            vec3 skyR = applyRainToSky(getSkyColor(refl, sunVec, moonVec, upVec), rainStrength);
#if defined(WATER_SKY_FX) && !defined(DIM_NETHER) && !defined(DIM_END)
            float night = (1.0 - day) * (1.0 - rainStrength);
            if (night > 0.01)
            {
                vec3 dirW = mat3(gbufferModelViewInverse) * refl;
                skyR += nightSkyEffectsSoft(dirW, night, max(dot(refl, upVec), 0.0));
            }
#endif

            vec3 add = vec3(0.0);

            // blyski: ostry punkt + miekka poswiata wokol (slonce w dzien, ksiezyc w nocy)
            vec3  L    = (day > 0.5) ? sunVec : moonVec;
            float ld   = max(dot(refl, L), 0.0);
            float spec = pow(ld, 300.0) + 0.08 * pow(ld, 24.0);
            // cien na tafli (liscie, nawisy, gory): blysk slonca/ksiezyca tylko tam, gdzie swiatlo naprawde dochodzi.
            // Mapa cieni jest czytana tylko w poblizu sciezki blysku (ld > 0.8) - tam gdzie to widac.
            float glintShadow = 1.0;
            if (ld > 0.8 && WATER_GLINT > 0.001) glintShadow = getShadow(viewPos, Ng, lmcoord.y, gl_FragCoord.xy);
            add += getLightColor(sunHeight) * spec * WATER_GLINT * skyL * (1.0 - rainStrength) * glintShadow;

            // magiczne iskry (w nocy chlodne, cyjan/fiolet; w dzien cieple, delikatne)
            float spkMask = 0.0;
            if (WATER_SPARKLES > 0.001 && topFace > 0.5 && dist < 70.0)    // fade ponizej juz zeruje blysk
            {
                float hh;
                float spk  = waterSparkle(worldPos.xz, frameTimeCounter, hh);
                float fade = (1.0 - smoothstep(25.0, 70.0, dist)) * skyL * (1.0 - rainStrength * 0.8);
                vec3  sc   = mix(vec3(1.0, 0.92, 0.75),
                                 mix(vec3(0.5, 0.85, 1.2), vec3(1.1, 0.6, 1.1), fract(hh * 37.0)),
                                 1.0 - day);
                float inten = (0.6 + 2.2 * (1.0 - day)) * WATER_SPARKLES * spk * fade;
                add += sc * inten;
                spkMask = clamp(inten * 0.5, 0.0, 1.0);
            }

            // swiatlo z reki (latarka nad woda delikatnie swieci na tafli)
            add += toLinear(WATER_COLOR) * handLight(viewPos, N) * 0.35;

#ifdef WATER_USE_COMPAT
            // Tryb zgodnosci: woda rysowana od razu w tym przebiegu (kolor + odbicie + alpha), bez maski w colortex1
            // i bez zadnej pracy w composite1 - widoczna w kazdej wersji gry. Bez zalamania, kaustyki i piany.
            vec3  body = toLinear(WATER_COLOR) * 0.30 * (0.12 + 0.88 * day) * mix(0.25, 1.0, lmcoord.y);
            float a    = clamp(0.55 + 0.40 * F, 0.0, 1.0);
            out0 = vec4(mix(body, skyR * skyL, F) + add / a, a);
            out1 = vec4(0.0);
            out3 = vec4(0.0);
#else
            out3 = vec4(skyR * (F * skyL) + add, 1.0);       // odbicie JUZ przemnozone przez Fresnela
            out1 = vec4(spkMask, 1.0, 0.25 * lmcoord.y, 0.6);
#endif
        }
    }
    else
    {
        // szyba, lod, witraze itp.
        float alpha = tex.a * glcolor.a;
        if (alpha < 0.004) discard;                          // w pelni przezroczyste teksele nie pisza glebi
        vec3 albedo = toLinear(tex.rgb * glcolor.rgb);
        vec3 color = calcLighting(albedo, lmcoord, N, sunVec, moonVec, upVec, 0.0, rainStrength, 1.0);
        color += albedo * handLight(viewPos, N);             // swiatlo z reki
        out0 = vec4(color, alpha);
        // lod / szklo PRZED woda: zeruje maske wody (g) tam, gdzie jest wyraznie widoczne (alpha > ~0.25),
        // inaczej composite1 malowalby wode na lodzie. Przy braku blendu bufor jest po prostu zerowany.
        out1 = vec4(0.0, 0.0, 0.0, alpha);
    }

    gl_FragData[0] = out0;
    gl_FragData[1] = out1;
    gl_FragData[2] = out3;
}
