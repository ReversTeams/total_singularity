#version 120
// =====================================================================
//  gbuffers_block.vsh - bloki: machanie lisci / trawy na wietrze
//  ID z block.properties:  10001 = liscie, 10002 = trawa/kwiaty/uprawy,
//                          10003/10004 = dolna/gorna polowa wysokich roslin
//                          10010 = bloki swiecace, 10011 = swiatlo dusz (cyan)
// =====================================================================
#include "/lib/settings.glsl"
#include "/lib/wind.glsl"

attribute vec4 mc_Entity;
attribute vec4 at_tangent;
attribute vec4 mc_midTexCoord;

uniform mat4  gbufferModelView;
uniform mat4  gbufferModelViewInverse;
uniform vec3  cameraPosition;
uniform float frameTimeCounter;
uniform float rainStrength;

varying vec2  texcoord;
varying vec2  lmcoord;
varying vec4  glcolor;
varying vec3  normal;
varying float emissive;
varying vec3  viewPosV;
varying vec3  tangentV;
varying vec3  bitangentV;
varying float plantFlag;
varying float foliageKind;   // 0 brak, 1 liscie, 2 rosliny, 3 trawa na ziemi
varying float plantShade;    // przyciemnienie podstawy traw
varying vec3  wposV;         // pozycja w swiecie (zmiennosc koloru)

void main()
{
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lmcoord  = clamp((lmcoord - 0.03125) * 1.06667, 0.0, 1.0);
    glcolor  = gl_Color;
    normal   = normalize(gl_NormalMatrix * gl_Normal);
    tangentV   = normalize(gl_NormalMatrix * at_tangent.xyz);
    bitangentV = normalize(gl_NormalMatrix * (cross(at_tangent.xyz, gl_Normal) * at_tangent.w));

    float id      = mc_Entity.x;
    float isLeaf  = float(abs(id - 10001.0) < 0.5);
    float isPlant = float(abs(id - 10002.0) < 0.5);   // roslina jednoblokowa
    float isLower = float(abs(id - 10003.0) < 0.5);   // dolna polowa rosliny dwublokowej
    float isUpper = float(abs(id - 10004.0) < 0.5);   // gorna polowa rosliny dwublokowej
    float anyPlant = isPlant + isLower + isUpper;
    plantFlag = anyPlant;                              // rosliny: bez normal map
    float isGround = float(abs(id - 10005.0) < 0.5);   // blok trawy (tylko zmiennosc koloru)
    foliageKind = isLeaf + 2.0 * anyPlant + 3.0 * isGround;

    // przyciemnienie przy ziemi: dol roslin ciemniejszy, gora jasna (dolna/gorna polowa wysokich - ciagle)
    float topV = float(gl_MultiTexCoord0.t < mc_midTexCoord.t);
    plantShade = 1.0;
    if (isPlant > 0.5) plantShade = mix(0.62, 1.00, topV);
    if (isLower > 0.5) plantShade = mix(0.62, 0.85, topV);
    if (isUpper > 0.5) plantShade = mix(0.85, 1.00, topV);
    emissive      = float(abs(id - 10010.0) < 0.5) + 2.0 * float(abs(id - 10011.0) < 0.5)
                  + 3.0 * float(abs(id - 10012.0) < 0.5) + 4.0 * float(abs(id - 10013.0) < 0.5);

    // roslinki: normalna "do gory" -> rowne, miekkie oswietlenie
    if (anyPlant > 0.5) normal = normalize(mat3(gbufferModelView) * vec3(0.0, 1.0, 0.0));

    vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
    vec4 eyePos  = gbufferModelViewInverse * viewPos;   // pozycja wzgledem kamery (osie swiata)
    wposV = eyePos.xyz + cameraPosition;

#ifdef WAVING_FOLIAGE
    if (isLeaf + anyPlant > 0.5)
    {
        // Waga: liscie ruszaja sie cale (slabo), trawa tylko gorna czescia (podstawa zakorzeniona)
        // dolna polowa: gora = 0.5, gorna polowa: dol = 0.5, gora = 1.0 -> ciagly ksztalt na styku
        float weight = isLeaf * 0.45 + isPlant * topV + isLower * topV * 0.5 + isUpper * (0.5 + 0.5 * topV);
        eyePos.xyz += windOffset(wposV, weight, frameTimeCounter * WAVE_SPEED, rainStrength);
    }
#endif

    viewPos     = gbufferModelView * eyePos;
    viewPosV    = viewPos.xyz;
    gl_Position = gl_ProjectionMatrix * viewPos;
}
