#version 120
// gbuffers_damagedblock.fsh - pekniecia przy kopaniu.
// Vanilla nakłada ten sprite mnozeniem na blok (szary ~0.5 = neutralny), wiec oddajemy
// teksture bez oswietlenia i bez konwersji gamma - inaczej pekniecia sa za ciemne.
uniform sampler2D texture;

varying vec2 texcoord;
varying vec4 glcolor;

/* DRAWBUFFERS:0 */
void main()
{
    vec4 tex = texture2D(texture, texcoord) * glcolor;
    if (tex.a < 0.01) discard;
    gl_FragData[0] = tex;
}
