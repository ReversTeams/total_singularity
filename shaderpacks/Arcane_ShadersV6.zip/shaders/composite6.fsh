#version 120
// =====================================================================
//  composite6.fsh - BLOOM: poziom 2: zmniejszenie 2x + rozmycie poziome (colortex5 -> colortex3)
//  Piramida o zredukowanej rozdzielczosci (lib/bloom.glsl) - ok. 30x mniej pracy niz
//  dawna kaskada w pelnej rozdzielczosci.
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/bloom.glsl"

uniform sampler2D colortex5;

/* DRAWBUFFERS:3 */
void main()
{
    vec3 sum = vec3(0.0);
#ifdef BLOOM
    if (bloomInside(BLOOM_LV2))
        sum = bloomDownBlurH(colortex5, gl_FragCoord.xy, BLOOM_LV2, BLOOM_LV1, BLOOM_RADIUS * 0.5);
#endif
    gl_FragData[0] = vec4(sum, 1.0);
}
