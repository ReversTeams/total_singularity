#version 120
// gbuffers_entities.fsh - moby i encje (z czerwonym blyskiem po uderzeniu)
#include "/lib/common.glsl"
#include "/lib/shadow.glsl"
#include "/lib/handlight.glsl"
#include "/lib/endpalette.glsl"

uniform sampler2D texture;
uniform vec4  entityColor;
uniform int   entityId;          // z entity.properties (10100 = krysztal Endu)
uniform vec3  sunPosition;
uniform vec3  moonPosition;
uniform vec3  upPosition;

varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 glcolor;
varying vec3 normal;
varying vec3 viewPosV;

/* DRAWBUFFERS:012 */
void main()
{
    vec4 tex = texture2D(texture, texcoord) * glcolor;
    if (tex.a < 0.01) discard;
    tex.rgb = mix(tex.rgb, entityColor.rgb, entityColor.a);
    vec3 albedo = toLinear(tex.rgb);

    vec3 sunVec = normalize(sunPosition), moonVec = normalize(moonPosition), upVec = normalize(upPosition);
    vec3 N = (dot(normal, normal) < 0.01) ? upVec : normalize(normal);

    float shadow = getShadow(viewPosV, N, lmcoord.y, gl_FragCoord.xy);
    vec3 color = calcLighting(albedo, lmcoord, N, sunVec, moonVec, upVec, 0.0, rainStrength, shadow);
    color += albedo * handLight(viewPosV, N);   // swiatlo z reki

    // krysztal Endu: jasne, nasycone fragmenty swieca (rdzen i szklo)
    float emisE = 0.0;
    if (entityId == 10100)
    {
        emisE = clamp(emissiveStrength(albedo, 1.0) + endGlowStrength(albedo), 0.0, 1.0) * END_GLOW;
        color += albedo * mix(vec3(1.0), END_COL_C * 1.5, 0.35) * emisE * EMISSIVE_BRIGHTNESS * 1.6
               * (0.88 + 0.12 * sin(frameTimeCounter * 1.3));
    }
    gl_FragData[0] = vec4(color, tex.a);
    gl_FragData[1] = vec4(clamp(emisE, 0.0, 1.0), 0.0, 0.0, emisE > 0.001 ? 1.0 : 0.0);
    gl_FragData[2] = vec4(N * 0.5 + 0.5, step(0.5, tex.a));   // normalna dla SSAO
}
