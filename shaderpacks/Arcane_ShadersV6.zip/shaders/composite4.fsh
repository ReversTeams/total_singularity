#version 120
// =====================================================================
//  composite4.fsh - BLOOM: poziom 1, rozmycie poziome (colortex3 -> colortex4)
//  Piramida o zredukowanej rozdzielczosci (lib/bloom.glsl) - ok. 30x mniej pracy niz
//  dawna kaskada w pelnej rozdzielczosci.
// =====================================================================
#include "/lib/common.glsl"
#include "/lib/bloom.glsl"

uniform sampler2D colortex3;

/* DRAWBUFFERS:4 */
void main()
{
    vec3 sum = vec3(0.0);
#ifdef BLOOM
    if (bloomInside(BLOOM_LV1))
        sum = bloomBlur(colortex3, gl_FragCoord.xy, vec2(1.0, 0.0), BLOOM_LV1, BLOOM_RADIUS * 0.25);
#endif
    gl_FragData[0] = vec4(sum, 1.0);
}
