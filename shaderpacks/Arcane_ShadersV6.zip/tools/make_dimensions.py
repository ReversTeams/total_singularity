#!/usr/bin/env python3
"""
Generuje foldery wymiarow  shaders/world-1 (Nether)  i  shaders/world1 (End).
Kazdy program z shaders/ jest kopiowany z dopisanym  #define DIM_NETHER / DIM_END
(po linii #version), dzieki czemu lib/common.glsl wybiera oswietlenie, niebo i mgle
wlasciwe dla wymiaru. Cienie sa w nich wylaczone (puste programy shadow).

Uruchom po kazdej zmianie plikow w shaders/ :   python3 tools/make_dimensions.py
"""
import os, shutil, sys
here = os.path.dirname(os.path.abspath(__file__))
root = os.path.join(here, '..', 'shaders')
dims = {'world-1': 'DIM_NETHER', 'world1': 'DIM_END'}
SHADOW_VSH = "#version 120\n// puste cienie - w tym wymiarze nie ma slonca\nvoid main() { gl_Position = vec4(2.0, 2.0, 2.0, 1.0); }\n"
SHADOW_FSH = "#version 120\nvoid main() { gl_FragData[0] = vec4(0.0); }\n"
for folder, macro in dims.items():
    out = os.path.join(root, folder)
    shutil.rmtree(out, ignore_errors=True)
    os.makedirs(out)
    for f in sorted(os.listdir(root)):
        if not f.endswith(('.vsh', '.fsh')):
            continue
        s = open(os.path.join(root, f)).read()
        s = s.replace('#version 120\n', '#version 120\n#define %s\n' % macro, 1)
        open(os.path.join(out, f), 'w').write(s)
    open(os.path.join(out, 'shadow.vsh'), 'w').write(SHADOW_VSH)
    open(os.path.join(out, 'shadow.fsh'), 'w').write(SHADOW_FSH)
    print('%s: %d programow (%s)' % (folder, len(os.listdir(out)), macro))
