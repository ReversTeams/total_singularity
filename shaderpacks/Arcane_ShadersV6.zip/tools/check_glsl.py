#!/usr/bin/env python3
"""
Sprawdza kompilacje GLSL wszystkich programow (glslangValidator) - tak jak to robiono przy v17+.
Rozwija  #include "/lib/..."  (jak Iris / OptiFine), a opcjonalne -D dopisuje po #version.

Uzycie:
    python3 tools/check_glsl.py                       # wszystkie programy, domyslne opcje
    python3 tools/check_glsl.py -D FANTASY_RAIN       # z dodatkowym #define
    python3 tools/check_glsl.py --only gbuffers_weather composite1
    python3 tools/check_glsl.py --undef FANTASY_RAIN  # wylacza opcje zdefiniowana w settings.glsl
"""
import argparse, os, re, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, '..', 'shaders'))
INC = re.compile(r'^\s*#include\s+"(/[^"]+)"\s*$')


def expand(path, seen=None):
    out = []
    with open(path, encoding='utf-8') as f:
        for line in f:
            m = INC.match(line)
            if m:
                out.append(expand(os.path.join(ROOT, m.group(1).lstrip('/'))))
            else:
                out.append(line)
    return ''.join(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('-D', action='append', default=[], help='dodatkowe #define (NAME lub NAME=VAL)')
    ap.add_argument('--undef', action='append', default=[], help='#undef po settings.glsl')
    ap.add_argument('--dim', choices=['overworld', 'nether', 'end'], default='overworld')
    ap.add_argument('--only', nargs='*', default=None, help='tylko te programy (bez rozszerzenia)')
    args = ap.parse_args()

    folder = {'overworld': ROOT, 'nether': os.path.join(ROOT, 'world-1'), 'end': os.path.join(ROOT, 'world1')}[args.dim]
    # programy w world-1 / world1 sa juz po make_dimensions (maja #define DIM_*), a include liczymy wzgledem ROOT
    files = sorted(f for f in os.listdir(folder) if f.endswith(('.vsh', '.fsh')))
    if args.only:
        files = [f for f in files if os.path.splitext(f)[0] in args.only]

    bad = 0
    for f in files:
        src = expand(os.path.join(folder, f))
        defs = ''.join('#define %s\n' % d.replace('=', ' ') for d in args.D)
        # #version musi byc pierwsza linia; po niej dopisujemy define'y
        m = re.match(r'(#version[^\n]*\n)', src)
        head, body = (m.group(1), src[m.end():]) if m else ('', src)
        # #undef trzeba wstawic po wszystkich definicjach z settings - zaraz po ostatnim #endif settings jest trudno,
        # wiec dopisujemy undef na samym poczatku kodu i w settings.glsl define nie wraca: prosta metoda = zamiana tekstu
        for u in args.undef:
            body = re.sub(r'(?m)^(\s*#define\s+%s\b.*)$' % re.escape(u), r'// \1', body)
        text = head + defs + body
        ext = '.vert' if f.endswith('.vsh') else '.frag'
        with tempfile.NamedTemporaryFile('w', suffix=ext, delete=False) as tf:
            tf.write(text)
            tmp = tf.name
        r = subprocess.run(['glslangValidator', tmp], capture_output=True, text=True)
        os.unlink(tmp)
        if r.returncode != 0:
            bad += 1
            print('BLAD  %s/%s' % (os.path.basename(folder), f))
            print('\n'.join('   ' + l for l in (r.stdout + r.stderr).strip().splitlines()[:12]))
    print('%s: %d programow, %d bledow' % (os.path.basename(folder) if folder != ROOT else 'shaders', len(files), bad))
    sys.exit(1 if bad else 0)


if __name__ == '__main__':
    main()
