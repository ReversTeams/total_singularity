FANTASY MAGICAL SHADERS (Minecraft 1.20.1, Iris / Oculus / OptiFine)

Instalacja:
 1. Wrzuc caly plik .zip (NIE rozpakowany) do folderu  .minecraft/shaderpacks
 2. Gra -> Opcje -> Ustawienia grafiki -> Shadery -> wybierz FantasyMagical_Shaders.zip
 3. Dostosowanie: Shader Settings (suwaki) albo edycja shaders/lib/settings.glsl

Wskazowki:
 - Jesli widac krawedz renderowanych chunkow, ustaw "Fog Distance" recznie (np. 192).
 - Pack ma osobne programy dla Nether i End (foldery world-1 / world1, generowane skryptem - patrz nizej).

Zmiany w tej wersji:
 * WYDAJNOSC (FPS):
   - SPADEK FPS TYLEM DO SLONCA (glowna przyczyna): dodano const float shadowDistanceRenderMul = 1.0 (lib/settings.glsl).
     Bez tego Iris/OptiFine rysowaly do shadow mapy teren az do granicy renderowania (cienie i tak sa liczone tylko do
     shadowDistance), a najwiecej takiej geometrii trafia do przebiegu cieni, gdy patrzymy tylem do slonca.
   - SPRZETOWE FILTROWANIE CIENI (opcja Shadows -> Hardware Shadow Filtering, domyslnie wlaczona): shadowtex1 jako sampler2DShadow
     (const bool shadowHardwareFiltering). Jeden odczyt = porownanie i mieszanie 2x2 tekseli, wiec filtr krawedzi ma o polowe mniej probek
     (SHADOW_SAMPLES 8 -> 4 odczyty) przy tej samej miekkosci; etap 1 (klasyfikacja swiatlo/cien) tez jest gladszy. Po wylaczeniu wraca
     reczne porownywanie (sampler2D). Funkcja shadowTap() w lib/shadow.glsl.
   - WIATR (LOD): przesuniecie lisci/trawy gasnie miedzy 64 a 96 blokow (w shadow mapie miedzy 40 a 60 - tam wiatr to < 1 teksel),
     szybkie drzenie ("flutter") znika po 40 blokach; dalej nie liczymy ani sin(), ani przesuniecia. lib/wind.glsl, WIND_FADE_* w settings.
   - CHMURY: marsz cieniowania ma tyle krokow, ile potrzeba (2 przy wysokim sloncu, gdzie droga swiatla ma ulamek teksela; 4 przy niskim) -
     blad < 0.01. Srebrna obwodka liczona tylko w poblizu slonca (poza nim jej wklad < 1%).
   - EFEKTY ZANIKAJACE Z ODLEGLOSCIA: normal mapy i polysk PBR gasna miedzy 32 a 56 blokow (daleko normal-mapa nie jest nawet
     czytana; emisja i kolor zostaja, metal przechodzi w zwykle swiatlo rozproszone), zalamanie wody po 64 blokach,
     kaustyka po 70, piana po 80, iskry na wodzie po 70. Pod-pikselowe detale daleko i tak tylko migotaly.
   - ODROCZONE OSWIETLENIE TERENU (opcja Quality -> Deferred Lighting, domyslnie wlaczona): gbuffers_terrain.fsh zapisuje
     tylko albedo i dane materialu (lib/gbuf.glsl), a nowy program deferred.fsh liczy cien, swiatlo, PBR, swiatlo z reki
     i SSS RAZ NA PIKSEL EKRANU - bez kosztu overdrawu warstw lisci i trawy. Dziala przed woda / szklem (deferred), wiec
     woda, refrakcja i mgla zachowuja sie jak dawniej. Lawa, byty, bloki-byty, reka i woda nadal maja swiatlo w swoich
     shaderach. Wylacz opcje, jesli widzisz bledy - wraca klasyczny tryb. Znacznik piksela: colortex1.a = 0.2.
     G-buffer terenu: colortex0 albedo, colortex1 lightmapa, colortex2 normalna, colortex4 (ao, emisja, kod materialu),
     colortex5 (normalna po normal-mapie, gladkosc, F0). Program wylaczany razem z opcja (program.deferred.enabled).
   - BLOOM: piramida o zredukowanej rozdzielczosci (lib/bloom.glsl): poziomy 1/2, 1/4 i 1/8 ekranu, 9 przebiegow
     (composite3..composite9; composite10 usuniety). Ok. 30x mniej pobran tekstur niz dawna kaskada w pelnej
     rozdzielczosci. Przy wylaczonym Bloom wszystkie te przebiegi sa pomijane (program.compositeN.enabled).
     Halo jest nieco miekkie i szersze w rdzeniu; jesli chcesz ostrzej - zmniejsz Bloom Radius.
   - CIENIE: filtr bez sin/cos na probke (spirala Vogela przez obrot), tani etap 4 probek dla roslin i lisci
     (duzo overdrawu), pelny filtr tylko do 36 blokow. To byl powod spadku FPS przy staniu tylem do slonca
     (wtedy wszystkie widoczne sciany sa oswietlone i licza cien; przodem do slonca sa tylem do swiatla i go omijaja).
   - Profile LOW i MEDIUM wylaczaja Plant Shadows (trawa/kwiaty nie renderuja sie do shadow mapy).
   - Domyslny zasieg cieni 96 -> 72 blokow (profile: MEDIUM 56, HIGH 72, ULTRA 96, MAXIMUM 160): mniej geometrii w shadow mapie, a cienie sa ostrzejsze (ta sama rozdzielczosc na mniejszym obszarze).
   - Motion Blur, SSAO i God Rays nie kosztuja nic po wylaczeniu (pominiete przebiegi).
 * SSAO "brudne / poszarpane": wzorzec Bayera 4x4 + odszumianie oknem 4x4 w composite1 (zamiast losowego szumu),
   rosliny i liscie nie dostaja SSAO i nie zaslaniaja innych pikseli (znacznik w colortex2.a = 0.6),
   a w pelnym sloncu AO slabnie do 30% (mnoznik w colortex1.a) - AO dziala glownie w cieniu / swietle otoczenia.
 * End: niebo rysowane takze w composite1 (naprawa szarego nieba w MC 26+).
 + Nowe programy: swiecace oczy mobow, blysk zaklec, wiazka latarni,
   peknice przy kopaniu, przezroczystosci w rece, blokowe encje (skrzynie...),
   czasteczki oswietlone - brak dziur w renderingu na 1.20.1.
 + Mgla w sypkim sniegu.
 + Migotanie swiatla pochodni (suwak: Torch Flicker).
 + Ogień dusz (soul torch / lantern / fire) swieci na cyanowo - osobne ID 10011.
 + Wiecej roslin machajacych na wietrze (bambus, trzcina, dripleaf, spore blossom...).
 + Bloki sculk i kociolek z lawa traktowane jako swiecace.
 + Suwak Shadow Distortion w menu cieni.

Poprawki v3:
 * Wysokie rosliny (wysoka trawa, slonecznik, bez, roza...) maja ciagly ksztalt - wiatr nie rozrywa ich
   na styku dwoch blokow.
 * Trzcina, bambus, wodorosty, pnącza i inne rosliny "sklejane w pionie" lub wiszace nie macha ja
   (wczesniej pekaly na stykach segmentow).
 * Pekniecia przy kopaniu maja wlasciwa jasnosc.

NOWOSCI v4:
 * SSAO (polowa rozdzielczosci) - glebia w naroznikach i pod drzewami.
 * labPBR - normal mapy, specular, emisja i metale z resource packow *_n / *_s.
   Bez takiej paczki tekstur nic sie nie zmienia.
 * SSR dla wody (polowa rozdzielczosci) - odbicia sceny, nie tylko nieba.
 * Nether (world-1) i End (world1) maja wlasne niebo, mgle i oswietlenie.
 * God Rays w polowie rozdzielczosci (SSAO, rays i SSR liczone razem w composite.fsh).

Foldery shaders/world-1 i shaders/world1 sa GENEROWANE:
   python3 tools/make_dimensions.py
Uruchom po kazdej zmianie plikow w shaders/, inaczej wymiary beda uzywac starej wersji.

v5: usunieto TAA (powodowal dziwne efekty). Dodano presety (Low..Maximum) i opisy opcji po najechaniu kursorem.

v6: ciemniejsza noc (suwak Night Brightness), wybor palety kolorow (6 motywow) i wlasna paleta (suwaki H/S/V).

v7: magiczne niebo (zorza, mglawica, spadajace gwiazdy), rozmycie ruchu (domyslnie wylaczone),
    lepsza roslinnosc (swiatlo przez liscie, zmiennosc koloru, cieniowanie podstaw, ruchome cienie lisci),
    (kolorowe swiatlo z blokow zostalo usuniete w v8).

v8: usunieto "Colored light from blocks".

v9: swiatlo z trzymanych swiecacych blokow (obie rece), kolor zalezy od przedmiotu (item.properties).

v11: mgla wolumetryczna usunieta. Cienie: dalekie krawedzie liczone taniej (4 probki zamiast pelnego filtra).

v12: usunieto odbicia SSR w wodzie (odbicie nieba zostaje); dodano flare soczewki przy patrzeniu na slonce.

v16: baza v12, usunieta flara soczewki (End z v12 bez zmian).

LATKA DEBUGUJACA (na bazie v16, przeglad statyczny):
 - Deklaracje formatow colortex przeniesione do poprawnego komentarza blokowego; bufory obrazu i danych SSAO/God Rays zachowuja precyzje HDR.
 - Poprawione odwrocone krawedzie smoothstep dla gwiazd i spadajacych gwiazd.
 - Profil LOW wylacza bloom; poprawione opisy opcji po usunieciu SSR.
 - Pliki tlumaczen maja nazwy en_us.lang / pl_pl.lang.
 - To latka po analizie kodu; wymaga jeszcze testu uruchomieniowego w Minecraft 1.20.1 (Iris/Oculus/OptiFine).

=====================================================================
v17 - NOWA WODA + poprawki z debugowania (baza: v16_1)
=====================================================================
WODA (calkowicie przebudowana):
 * Powierzchnia (gbuffers_water) liczy TYLKO odbicie nieba, blyski i iskry -> colortex3.
   Cialo wody (composite1) liczone z prawdziwej glebokosci: pochlanianie Beera-Lamberta
   (czerwien znika pierwsza), plytko jasny turkus -> gleboko ciemny z lekkim fioletem.
   Odbicia NIE znikaja juz w glebokiej wodzie (wczesniej mieszane z plaskim kolorem).
 * Brak "farby" na dnie: zniknal sztywny turkusowy kolor z alpha 0.45 i tekstura vanilla.
 * Fale: zaburzone szumem (domain warp) + zmarszczki z szumu -> brak powtarzalnego wzoru.
 * Zalamanie swiatla (dno faluje), kaustyka na dnie, piana + nocna poswiata przy brzegu,
   magiczne iskry, odbicie gwiazd / zorzy / mglawicy w nocy, miekka sciezka blasku slonca.
 * Pod woda: okno Snella - widac swiat nad woda, na brzegach odbicie od spodu
   (wczesniej tafla od spodu byla nieprzezroczystym "dekielkiem" w kolorze nieba).
 * Woda w jaskiniach ciemnieje (wczesniej swiecila turkusem dzieki stalej jasnosci).
 * Nowe opcje w menu Water: Murnosc, Odbicia, Blask slonca, Odbijaj nocne niebo,
   Zalamanie, Kaustyka, Piana, Iskry. Usunieto WATER_OPACITY (juz niepotrzebne).
   Profil LOW wylacza kaustyke, zalamanie i odbicia nocnego nieba.
POPRAWKI:
 * pl_pl.lang: 26 nazw opcji (paleta, suwaki Custom, Night Brightness) bylo nadpisanych
   angielskimi opisami; en_us.lang mial polskie opisy. Naprawione (zamienione miejscami).
 * Szyby / lod: w pelni przezroczyste teksele nie zapisuja juz glebi (discard).
 * Zasniezony blok trawy nie dostaje zielono-zlotego odcienia (grass_block:snowy=false).
 * Jawny kolor czyszczenia colortex1 = 0 (maska emisji/wody nie zalezy od domyslnego bufora).
 * Efekty nocnego nieba przeniesione do lib/skyfx.glsl (wspolne dla nieba i wody).
NIE TESTOWANE W GRZE: kompilacja GLSL sprawdzona narzedziem glslang (138 programow x 32
konfiguracji opcji = 0 bledow), ale wyglad trzeba ocenic w Minecraft 1.20.1 (Iris/Oculus/OptiFine).
Dostrajanie wygladu wody: kolory - paleta / suwaki Custom; Murnosc; Sila zmarszczek.

v17.1 (poprawka po testach):
 * Magiczne iskry domyslnie WYLACZONE (biale kropki na wodzie) - wlacz suwakiem Magic Sparkles.
 * Zalamanie swiatla: domyslnie 0.5, probki przyjmowane tylko z tej samej glebokosci dna
   (wczesniej mogly rozmazywac ciemne boki blokow po krawedziach = "czarne krawedzie").
 * Piana nigdy nie jest ciemniejsza niz woda pod nia; maska wody dziala tez przy dwoch warstwach wody.
 Diagnoza, jesli czarne krawedzie zostana: ustaw po kolei Refraction=0, Shore Foam=0, Caustics=0
 i sprawdz, ktora opcja je usuwa (albo to zwykly czarny obrys zaznaczenia bloku z gry).

v17.2: woda nie odbija juz punktowych gwiazd ani spadajacych gwiazd (migaly jako male kropki).
 Zorza, mglawica, niebo, blask ksiezyca nadal sie odbijaja. Opcja "Odbijaj nocne niebo" dziala jak wczesniej.

v17.3: SZEROKI BLOOM. Nowe programy composite5/composite6 rozmywaja gotowy bloom jeszcze raz z duzym
 rozstawem probek (wynik w colortex5, czytany w final.fsh). Przy domyslnym promieniu halo ma ~3.7x wiekszy
 zasieg (sigma ~45 px zamiast ~12 px). Nowy suwak Effects -> Wide Bloom (0 = wylaczony, wtedy pass'y nic nie licza).
 Zasieg zalezy tez od Bloom Radius. Jesli halo jest zbyt mocne: zmniejsz Wide Bloom albo podnies Bloom Threshold.

v17.4: BLOOM bez "kwadratow". Przyczyna: jadro Gaussa bylo obciete (waga na krawedzi 14-22% szczytu) i pierwszy
 etap probkowal co 2-5 px, wiec mogl pominac maly jasny punkt (plomien pochodni). Teraz kaskada 4 etapow
 (rozstaw 1 -> 3 -> 8 -> 20 px, waga na krawedzi ~1%): bliskie halo (sigma ~5 px), srednie (~14 px, odpowiednik
 dawnego bloomu) i szerokie (~36 px, suwak Wide Bloom). Programy composite3..composite10, bufory colortex4/5/6.
 Zmierzone symulacja: profil rozmycia pojedynczego jasnego piksela jest monotoniczny (brak falowania).

v17.5: CIENIE NA BLYSKU SLONCA. Sciezka blasku slonca / ksiezyca na wodzie jest teraz zaslaniana przez cienie
 (liscie, nawisy, gory, budowle) - uzywa tej samej mapy cieni co teren. Mapa cieni jest czytana tylko tam,
 gdzie blysk jest widoczny, wiec koszt jest maly. Odbicie nieba zostaje (niebo jest swiatlem rozproszonym).
 Dziala tez dla ksiezyca w nocy; przy wylaczonych cieniach (SHADOWS) blysk dziala jak wczesniej.

v17.6: OSWIETLENIE CHMUR.
 * Srebrna obwodka (silver lining): cienkie brzegi chmur swieca, gdy patrzysz w strone slonca; najmocniej
   przy wschodzie/zachodzie (cieple swiatlo), wygaszana przez deszcz i gdy slonce jest pod horyzontem.
   Brzeg liczony z tekstury chmur (rozmyte pokrycie w srodkach 4 tekseli + interpolacja dwuliniowa,
   zeby nie bylo schodkow). Grube srodki chmur sa lekko ciemniejsze. Gorace jasne brzegi dodatkowo
   swieca przez bloom. Menu Atmosphere: Cloud Silver Lining (on/off), Silver Lining Strength.
 * Promienie swiatla przez chmury: gbuffers_clouds zapisuje znacznik w colortex2 (r=1, b=0 - taka normalna
   nie wystepuje w geometrii), a composite.fsh traktuje chmury jako czesciowo przepuszczajace (88% blokady)
   zamiast pelnej przeslony, wiec promienie wychodza przez luki. Teren/woda/szklo blokuja jak wczesniej.
   Menu Atmosphere: Cloud Light Shafts (wymaga God Rays). Jawny kolor czyszczenia colortex2 = 0.
 Zalozenie: tekstura chmur ma 256x256 (vanilla). Przy resource packu z inna tekstura zmien SIZE w
 gbuffers_clouds.fsh (cloudCover).

v17.7: NOWE NIEBO ENDU (ciemna fantazja). Plik lib/endsky.glsl, uzywany przez gbuffers_skytextured (skybox Endu
 zastepuje end_sky.png) i gbuffers_skybasic (zapas) oraz przez mgle terenu w composite1.
 Skladniki: prawie czarny indygo + slaba poswiata horyzontu, mglawica (szum 3D z zaburzeniem, dwa kolory palety,
 wstega galaktyki, ciemne pasma pylu, swiecace "zyly szczeliny"), kolorowe gwiazdy (gestsze w wstedze) +
 rzadkie duze z halo, spadajace gwiazdy, mgielka przy horyzoncie oraz Pusty Ksiezyc: czarna tarcza zaslaniajaca
 niebo, z korona (HDR -> bloom), cienka oswietlona krawedzia i pochylonym pierscieniem pylu.
 Mgla terenu w Endzie ma teraz kolor horyzontu nieba (wyspy gasna w tle).
 Menu: Koniec (Niebo): Styl (Fioletowa Pustka / Szkarlatna Szczelina / Szmaragdowa Otchlan), jasnosc mglawicy,
 jasnosc gwiazd, Pusty Ksiezyc (on/off). Overworld i Nether bez zmian.
 Podglad: kod nieba byl renderowany programowo (llvmpipe) - bez bloomu i mgly; wyglad w grze trzeba ocenic.

v17.8: MOCNIEJSZE AMBIENT OCCLUSION W ENDZIE (glebszy, ciemniejszy wyglad). Tylko wymiar End (DIM_END).
 * SSAO (composite.fsh): promien x(1 + 0.6*END_AO) i zasieg 128 bloków zamiast 96 -> szersze, miekkie zaciemnienie.
 * composite1.fsh: sila SSAO x END_AO, krzywa pow(ao, 1.35) (glebiej w zakamarkach prawie czern) oraz cien
   zabarwiony na fiolet (mnoznik 0.10/0.05/0.20 w pelnym zaciemnieniu) zamiast neutralnej szarosci.
 * lib/common.glsl: wypalone AO blokow (kolor wierzcholkow) w Endzie ma ostrzejsza krzywa (~ao^1.8) i nieco
   nizsze minimum swiatla otoczenia od dolu.
 * final.fsh: winieta w Endzie silniejsza o 0.6*END_DEPTH (max 0.85).
 Menu: Koniec (Niebo) -> Ambient Occlusion Strength (END_AO, domyslnie 1.5, 0 = jak Overworld), Screen Depth (END_DEPTH).
 SSAO musi byc wlaczone (profil LOW je wylacza). Weryfikacja: prawdziwa petla SSAO z composite.fsh uruchomiona
 programowo na scenie z blokow: plaska podloga daje AO = 1.000, brak halo na sylwetkach.

v18: WIEKSZA ZGODNOSC Z WERSJAMI MINECRAFTA (block.properties).
 Kod shaderow jest ten sam dla wszystkich wersji; roznice dotycza nazw blokow. Listy zawieraja teraz nazwy z wielu
 wersji naraz, a gra ignoruje te, ktorych w danej wersji nie ma:
   * "grass" (do 1.20.2) i "short_grass" (od 1.20.3) - machanie trawa
   * pale_oak_leaves (1.21.4), bush / short_dry_grass / tall_dry_grass / firefly_bush / wildflowers / cactus_flower /
     open_eyeblossom / closed_eyeblossom (1.21.x), torchflower_crop / pitcher_crop
   * copper_bulb (i warianty, lit=true), copper_torch / copper_lantern, glow_lichen - swiecace bloki
 WERSJE (stan wiedzy autora; nic nie bylo testowane w grze poza 1.20.1):
   1.20.1                 - docelowa, przetestowana
   1.16.5 - 1.20.6        - powinna dzialac (Iris / Oculus / OptiFine); nowsze bloki po prostu nie istnieja
   1.21.x                 - Iris (Fabric / NeoForge od 1.21.1); poprawnie dzialac maja: niebo, woda, bloom, cienie,
                            machanie roslin; mniej pewne: chmury (srebrna obwodka zaklada teksture 256x256 - jest
                            przelacznik), skybox Endu, nowe bloki
   Oculus (Forge) dziala tylko do 1.20.1; OptiFine mozna uzywac tylko tam, gdzie ma wydanie dla danej wersji.
 Przy starszych OptiFine (przed 1.17) dyrektywa #include moze nie dzialac - uzyj Iris/Oculus.

v18.1: NAPRAWA WODY / LODU W INNYCH WERSJACH MC (zgloszone: lod na wodzie wyglada jak woda w 1.21+, woda niewidoczna
 w 26.1+, lod na wodzie zepsuty w 1.16.5).
 Przyczyna: nowa woda (v17) jest rysowana w composite1 na podstawie maski w colortex1.g. (1) Lod/szklo rysowane PRZED
 woda nie zerowaly tej maski, wiec composite1 malowal wode takze na lodzie. (2) Maska byla przyjmowana tylko w zakresie
 0.45-0.95, czyli zakladala standardowy blend; gdy gra (nowsze wersje) nie blenduje tego bufora, maska = 1.0 i woda
 byla odrzucana (niewidoczna).
 Poprawki: maska przyjmowana od 0.45 w gore (chmury maja wlasny znacznik, wiec nie sa wodą); lod/szklo zeruja maske
 (out1 = (0,0,0,alpha)); nowa opcja Water -> "Woda: tryb zgodnosci" (WATER_COMPAT) - prosta klasyczna woda rysowana
 w jednym przebiegu, widoczna w kazdej wersji, bez zalamania/kaustyki/piany.
 NIE zweryfikowane w 1.16.5 / 1.21+ / 26.1+ - wymaga ponownego testu.

v19: SWIECACE BLOKI ENDU + AUTOMATYCZNY WYBOR TRYBU WODY.
 SWIECACE BLOKI ENDU (menu: Koniec (Niebo) -> Glowing End Blocks, END_GLOW, domyslnie 1.0):
 * lib/endpalette.glsl: wspolna paleta Endu (z endsky.glsl) + endGlowStrength() - swieca tylko jasne, nasycone piksele
   tekstury (magenta/fiolet/cyjan/roz); szare, ciemne i czarne fragmenty zostaja ciemne.
 * block.properties: 10012 = pelna poswiata (chorus_flower, dragon_egg, end_portal_frame:eye=true, ender_chest),
   10013 = slaba, 35% (purpur_*, chorus_plant, amethyst_block, budding_amethyst). Poza Endem poswiata x0.4.
   Kolor podbity w strone akcentu palety, delikatne pulsowanie; wchodzi do maski bloomu.
 * entity.properties: 10100 = end_crystal; gbuffers_entities.fsh czyta uniform entityId (swieci rdzen i szklo).
 * gbuffers_spidereyes.fsh: oczy endermanow i smoka w Endzie jasniejsze i mocniej bloomuja (zalezne od END_GLOW).
 * Rod Endu, ametystowe skupiska, crying obsidian i beacon juz swiecily (klasa 10010) - bez zmian.
 AUTO WYBOR TRYBU WODY (menu: Water -> Water Mode / WATER_MODE): 0 Auto (domyslnie), 1 Krysztalowa, 2 Zgodnosci.
 Auto wybiera prosta wode, gdy MC_VERSION >= 200000 (np. 26.1 = 260100 wg wzoru major*10000+minor*100+patch);
 w 1.16.5-1.21.x dziala nowa woda. ZALOZENIE: kodowanie MC_VERSION dla 26.x nie jest udokumentowane - jesli Iris
 koduje je inaczej, Auto nie zadziala i trzeba wybrac tryb recznie. Zastepuje opcje WATER_COMPAT.
 Zrodlo problemu w 26.x nieznane; Iris 1.11.4+ zmienil obsluge glebi (reverse-Z, tlumaczona dla paczek).

v20: CIENIOWANIE CHMUR (gbuffers_clouds.fsh; menu: Atmosphere -> Cloud Shading).
 * Chmury sa plaskie (clouds=fast), wiec glebie udajemy w przestrzeni tekstury chmur: od piksela marsz
   (CLOUD_SHADING_STEPS probek, domyslnie 4) w strone slonca / ksiezyca, rzutowany na plaszczyzne chmur
   (1 teksel = 12 blokow). Duzo chmury po drodze do swiatla = zacieniony brzeg; brzegi zwrocone do slonca zostaja jasne.
 * Grube srodki ciemniejsze (prawo Beera) z podlogowa jasnoscia (wielokrotne rozproszenie), a spod grubych chmur
   chlodniejszy i ciemniejszy (przyslonieta gorna polkula nieba). Deszcz zwieksza zaciemnienie.
 * Opcje: CLOUD_SHADING (wl/wyl), CLOUD_SHADING_STRENGTH 0-2, CLOUD_SHADING_STEPS 2-8. Profil LOW wylacza.
   Z wlaczonym cieniowaniem stare przyciemnienie srodka chmur (v17.6) jest pominiete; srebrna obwodka dziala jak dotad.
 * Programy uzywaja uniformu gbufferModelViewInverse (kierunek swiatla w swiecie -> osie tekstury: u = +X, v = +Z).
   ZALOZENIE: tak mapuja teksture chmur 1.20.1; jesli cien pada w zla strone (od slonca zamiast do niego),
   odkomentuj ukryte  #define CLOUD_LIGHT_FLIP  w lib/settings.glsl.
 * Kompilacja GLSL sprawdzona glslang (72 kombinacje: shading/silver/kroki/flip x Overworld/Nether/End).
   NIE TESTOWANE W GRZE - wyglad (sila 1.0, THICKNESS 18, MAX_BLOCKS 64) wymaga strojenia na zywo.
 * Foldery world-1 / world1 przegenerowane (tools/make_dimensions.py).
v21: NOWY NETHER (fantasy) - menu: The Nether. Nowy plik lib/nether.glsl, zmiany w composite1.fsh i lib/common.glsl.
 * ISKRY / ZARODNIKI / POPIOL (NETHER_EMBERS, NETHER_EMBER_AMOUNT): swiecace czasteczki 3D w swiecie gry (3 warstwy komorek
   2/4/8 blokow, 6 probek na warstwe, kazda czasteczka liczona raz), unosza sie w gore, kolysza sie, migocza, sa przeslaniane
   przez sciany i swieca HDR, wiec bloom je rozmywa. Kolor zalezy od biomu: pomaranczowe iskry (Wastes / Crimson),
   turkusowe zarodniki (Warped), blekitne dusze (Soul Sand Valley), lawendowy popiol (Basalt Deltas).
   Biom rozpoznawany z fogColor (bez uniformu biomu), wiec dziala w kazdej wersji; biomy plynnie sie mieszaja.
 * WIRUJACA MGLA (NETHER_FOG_SWIRL) + POSWIATA LAWY (NETHER_LAVA_GLOW): mgla faluje wstegami w kolorze biomu, gestnieje
   i rozjasnia sie przy poziomie lawy (y = 31). Piksele bez geometrii (horyzont) tez uzywaja tej mgly.
 * DRGANIE CIEPLA (NETHER_HEAT_HAZE): przesuniecie UV nad lawa na srednim dystansie (do ~2 px).
 * SWIATLO: dwutonowe - cieple odbicie lawy od dolu, rozowo-fioletowa magiczna mgla z gory; barwa wg biomu (NETHER_BIOME_TINT).
 * fogColor deklarowany teraz w lib/common.glsl (usunieto duplikaty z composite1.fsh i gbuffers_skybasic.fsh).
 * Profil LOW wylacza iskry i drganie ciepla. Przegenerowano world-1 / world1.
 * Kompilacja GLSL (glslang): 177 programow (wszystkie pliki x Overworld/Nether/End + warianty composite1 Nether) - 0 bledow.
   Symulacja CPU iskier: ok. 60 czasteczek na ekranie przy domyslnej ilosci, ~0.1% pikseli.
   NIE TESTOWANE W GRZE - jasnosc iskier (x3), sila mgly i drgania wymagaja strojenia na zywo.
v21.1: Nether - usunieta wirujaca mgla (opcja NETHER_FOG_SWIRL i szum netherSwirl). Mgla jest rowna i gesta, w kolorze biomu;
 przy poziomie lawy (y = 31) tylko gestsza i cieplej swieci (NETHER_LAVA_GLOW), a poswiata znika w pelnej mgle.
 Naprawione dziwne niebo: piksele bez geometrii to teraz dokladnie ten sam jednolity kolor co mgla (fogColor x1.2),
 takze w gbuffers_skybasic.fsh - bez szwu i gradientu na horyzoncie. Kompilacja: 177 programow, 0 bledow.
v22: NETHER - mgla i niebo (poprawka po testach).
 * WIRUJACA MGLA PRZYWROCONA, ale od nowa: szum gradientowy 3D (Perlin, quintic) zamiast szumu wartosciowego 2D.
   Stary szum (hash21 na duzych wspolrzednych swiata) dawal blokowe, powtarzalne wzory = "niska jakosc".
   Wspolrzedne komorek sa teraz zawijane (mod 256), wiec precyzja nie zalezy od pozycji w swiecie.
 * Mgla jest OBJETOSCIOWA: gestosc liczona w NETHER_FOG_STEPS (domyslnie 3) punktach wzdluz promienia + jedno wolne
   znieksztalcenie domeny na piksel (zawijasy), a nie w punkcie trafienia - wzor nie "przykleja sie" do scian jak tekstura.
 * NIEBO bez szwu: piksele bez geometrii uzywaja tej samej mgly przy dystansie far*DIM_FOG_RANGE, czyli tym samym co
   w pelni zamglony teren (dystans terenu jest przycinany do tej wartosci) - kolor na horyzoncie jest identyczny.
   Niebo faluje razem z mgla, a dolna czesc ma cieple swiatlo lawy.
 * Nowe opcje: NETHER_FOG_SWIRL (0 = rowna mgla), NETHER_FOG_STEPS 2-6. gbuffers_skybasic.fsh bez zmian wzgledem v21.1.
 * Podglad CPU algorytmu mgly: gladkie, bez siatki ani pasow. Kompilacja glslang: 177 programow, 0 bledow.
   NIE TESTOWANE W GRZE.
v22.1: NETHER - mniej mgly, spokojniejsze niebo (poprawka po testach).
 * NOWA OPCJA NETHER_FOG_AMOUNT (Gestosc mgly, domyslnie 0.75, zakres 0.25-1.5): mnoznik gestosci mgly w Netherze
   (tylko Nether, End bez zmian). Mniej = dalej widac teren; krawedz renderowania nadal ukryta.
 * Mgla nigdy nie jest gestsza niz bazowa: wiry tylko ja przerzedzaja w ciemnych wstegach (min. 70%), a poswiata lawy
   nie zageszcza juz mgly (zostala tylko jako cieple swiatlo).
 * Niebo i daleka mgla spokojniejsze: wiry w kolorze ~2x slabsze, jasne wstegi akcentu 0.07 -> 0.03, poswiata lawy 0.10 -> 0.06.
   Niebo nadal ma ten sam kolor co w pelni zamglony teren (brak szwu).
 * Kompilacja glslang: 177 programow, 0 bledow. Foldery world-1 / world1 przegenerowane. NIE TESTOWANE W GRZE.
v23: FANTASY LAWA (menu: Lava). Nowy plik lib/lava.glsl; zmiany: gbuffers_terrain.vsh/.fsh, block.properties, composite1.fsh.
 * Inspiracja: nastroj lawy z innych paczek (ciemna skorupa -> roztopiony pomaranczowy -> goracy rdzen, plynace wzory, fale).
   Implementacja WLASNA, inna metoda: wypaczony szum "grzbietowy" daje sieci plynacych zyl (zamiast mieszania dwoch scrolowanych
   szumow), skorupa lekko fioletowa, rampa kolorow szkarlat -> pomarancz -> zloto -> jasny rdzen, gorace "jeziora" w duzej skali,
   powolny oddech jasnosci, polysk przy ostrych katach. Ziarno oryginalnej tekstury lawy jest czesciowo zachowane.
 * Lawa ma wlasne ID (block.10020: lava + lava_cauldron; wczesniej byla w 10010). Flaga emissive = 5; endSoft ograniczone do 4.
 * Fale: tylko wierzcholki przy powierzchni (ulamkowa wysokosc), amplituda ~0.035 bloku, funkcja pozycji w swiecie
   (ciaglosc miedzy blokami i scianami). Maska emisji (bloom) z temperatury powierzchni.
 * Pod lawa (isEyeInWater == 2): gestsza, szkarlatno-zlota mgla, delikatnie pulsuje.
 * Opcje: FANTASY_LAVA (wyl = dawna lawa jako zwykly blok swiecacy), LAVA_BRIGHTNESS, LAVA_CRUST (0 = prawie caly roztopiony,
   1 = ciemna skorupa z cienkimi zylami; domyslnie 0.5), LAVA_FLOW_SPEED, LAVA_WAVES, LAVA_WAVE_HEIGHT.
 * Kompilacja glslang: 177 programow + 36 wariantow lawy (on/off x fale x wymiar), 0 bledow. Podglad wzoru wyrenderowany na CPU.
   NIE TESTOWANE W GRZE - jasnosc (rampa HDR) i skala wzoru wymagaja strojenia na zywo.
v23.1: LAWA - prostsza, bardziej "minecraftowa" (poprawka po testach).
 * Usuniete: wypaczone zyly, cienkie pekniecia i gorace "jeziora". Teraz jedna miekka, powoli plynaca warstwa plam
   (dwie skale szumu), pikselowana do siatki 2 px tekstury, a oryginalna tekstura lawy ma glowny wzor (80%).
 * Kolory: szkarlat -> pomarancz -> zloto (ta sama rampa, ale prawie bez czarnej skorupy). LAVA_CRUST zmieniona w "Kontrast lawy"
   (domyslnie 0.3 zamiast 0.5): ciemnoczerwone plamy. Fale, mgla pod lawa i opcje bez zmian.
 * Kompilacja glslang: 177 programow, 0 bledow. Podglad wzoru wyrenderowany na CPU. NIE TESTOWANE W GRZE.
v23.2: LAWA - lawospady. Kazda sciana lawy (x,y lub z,y) ma teraz wlasna plaszczyzne wzoru z przesunieciem zaleznym od pozycji
 i kierunku sciany (hash), wiec sasiednie lawospady (takze prostopadle) maja rozne wzory zamiast identycznych; wzor splywa w dol.
 Wczesniej sciany uzywaly wspolnego odwzorowania (x+z, y), przez co rozne sciany o tej samej sumie x+z wygladaly tak samo.
 Wyglad powierzchni bez zmian wzgledem v23.1 (prosta, pikselowana, ziarno tekstury z gry). shadeLava dostaje normalna swiata (Nw).
 Kompilacja glslang: 177 programow, 0 bledow. Foldery world-1 / world1 przegenerowane. NIE TESTOWANE W GRZE.
v24: DESZCZ (menu: Rain & Snow / Deszcz i snieg). Zmiany: gbuffers_weather.vsh/.fsh, composite1.fsh, composite.fsh (colortex7),
 lib/water.glsl, gbuffers_water.fsh, shaders.properties, lib/settings.glsl, lang/*.lang, nowe narzedzie tools/check_glsl.py.
 PRZYCZYNA "dziwnego / zepsutego" deszczu (znaleziona w kodzie): deszcz byl rysowany do colortex0 i nie zapisuje glebi, a composite1
 liczy mgle i wode wg glebi tego, co jest ZA deszczem. Skutki: (1) smuga 3 bloki od kamery przed odlegla gora dostawala mgle jak
 150 blokow dalej (rozpuszczala sie w mgle dokladnie na tle gor, a w deszczu mgla jest x2.2 gestsza); (2) nad woda smuga szla przez
 zalamanie i pochlanianie jak dno jeziora (ciemniala i falowala); (3) SSAO i god rays traktowaly ja jak teren. Do tego: twarda
 "sciana deszczu" na krawedzi zasiegu, ogromne pikselowe smugi tuz przy kamerze, szary kolor bez zwiazku z paleta, w nocy prawie niewidoczny.
 * FANTASY_RAIN (domyslnie wlaczone): gbuffers_weather zapisuje kolor + alfa do colortex7 (test glebi dziala, wiec sciany i dachy
   zaslaniaja deszcz), a composite1 doklada te warstwe na samym koncu, PO mgle / wodzie / SSAO. blend.gbuffers_weather sumuje alfa (pokrycie).
 * Kolor smugi = kolor nieba (= mgly) w jej kierunku + rozpraszanie swiatla do przodu (swieci patrzac na slonce / ksiezyc) + odcien
   z palety (AMBIENT_*) + w nocy slaba wlasna poswiata + rzadkie blyski na spadajacych kroplach. Suwak Magic Rain: 0 = realistyczny.
 * Zanikanie: na krawedzi zasiegu (z alfa wierzcholka: vanilla koduje tam odleglosc) i tuz przy kamerze.
 * Pochylenie przez wiatr (RAIN_SLANT): scinanie objetosci deszczu wg wysokosci nad oczami, kierunek = wiatr roslin (0.87, 0.49).
 * Kregi na wodzie (RAIN_RIPPLES): komorki 1 blok + druga warstwa obrocona/wieksza; pierscien zostaje w swojej komorce (brak szwow);
   wchodzi do normalnej wody, wiec widac je w odbiciu i w zalamaniu dna. Dziala tylko w nowej wodzie (nie w trybie zgodnosci).
 * Wylacz Fantasy Rain = stary kod deszczu (przydatne do porownania albo gdy w jakiejs wersji MC cos wyglada zle).
 * Snieg uzywa tego samego programu: dostaje te same zaniki, kolor z nieba i blyski (platki mienia sie), bez osobnego rozpoznawania biomu.
 * Zgodnosc: bez nowych uniformow poza standardowymi; colortex7 istnieje w kazdej wersji OptiFine / Iris. Nether i End bez zmian
   (warstwa deszczu tam wylaczona). Iris/OptiFine nie respektuja DRAWBUFFERS w #ifdef zawsze, wiec lista buforow jest stala (07).
 * Kompilacja glslang (tools/check_glsl.py): 58 programow x Overworld/Nether/End x warianty opcji (deszcz on/off, kregi, pochylenie,
   magia, tryb wody, bez SSAO/bloom/god rays, inne palety) = 0 bledow. Matematyka kregow i kontrast smugi sprawdzone numerycznie.
 * NIE TESTOWANE W GRZE. Jesli deszcz jest za slaby / za mocny: Rain Visibility i Rain Brightness. Jesli go brak w jakiejs wersji MC:
   wylacz Fantasy Rain i daj znac, ktora to wersja i czy Iris czy OptiFine.
v24.1: NAPRAWA - deszcz v24 byl niewidoczny w Iris (zgloszone z latest.log: Iris 1.7.6, MC 1.20.1, brak bledow kompilacji, deszczu brak).
 Przyczyna: Iris dokleja do programow #version 120 automatyczny test alfa na gl_FragData[0].a. W v24 slot 0 byl colortex0 z alfa = 0
 (zeby nie zmieniac sceny), wiec Iris odrzucal kazdy fragment deszczu, zanim trafil do colortex7.
 Poprawki: (1) DRAWBUFFERS:70 - slot 0 to warstwa deszczu (jej alfa jest prawdziwa), colortex0 w slocie 1; (2) alphaTest.gbuffers_weather=off
 w shaders.properties; (3) zanikanie na krawedzi zasiegu nigdy nie schodzi do 0 (min 0.30), zeby rozjazd miedzy uniformem rainStrength a alfa
 z gry nie mogl wymazac deszczu; (4) tryb klasyczny tez ma alfa > 0 w slocie 0.
v24.2: nowy suwak Rain Density (RAIN_DENSITY, domyslnie 0.5): vanilla rysuje smuge w kazdej kolumnie blokow, wiec deszcz byl za gesty.
 Swiat jest dzielony na pasy 1/4 bloku, a zostaje ich ulamek RAIN_DENSITY (hash pozycji XZ sprzed pochylenia - pasy sa stabilne w czasie).
v24.3: niebo w deszczu bylo prawie jasne (applyRainToSky: 60% w strone szarosci przy 75% jasnosci), tylko chmury ciemnialy (osobny kod).
 Teraz applyRainToSky miesza do ~0.46 jasnosci szaro-granatowego zachmurzenia; suwak Rain Overcast (RAIN_OVERCAST) skaluje sile.
 Ta sama funkcja barwi mgle i smugi deszczu, wiec pasuja do nieba. Smugi x1.9 (zamiast 1.65) dla kontrastu na ciemniejszym tle.
v25: CHMURY OBJETOSCIOWE (menu: Atmosphere -> Volumetric Clouds). Zmiana: gbuffers_clouds.fsh (stary plaski kod zostaje jako tryb zapasowy),
 lib/settings.glsl, shaders.properties (alphaTest.gbuffers_clouds=off, menu, LOW), lang/*.lang.
 Powod "plaskich" chmur: geometria to jedna plaszczyzna (clouds=fast), a CLOUD_SHADING tylko udawal cien w teksturze - brak parallax i grubosci.
 * Plaszczyzna chmur jest nadal "powierzchnia startowa" (dziala w vanilla, Sodium i innych wersjach), ale dla kazdego jej piksela marszujemy
   promien przez plaster CLOUD_THICKNESS blokow NAD nia. Tekstura chmur (wygladzone pokrycie) mowi, ile chmury jest w danym miejscu XZ;
   szum wartosciowy (~9 i ~3 bloki, powoli dryfuje) daje wysokosc kolumny - srodki wysokie i puchate, brzegi nisko i uniesione, spod plaski.
 * Oswietlenie: Beer w strone slonca/ksiezyca (3 probki), podwojne rozpraszanie (0.12 + 0.88*Tl), rozpraszanie do przodu = srebrna obwodka
   (CLOUD_SILVER), spod chlodniejszy i ciemniejszy, w deszczu szara, gestsza chmura. CLOUD_SHADING_STRENGTH skaluje cien, CLOUD_DENSITY gestosc.
 * Odwzorowanie swiat XZ -> UV z pochodnych ekranowych (dFdx/dFdy) zamiast zalozenia "12 blokow / teksel" i orientacji osi; wynik poza
   rozsadnym zakresem lub NaN = zapas (12 blokow / teksel). Dzieki temu parallax nie jest odwrocony w innych wersjach MC.
 * Ziarno: drobny szum zanika, gdy krok marszu jest dlugi (niski kat), a rozrzut duzego szumu jest tlumiony; jitter interleaved gradient noise.
 * Koszt: CLOUD_VOLUME_STEPS (4 / 6 / 8 / 12) krokow, kazdy z 3 probkami swiatla tylko tam, gdzie jest chmura; tani test wstepny odrzuca puste piksele.
   Profil LOW ustawia 4 kroki. Wylacz Volumetric Clouds = dawne plaskie chmury (CLOUD_SHADING_STEPS dziala tylko w tym trybie).
 * Sprawdzone: kompilacja glslang obu sciezek + CPU-symulacja algorytmu na syntetycznej teksturze (gora, zachod, deszcz, ziarno przy horyzoncie).
   NIE TESTOWANE W GRZE. Jesli chmury znikaja / sa lustrzane / ziarniste: wylacz Volumetric Clouds i opisz wersje MC oraz Iris/OptiFine.
v26: PROCEDURALNE CHMURY 3D (menu: Atmosphere -> Cloud Style). Nowy plik lib/clouds.glsl, zmiany: composite1.fsh, gbuffers_clouds.fsh,
 lib/settings.glsl (CLOUD_STYLE 0/1/2 zamiast CLOUD_VOLUME, CLOUD_HEIGHT/DEPTH/COVERAGE/QUALITY), shaders.properties, lang/*.lang.
 Zgloszenie: "Clouds are still flat" po v25 (latest.log: Iris 1.7.6 + Sodium 0.5.13; ostrzezenia "Shader clouds could not find uniform ModelViewMat..."
 sa nieszkodliwe - ten sam komunikat jest w logach wielu paczek, takze Complementary; nic nie wskazuje na blad kompilacji).
 DIAGNOZA v25: ksztalt chmury nadal byl blokowym obrysem tekstury vanilla (12 blokow / teksel), a objetosc zmieniala glownie cieniowanie -
 oko czyta to jako plaskie. Do tego z Sodium nie mam pewnosci, jaka geometria i tekstura dociera do programu chmur.
 * Styl 2 (domyslny): chmury licza sie w composite1 jako ray-marching po calym niebie (nie zaleza od chmur z gry - gbuffers_clouds odrzuca ich plaszczyzne).
   Ksztalt: wolny szum 2D (~240 blokow) = pokrycie; 3 oktawy szumu 3D (~54 / 24 / 10 blokow) rzezbia puchate klebki; prog zalezy od pokrycia;
   profil wysokosci = plaski spod, wierzch rosnie z pokryciem. Wspolrzedne absolutne (chmury stoja w swiecie), dryf z kierunkiem wiatru roslin.
 * Swiatlo: marsz w strone slonca / ksiezyca (3 probki, 2 oktawy), Beer + wielokrotne rozproszenie (0.12 + 0.88*Tl), rozpraszanie do przodu
   (srebrna obwodka, CLOUD_SILVER), jasniejsza gora, chlodniejszy i ciemniejszy spod, deszcz = wiecej pokrycia, gestsze, szare. Dalekie chmury w mgle nieba.
 * Koszt: CLOUD_QUALITY krokow (12 / 16 / 20 / 24 / 32) x (1 pelna gestosc + 3 probki swiatla tam, gdzie jest chmura). Piksele, ktorych promien nie trafia
   w warstwe, wychodza od razu. Profil LOW = 12 krokow. Jesli FPS spada: Cloud Quality w dol albo Cloud Style = Vanilla plane / Flat.
 * Styl 1 = v25 (plaszczyzna z gry + objetosc), styl 0 = oryginalne plaskie chmury z fake-cieniowaniem.
 * Uwaga: znacznik chmury (colortex2.r), ktory CLOUD_SHAFTS uzywal do "dziur w chmurach" dla god rays, w stylu 2 nie jest zapisywany - promienie
   nie sa przyslaniane przez chmury (tylko w stylu 2).
 * Sprawdzone: kompilacja glslang (style 0/1/2, jakosci, 3 wymiary, deszcz on/off) + CPU-port algorytmu: 5 scen (dzien, nad glowa, zachod, deszcz, horyzont);
   pierwsza wersja byla mglista - zmieniono tak, by to szum 3D rzezbil ksztalt (a nie pokrycie 2D). NIE TESTOWANE W GRZE.
v27: CHMURY "PODUSZKI" (menu: Atmosphere -> Cloud Style -> Pillows; domyslny styl 3). lib/clouds.glsl przepisany; zmiany: lib/settings.glsl
 (CLOUD_STYLE 0-3, CLOUD_CELL, CLOUD_ROUNDNESS, CLOUD_SOFTNESS), composite1.fsh / gbuffers_clouds.fsh (style >= 2), shaders.properties, lang/*.lang.
 Wymagania: klasyczna siatka blokow Minecrafta, kazdy blok zaokraglony; miekkie krawedzie; poswiata krawedzi (SSS) w strone slonca; lagodne cieniowanie;
 integracja z mgla i plynne zanikanie w oddali.
 * Ksztalt: siatka komorek CLOUD_CELL (12 blokow jak vanilla); zajeta komorka = zaokraglony blok (SDF prostopadloscianu, promien = 0.5 * CELL * ROUNDNESS,
   ograniczony wysokoscia). Zajetosc: wolny szum po INDEKSIE komorki (klastry kilku blokow), grubosc kazdej komorki zmienna (grubsze rdzenie klastrow).
   Trzy najblizsze komorki laczone smooth-min (k = 0.22 * CELL) => pikowane, pluszowe masy; minimalne zaburzenie pozycji szumem 3D, zeby nie bylo idealnie geometrycznie.
 * Miekkie krawedzie: gestosc = 1 - smoothstep(-SOFTNESS, +SOFTNESS, SDF) - alfa spada plynnie z odlegloscia od powierzchni, nigdzie nie ma twardego progu.
 * Oswietlenie: marsz w strone swiatla (3 probki) z lagodnym kontrastem (0.20 + 0.80 * Beer), jasna gora, spod i zaglebienia lekko ciemniejsze (AO z probki nad punktem),
   SSS: pow(cos(kat do swiatla), 3) * exp(-tau * 0.22) * (krawedz jasniejsza) - miekka szeroka poswiata, gdy patrzysz w strone slonca / ksiezyca (skala CLOUD_SILVER).
 * Atmosfera: odleglosc zaniku z mgly globalnej (FOG_DENSITY; w deszczu krocej): kolor -> kolor nieba w tym kierunku, kontrast spada, a przy koncu zasiegu (2200 blokow)
   alfa schodzi do zera plynnie. Daleko (krok marszu >> komorka) gestosc przechodzi w gladkie pokrycie (LOD) - bez aliasingu / pasow.
 * Sprawdzone: glslang (style 0-3, jakosci, 3 wymiary, deszcz) + CPU-port: z ziemi, odwrotnie do slonca, pod slonce, zachod, deszcz; wykryto i naprawiono pasy
   aliasingu przy horyzoncie (wczesniejsze LOD) i zbyt slaba poswiate (x2). NIE TESTOWANE W GRZE. Koszt jak styl 2 lub nizszy (tanszy szum: 4 komorki zamiast 3D FBM).
v28: WYDAJNOSC CHMUR (zgloszenie: "gra niegrywalna, bardzo laguje" przy v27). Chmury byly liczone w pelnej rozdzielczosci, a kazdy krok marszu liczyl
 ~44 odczytow szumu, w gestych krokach dodatkowo 4 pelne gestosci (swiatlo + AO) - rzedu 1600 odczytow na piksel nieba. Teraz:
 * Polowa rozdzielczosci: marsz jest w composite.fsh (juz istniejacy pass 1/2 rozdzielczosci, jak SSAO), wynik w colortex6 (rgb przedmnozone, a = przezroczystosc).
   composite1.fsh robi upsample 2x2 z waga glebi (colortex5.b) - piksel nieba bierze teksele nieba, teren - teren, bez halo na krawedziach. 4x mniej pikseli.
   composite jest teraz zawsze wlaczony (program.composite.enabled usuniete) - chmury nie zaleza od SSAO / GODRAYS. colortex6 czytamy zanim bloom (composite7) go nadpisze.
 * Tanszy ksztalt (styl 3): zajetosc komorki = 1 oktawa szumu + 1 hash (5 odczytow, bylo 9), wczesne odrzucenie pustych miejsc (4 odczyty),
   brak szumu 3D przesuwajacego geometrie, grubosc komorki z tego samego hasha.
 * Swiatlo / AO na tanim, gladkim modelu pokrycia (4 odczyty): 2 probki swiatla + 1 AO zamiast 4 pelnych gestosci.
 * Kroki adaptacyjne: liczba krokow wg grubosci warstwy do przejscia (krok ~0.4 komorki, min 3, max CLOUD_QUALITY=12 domyslnie, LOW = 6). Patrzac w gore 3-6 krokow.
 * Szacunek (licznik odczytow szumu w symulacji, NIE pomiar na GPU): ~9x mniej pracy na piksel z samych zmian algorytmu, ~36x razem z polowa rozdzielczosci.
   Wyglad sprawdzony ponownie na symulacji (siatka blokow, poswiata przy sloncu, deszcz, horyzont); wykryto i naprawiono rozmycie struktury siatki przy krotkiej liczbie krokow.
 * Jesli nadal laguje: Cloud Quality w dol (8 / 6), Cloud Style = Vanilla plane / Flat. Jesli chmury znikaja: ten sam przelacznik + opis wersji MC i latest.log.
v29: CHMURY JAKO JEDNA MASA (zgloszenie: "kazda chmura wyglada jak pocieta na mniejsze kostki"). Przyczyna: kazda komorka to osobny zaokraglony blok,
 a w miejscu styku dwoch blokow zaokraglone krawedzie zostawiaja rowek - rowki rysowaly siatke WEWNATRZ chmury.
 * Nowy suwak CLOUD_MERGE (domyslnie 0.7; 0.22 = stare, widac kostki): sila gladkiego laczenia komorek smooth-min k = CELL * MERGE. Rowki sie wypelniaja,
   zostaje zaokraglony, lekko blokowy OBRYS calej chmury. Koszt zerowy (ta sama liczba komorek, zmienia sie tylko parametr).
 * Skoki grubosci miedzy sasiednimi komorkami maleja wraz z MERGE (zakres zmiennosci 0.38 * (1 - 0.55 * MERGE)) - mniej "szachownicy" wewnatrz masy.
 * Max 0.9: przy wiekszych wartosciach smooth-min potrzebowalby komorek spoza 2x2 (patrzymy tylko na 4 najblizsze) i na brzegach pojawia sie ziarno
   (zaobserwowane w symulacji przy 1.5).
 * Sprawdzone: glslang + CPU-symulacja (merge 0.22 / 0.6 / 1.0 / 1.5; z gory, z ziemi, deszcz, nisko). NIE TESTOWANE W GRZE.
v30: STYL CHMUR "VANILLA" (CLOUD_STYLE 4, domyslny; zgloszenie: "zrob je bardziej minecraftowe / vanilla"). Poduszki (styl 3) zostaja dostepne.
 Co robi vanilla: wszystkie komorki tej samej wysokosci (plaskie gory, brak szwow), ostre krawedzie i naroza, stale cieniowanie scian jak w chmurach fancy
 (gora 1.0, spod 0.7, sciany E/W 0.8, N/S 0.9), bialy kolor pory dnia, alfa ~0.9, zwarte klastry zamiast losowych dziur.
 * Ten sam silnik co styl 3 (siatka komorek 12 blokow, polowa rozdzielczosci, upsample w composite1), parametry: grubosc CLOUD_VTHICK (5; vanilla 4),
   zaokraglenie 0.10, miekkosc krawedzi 0.7, laczenie 0.26 (tylko zakrywa szwy), waga losowych dziur 0.10, gestosc sigma 0.55.
 * Ktora sciane widzimy: z najblizszej plaszczyzny prostopadloscianu komorki; sciana, za ktora jest zajeta komorka, to wnetrze masy (nie sciana) - brak kratki w srodku chmury.
 * Taniej niz Poduszki: nie ma marszu w strone swiatla ani AO (plaskie oswietlenie), tylko 1 gestosc + wybor sciany w kroku.
 * Kolor: (AMBIENT*0.62 + LIGHT*0.40) * wspolczynnik_sciany * 1.30, 70% odbarwienia -> prawie neutralna biel; zachod slonca dalej je zabarwia (kolor swiatla z palety).
 * Sprawdzone: glslang (style 0-4, jakosci, 3 wymiary) + CPU-symulacja (z ziemi, z wysoka, odwrotnie do slonca, deszcz). NIE TESTOWANE W GRZE.
v31: STYL CHMUR "MIEKKIE BLOKI" (CLOUD_STYLE 5, domyslny; prosba: "chce chmury takie jak w tej paczce" - Complementary Reimagined r5.9.3.1).
 UWAGA PRAWNA: licencja Complementary 1.7 jest "wszystkie prawa zastrzezone" poza wyraznymi zgodami (zmodyfikowana paczka musi m.in. zawierac ich licencje,
 podac autora, nie miec w nazwie "Complementary"). Dlatego NIC z ich kodu nie zostalo skopiowane: przeczytano tylko, JAK wyglada i na jakiej zasadzie dziala ich
 chmura, a ten styl napisano od zera na wlasnym szumie, wlasnej interpolacji i wlasnym cieniowaniu, w istniejacym potoku (polowa rozdzielczosci + upsample).
 Zasada (ogolna, nie kod): uklad komorek jak w vanilla; pole pokrycia M(x,z) z dwuliniowej interpolacji wartosci komorek ze SPLASZCZONYMI wagami (plateau w srodku,
 krotkie zaokraglone przejscie na granicy) => zaokraglone, blokowe krawedzie, a dwie pelne sasiednie komorki daja M=1 i nie ma szwow; profil pionowy: chmura istnieje
 na wysokosci u tylko tam, gdzie M przekracza prog rosnacy ku gorze i spodowi (gora - mocna kopula, spod - prawie plaski); prawie nieprzezroczyste; kolor liczony RAZ
 w srednim punkcie trafienia (jasniej ku gorze, miekki cien w strone slonca z 2 tanich probek, poswiata cienkich brzegow, w oddali kolor nieba).
 * Koszt: tanszy niz Poduszki (brak SDF, brak marszu swiatla w kazdym kroku): ~20 odczytow szumu na krok + ~16 na cieniowanie; srednio ~5 krokow na piksel (symulacja).
 * Nowe opcje: CLOUD_BTHICK (10), CLOUD_BROUND (0.20). Wspolne: Height, Coverage, Density, Quality, Cell. Styl 4 (Vanilla), 3 (Poduszki), 2, 1, 0 nadal dostepne.
 * Sprawdzone: glslang (style 0-5, 3 wymiary, jakosci) + CPU-symulacja (z ziemi, nad glowa, tylem do slonca, deszcz, grubsze/okragle). Nie mam ich paczki do porownania
 obok siebie w grze, wiec NIE TESTOWANE W GRZE i podobienstwo oparte jest na zasadzie dzialania, nie na zdjeciu.
v32: POPRAWKI CHMUR "MIEKKIE BLOKI" (zgloszenie: "krawedzie wygladaja jakby byly ucięte, a blisko chmur widac biale kolo / pol kola").
 Przyczyny (odtworzone w symulacji CPU) i naprawy:
 * BIALE KOLO / POL KOLA = tarcza slonca (lub ksiezyca) PRZEZ chmure. Marsz konczy sie przy przepuszczalnosci T < 0.05, a tarcza ma jasnosc HDR o rzad
   wieksza niz niebo, wiec 5% wystarczalo, by bylo ja widac; przy krawedzi chmury wychodzi pol kola. Naprawa: (1) T przeskalowane z [0.05, 1] do [0, 1]
   (nieprzezroczysta chmura blokuje calkowicie), (2) w composite1 bardzo jasne piksele (luma 1.5-4) sa przyslaniane mocniej (T^3 zamiast T).
 * KRESKOWANE KRAWEDZIE: opacity jednego kroku (sigma * dt ~ 3.8) nasycala sie do ~96%, wiec pokrycie piksela krawedziowego zalezalo od tego, czy jedna
   losowa probka trafi w chmure (wzor kreskowania). Naprawa: sigma 0.80 -> 0.42 (krawedzie narastaja plynnie).
 * UCIETA GORA / SPOD: profil pionowy nie schodzil do zera przed granica plastra (gora ~0.58 gestosci i nagle 0). Naprawa: prog rosnie PONAD 1 przy samej
   gorze i spodzie (1.10 * s^3 / s^8) + miekszy skok (0.26), wiec brzegi zaokraglaja sie i gasna plynnie.
 * PIERSCIENIE wokol zenitu (prazki tonalne we wnetrzu chmury): liczba krokow zmieniala sie skokowo z katem. Naprawa: staly krok dt = max(0.3 * CELL, span / QUALITY).
 * Sprawdzone: glslang (style 0-5, 3 wymiary) + CPU-symulacja widokow tuz pod / w warstwie chmur, z ziemi. NIE TESTOWANE W GRZE.
v33: WYGLADZANIE KRAWEDZI CHMUR - akumulacja czasowa ("TAA tylko dla chmur") + opcjonalny FXAA (zgloszenie: "krawedzie chmur dalej wygladaja na ucięte").
 DIAGNOZA (symulacja potoku z polowa rozdzielczosci + upsample 2x2): krawedzie mialy schodki (jedna probka ksztaltu na piksel polowy rozdzielczosci, bez antyaliasingu)
 i szachownicowy wzor szumu marszu. FXAA sam lagodzi schodki, ale zostawia szum; wyraznie pomaga dopiero uśrednianie w czasie.
 * Pelne TAA dla calego obrazu wymaga jitterowania macierzy projekcji we WSZYSTKICH shaderach geometrii + historii + obslugi ghostingu - niemozliwe do sprawdzenia bez gry
   i latwo o smugi na terenie / mobach. Chmury sa "w nieskonczonosci", wiec dla nich wystarcza reprojekcja samym obrotem kamery (bez glebi) - bezpieczniejsze.
 * CLOUD_TAA (domyslnie wlaczone), composite.fsh: promien kazdego piksela jest przesuniety o ulamek piksela (Halton 2,3, 16 klatek) i ma inne przesuniecie szumu marszu
   (frameCounter); wynik jest mieszany z poprzednia klatka z nowego bufora colortex8 (RGBA16F, colortex8Clear=false; alfa = przezroczystosc + 1, wartosc < 0.5 = brak historii).
   Reprojekcja: gbufferPreviousModelView/Projection * kierunek swiata. Historia probkowana Catmull-Rom 4x4 (reczne 16 odczytow, niezalezne od filtrowania bufora; ujemne listki przyciete).
   Waga biezacej klatki: 0.12 (ok. 8 klatek) przy braku ruchu, rosnie do 0.45 przy ruchu kamery (< ~1.5 px polowy rozdzielczosci), a przy duzej roznicy historia / klatka
   (nowa chmura, teleport, deszcz: smoothstep 0.60-1.10) = 1.0 (tylko obecna klatka). Przy "brak historii" (pierwsza klatka, zmiana rozmiaru) bierzemy tylko biezaca klatke.
   composite1 czyta teraz colortex8 (zamiast colortex6) i pomija teksele bez historii.
 * Wartosci dobrane w symulacji CPU z obracajaca sie kamera (blad wzgledem czystego odniesienia, mniej = lepiej; "brak" = bez akumulacji):
   brak ruchu 0.0347 -> 0.0225; 0.15 st./klatke 0.0346 -> 0.0282; 0.5 st./klatke 0.0340 -> 0.0290; 1.0 st./klatke 0.0332 -> 0.0313.
   Pierwsze strojenie bylo gorsze od braku akumulacji (za waski prog odrzucania wyrzucal historie na zaszumionych krawedziach; bilinear rozmywal przy wolnym obrocie) - naprawione
   (prog 0.60-1.10, Catmull-Rom, krotsza historia przy ruchu). Celowo zle dobrana reprojekcja daje blad 0.096, wiec kierunek reprojekcji jest sprawdzony.
 * FXAA (domyslnie wlaczone; wylacz, jesli tekstury sa za miekkie): final.fsh, na kolorze sceny PRZED bloomem / tonemappingiem; jasnosc percepcyjna sqrt(c/(1+c)),
   prog kontrastu max(0.0312, 0.125 * maxJasnosc), usrednianie wzdluz krawedzi, odrzucenie wyniku spoza zakresu sasiadow.
 * Ryzyko / ograniczenia: (1) historia w tym samym przejsciu, ktore ja zapisuje (standardowy wzorzec TAA w paczkach - Iris podmienia bufory), ale NIE TESTOWANE W GRZE;
   wylaczenie Cloud Smoothing usuwa odczyt historii z shadera. (2) colortex8 wymaga OptiFine / Iris z buforami 8+ (Iris: tak). (3) Podczas szybkiego obrotu krawedzie chmur
   moga byc odrobine bardziej ziarniste niz w bezruchu. (4) Dodatkowy bufor RGBA16F (ok. 16 MB przy 1080p).


v34: POPRAWKI WIDOCZNOSCI CHMUR PODCZAS RUCHU KAMERY
 * Ray-marching chmur pobiera teraz glebokosc w tym samym jitterowanym miejscu co promien, a limit odleglosci jest ograniczony
   zarowno glebia probki, jak i srodkowego piksela. Ogranicza to przebijanie chmur przez bloki na krawedziach przy ruchu.
 * CLOUD_TAA reprojektuje sredni punkt trafienia w chmurze z uzyciem previousCameraPosition, zamiast zakladac nieskonczona
   odleglosc i uwzgledniac tylko obrot. To poprawia paralakse podczas chodzenia, spadania i poruszania sie pionowo.
 * Historia TAA jest pomijana dla promienia bez aktualnego trafienia w chmure, aby stary obraz chmury nie pozostawal na
   pikselach zaslonietych obecnie przez bloki.
 * Weryfikacja statyczna kodu; nie testowane w uruchomionej grze.

v35: CIENIE CHMUR NA TERENIE (menu: Atmosphere -> Cloud Shadows / Cloud Shadow Strength / Cloud Shadow Quality). Nowy plik lib/cloudshadow.glsl,
 zmiany: lib/shadow.glsl, lib/clouds.glsl, lib/settings.glsl, deferred.fsh, 9 programow z oswietleniem (tylko usuniety duplikat uniformu rainStrength),
 shaders.properties (menu, profile), lang/*.lang.
 * Zasada: z punktu terenu idzie promien DO slonca / ksiezyca (swiat absolutny), przecina plaster chmur, a w CLOUD_SHADOW_QUALITY punktach (2-4)
   odpytujemy TEN SAM cloudDensity(), ktory rysuje composite.fsh. Stad cien ma ksztalt i dryf (frameTimeCounter) widocznych chmur i sunie po krajobrazie razem z nimi.
 * Gdzie wchodzi: getShadow() / getShadowLite() mnoza wynik shadow mapy przez getCloudShadow(), wiec dostaja go wszystkie programy oswietlajace
   (deferred / terrain, byty, bloki-byty, czasteczki, blysk slonca na wodzie). Dziala TAKZE poza shadowDistance (shadow mapa konczy sie na 56-160 blokach, cien chmur nie).
 * Blokowane jest tylko swiatlo BEZPOSREDNIE (zostaje ok. 1 - CLOUD_SHADOW_STRENGTH = 20%); swiatlo otoczenia nie ciemnieje, wiec cien jest chlodny i miekki.
   W deszczu efekt wygasa (calcLighting i tak przyciemnia slonce o 75%), przy sloncu < ok. 5-17 stopni nad horyzontem tez (cien robilby sie nieskonczenie dlugi).
 * Pomijane: jaskinie (lm.y < 0.12), tylne scianki, teren powyzej plastra chmur, Nether / End, reka. DEFERRED: SSS lisci tez slabnie pod cieniem chmury.
 * LOD: dalej niz ok. 220-640 blokow model przechodzi w gladkie pokrycie (bez migotania siatki komorek).
 * Wymaga CLOUD_STYLE 2-5. Styl 0 / 1 (chmury z gry) - cienie sa wylaczone, bo tekstury chmur z gry nie da sie odczytac w oswietleniu terenu.
 * Profile: LOW wylacza, MEDIUM = 2 probki, HIGH = 3, ULTRA / MAXIMUM = 4. Koszt: QUALITY x cloudDensity na piksel oswietlonego terenu (rzedu 20-30 odczytow szumu na probke w stylu 5).
 * Sprawdzone: glslang (style 0-5, jakosc 2/3/4, opcja wylaczona, bez SHADOWS, bez DEFERRED_LIGHTING, 3 wymiary) + CPU-port stylu 5: przy sloncu w zenicie
   cien = dokladnie kolumna widocznej chmury (korelacja 1.0), ok. 35% terenu w cieniu przy domyslnym pokryciu, minimum 0.20, dryf przesuwa wzor. NIE TESTOWANE W GRZE.

v36: PROMIENIE SWIATLA PRZEZ CHMURY (God Rays + Cloud Light Shafts) dla procedur. chmur (CLOUD_STYLE 2-5). Zmiany: composite.fsh, lib/clouds.glsl, lib/cloudshadow.glsl.
 * Problem: CLOUD_SHAFTS czytal znacznik chmury z colortex2.r, a chmury proceduralne (v26+) go nie zapisuja - promienie nie mialy "dziur" miedzy chmurami.
 * Teraz: dla kazdej probki promienia, ktora trafia w niebo, bierzemy jej kierunek w swiecie i pytamy cloudSkyOpacity() - ta sama cloudDensity() co widoczne
   chmury (2 probki w plastrze, dol + gora, bez marszu; daleko LOD -> gladkie pokrycie). Gesta chmura przepuszcza 12% swiatla, luka 100%, wiec smugi lamia sie za krawedziami
   chmur i dryfuja razem z nimi. Teren / woda nadal blokuja w pelni (depthtex1).
 * Wspolne funkcje cloudThickness() / cloudSigma() przeniesione do lib/clouds.glsl (uzywa ich tez cien chmur). Style 0 / 1 uzywaja starej sciezki ze znacznikiem.
 * Koszt: GODRAYS_SAMPLES x (toView + 2 gestosci) na piksel polowy rozdzielczosci, tylko dla probek nieba. Jesli FPS spada: mniej probek God Rays.
 * Sprawdzone: glslang (style 0-5, opcje wlaczone / wylaczone, 3 wymiary) + CPU-port stylu 5 (przy sloncu 20-35 stopni ok. 50% kierunkow w luce, ok. 45% zablokowanych). NIE TESTOWANE W GRZE.
